import * as i0 from '@angular/core';
import { InjectionToken, signal, Injectable, input, output, Component, provideAppInitializer, inject, computed, ChangeDetectionStrategy, viewChild, ViewEncapsulation, effect, Pipe, linkedSignal, ViewChild, HostBinding, DestroyRef, model } from '@angular/core';
import { TitleCasePipe, AsyncPipe, formatDate as formatDate$1, NgTemplateOutlet, DatePipe, SlicePipe, NgComponentOutlet, JsonPipe, NgStyle } from '@angular/common';
import * as i2 from 'primeng/api';
import { SharedModule, FilterService, ConfirmationService, MessageService } from 'primeng/api';
import * as i1 from 'primeng/button';
import { ButtonModule } from 'primeng/button';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import * as i2$1 from '@angular/forms';
import { UntypedFormGroup, FormArray, FormControl, Validators, ReactiveFormsModule, FormsModule, FormGroup, FormGroupDirective } from '@angular/forms';
import * as i3$2 from 'primeng/card';
import { CardModule } from 'primeng/card';
import * as i2$2 from 'primeng/checkbox';
import { CheckboxModule } from 'primeng/checkbox';
import * as i1$e from 'primeng/dialog';
import { DialogModule } from 'primeng/dialog';
import { BehaviorSubject, switchMap, of, catchError, map, tap, delay, retry, Subscription, debounceTime, distinctUntilChanged, filter, shareReplay, throwError, from, combineLatest, Subject } from 'rxjs';
import { isArray, isNil, isString, isNumber, isDate, isObject, isFunction, isEmail } from '@dwtechs/checkard';
import * as i3$1 from 'primeng/panel';
import { PanelModule } from 'primeng/panel';
import * as i2$5 from 'primeng/progressspinner';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { PrimeNG } from 'primeng/config';
import * as i1$1 from 'primeng/autocomplete';
import { AutoComplete, AutoCompleteModule } from 'primeng/autocomplete';
import * as i1$2 from 'primeng/datepicker';
import { DatePickerModule } from 'primeng/datepicker';
import { DividerModule } from 'primeng/divider';
import * as i2$3 from 'primeng/tooltip';
import { TooltipModule, Tooltip } from 'primeng/tooltip';
import { HttpClient } from '@angular/common/http';
import saveAs, { saveAs as saveAs$1 } from 'file-saver';
import * as i1$3 from 'primeng/inputnumber';
import { InputNumberModule } from 'primeng/inputnumber';
import * as i1$4 from 'primeng/inputtext';
import { InputTextModule } from 'primeng/inputtext';
import * as i1$d from 'primeng/iftalabel';
import { IftaLabelModule } from 'primeng/iftalabel';
import * as i1$5 from 'primeng/multiselect';
import { MultiSelectModule, MultiSelect } from 'primeng/multiselect';
import * as i1$6 from 'primeng/picklist';
import { PickListModule } from 'primeng/picklist';
import * as i1$7 from 'primeng/radiobutton';
import { RadioButtonModule } from 'primeng/radiobutton';
import * as i1$8 from 'primeng/editor';
import { EditorModule } from 'primeng/editor';
import * as i1$9 from 'primeng/selectbutton';
import { SelectButtonModule } from 'primeng/selectbutton';
import * as i1$a from 'primeng/select';
import { SelectModule } from 'primeng/select';
import * as i1$b from 'primeng/table';
import { TableModule, Table } from 'primeng/table';
import { SliderModule } from 'primeng/slider';
import * as i1$c from 'primeng/textarea';
import { TextareaModule } from 'primeng/textarea';
import * as i2$4 from 'primeng/floatlabel';
import { FloatLabelModule } from 'primeng/floatlabel';
import * as i3 from 'primeng/iconfield';
import { IconFieldModule } from 'primeng/iconfield';
import * as i4 from 'primeng/inputicon';
import { InputIconModule } from 'primeng/inputicon';
import { ActivatedRoute, Router } from '@angular/router';
import * as i2$6 from 'primeng/confirmdialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import * as i1$h from 'primeng/progressbar';
import { ProgressBarModule } from 'primeng/progressbar';
import * as i3$4 from 'primeng/toast';
import { ToastModule } from 'primeng/toast';
import { DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';
import * as i1$f from 'primeng/listbox';
import { ListboxModule } from 'primeng/listbox';
import * as i3$3 from 'primeng/contextmenu';
import { ContextMenuModule } from 'primeng/contextmenu';
import * as i4$1 from 'primeng/buttongroup';
import { ButtonGroupModule } from 'primeng/buttongroup';
import { FileUploadModule } from 'primeng/fileupload';
import * as i1$g from 'primeng/toolbar';
import { ToolbarModule } from 'primeng/toolbar';
import * as i6 from 'primeng/ripple';
import { RippleModule } from 'primeng/ripple';
import { Export } from '@dwtechs/csvx';
import * as ExcelJS from 'exceljs';

const defaultValue$1 = {
    title: "",
    appKey: "",
    storageKeys: {},
    apiPrefix: "/api/",
};
const APP_CONFIG = new InjectionToken("APP_CONFIG", {
    providedIn: "root",
    factory: () => defaultValue$1,
});

class LoadingService {
    defaultMode = "bar";
    _isLoading = signal(false, ...(ngDevMode ? [{ debugName: "_isLoading" }] : /* istanbul ignore next */ []));
    _mode = signal(this.defaultMode, ...(ngDevMode ? [{ debugName: "_mode" }] : /* istanbul ignore next */ []));
    isLoading = this._isLoading.asReadonly();
    mode = this._mode.asReadonly();
    start(mode = this.defaultMode) {
        this._mode.set(mode);
        this._isLoading.set(true);
    }
    stop() {
        this._isLoading.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LoadingService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LoadingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root",
                }]
        }] });

class LocalStorageService {
    getItem(key) {
        return localStorage.getItem(key);
    }
    setItem(key, data) {
        localStorage.setItem(key, data);
    }
    removeItem(key) {
        localStorage.removeItem(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocalStorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocalStorageService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocalStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root",
                }]
        }] });

const PRIMENG_FR = {
    accept: "Accepter",
    reject: "Annuler",
    dayNames: [
        "Dimanche",
        "Lundi",
        "Mardi",
        "Mercredi",
        "Jeudi",
        "Vendredi",
        "Samedi",
    ],
    dayNamesShort: ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"],
    dayNamesMin: ["Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa"],
    monthNames: [
        "Janvier",
        "Février",
        "Mars",
        "Avril",
        "Mai",
        "Juin",
        "Juillet",
        "Aout",
        "Septembre",
        "Octobre",
        "Novembre",
        "Décembre",
    ],
    monthNamesShort: [
        "Jan",
        "Fév",
        "Mar",
        "Avr",
        "Mai",
        "Jui",
        "Jul",
        "Aou",
        "Sep",
        "Oct",
        "Nov",
        "Déc",
    ],
    today: "Aujourd'hui",
    matchAll: "Satisfait tous les critères",
    matchAny: "Satisfait un des critères",
    startsWith: "Commence par",
    endsWith: "Finit par",
    contains: "Contient",
    notContains: "Ne contient pas",
    equals: "Egal à",
    notEquals: "Différent de",
    lt: "Inférieur à",
    lte: "Inférieur ou égal à",
    gt: "Supérieur à",
    gte: "Supérieur ou égal à",
    dateIs: "Date égale à",
    dateIsNot: "Date différente de",
    dateBefore: "Date avant",
    dateAfter: "Date après",
    removeRule: "Supprimer la règle",
    addRule: "Ajouter une règle",
    clear: "Effacer",
    apply: "Appliquer",
};

/**
 * Get a list of SelectItems from a list of item
 * @param items list of item to map
 * @param keyoflabel key of the label property
 * @returns a list of select item
 */
function toSelectItems(items, keyoflabel, extraKeys) {
    return (items ?? []).map((item) => ({
        value: item.id,
        label: item[keyoflabel],
        extraData: extraKeys?.reduce((acc, key) => {
            acc[key] = item[key];
            return acc;
        }, {}),
    }));
}

class SnackbarService {
    messageService;
    constructor(messageService) {
        this.messageService = messageService;
    }
    displayError(message = "Une erreur est survenue") {
        this.show({
            severity: "error",
            detail: message,
        });
    }
    displaySuccess() {
        this.show({
            key: "topRight",
            severity: "success",
            closable: false,
        });
    }
    displayInfo(message) {
        this.show({
            detail: message,
        });
    }
    show(messageConfig) {
        if (!messageConfig.key) {
            if (!messageConfig.severity) {
                messageConfig.severity = "info";
            }
            if (!messageConfig.summary) {
                messageConfig.summary = TitleCasePipe.prototype.transform(messageConfig.severity);
            }
        }
        this.messageService.add(messageConfig);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SnackbarService, deps: [{ token: i2.MessageService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SnackbarService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SnackbarService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }], ctorParameters: () => [{ type: i2.MessageService }] });

function interpolate(string, values) {
    return string.replace(/\{([^}]+)\}/g, (_, v) => {
        const valueProp = v;
        const value = values[valueProp] ?? "";
        return value.toString();
    });
}

class ColumnOptions {
    /** Defines if the column is sortable or not */
    sortable;
    /** Specifies a default value for the filter*/
    defaultFilter;
    /** Should the column be sorted by default when landing on the table */
    defaultSortField;
    /** Should the column be sorted ascending (1) or descending (-1) */
    defaultSortOrder;
    /** Defines if the column is filterable or not */
    filterable;
    /** Specifies a specific control type for the filter input */
    filterType;
    /** Custom tooltip renderer for the column cells */
    tooltip;
    /** If set to true, the column will be hidden but can be unhidden in column management */
    isSoftHidden;
    /** If set to true, the column will be hidden in the table and in the column management dialog */
    isHardHidden;
    /** Specifies a custom renderer for datatable cells
     * TODO: allow to use a custom component as renderer
     * Warning: be careful when using this prop, as it can lead to performance issues
     * Along with xss security issues if the renderer returns unsafe HTML
     */
    customCellRenderer;
    /** Specifies a custom HTML renderer for the column header
     * Warning: be careful when using this prop as it can lead to XSS security issues
     * if the renderer returns unsafe HTML
     */
    customHeaderRenderer;
    /** Specifies a custom component for datatable cells -- Works for CUSTOM controlType */
    customComponent;
    /** If true and the value is an array, each item will be displayed as a chip. Default true */
    valueAsChip;
    /** Cell will be centered */
    centered;
    /** Maximal width of the column. If not defined, will default to 150px */
    defaultWidth;
    /* Should column be frozen (false by default)
      As default is left frozen, the frozen columns should be the first ones
    */
    isFrozen;
    /** Specifies if the column should be ignore on export */
    ignoreOnExport;
    /** If the column should have a different label that the main label defined in CrudItemOptions */
    label;
    /** Custom tooltip for the column header. Falls back to the column label if not defined */
    headerTooltip;
    /** If the edition of this cell should be disabled in inline-cell edition mode */
    isCellEditionDisabled;
}

class ControlOptions {
    /**
     * Defines the action to take when a form field interaction occurs -
     * allows setting values of other fields based on interactions
     */
    action;
    /** Should the increment/decrement buttons be visible for number inputs
     * @default true
     * @example `areNumberInputButtonsVisible: false` // Hides the buttons
     */
    areNumberInputButtonsVisible;
    /** Should the options in dropdowns and multiselects be filterable
     * @default true
     * @example `areOptionsFilterable: false` // Enables a search input to filter options
     */
    areOptionsFilterable;
    /**
     * Specifies async validators for form control that perform asynchronous validation
     * @example `asyncValidators: [this.emailExistsValidator()]` // Custom async validator checking if email exists
     */
    asyncValidators;
    /** Minimum number of characters required to trigger autocomplete suggestions
     * @example `autocompleteMinQueryLength: 3` // Suggestions appear after typing 3 characters
     */
    autocompleteMinQueryLength;
    /** Delay in milliseconds before triggering autocomplete suggestions after user input
     * @example `autocompleteDelay: 300` // Waits 300ms after typing before fetching suggestions
     */
    autocompleteDelay;
    /** Height of the autocomplete suggestions dropdown
     * @example `autocompleteScrollHeight: '200px'` // Sets the dropdown height to 200 pixels
     */
    autocompleteScrollHeight;
    /** Should the autocomplete control allow selecting multiple values
     * @example `autocompleteMultiple: true` // Enables multi-select in autocomplete
     */
    autocompleteMultiple;
    /** Should the autocomplete control show a dropdown button to display all options
     * @example `autocompleteDropdown: true` // Shows a dropdown button
     */
    autocompleteDropdown;
    /**
     * Configuration for the FormArray control when isFormArray is true
     * @example `controlArrayConfig: { minItems: 1, maxItems: 5, addButtonLabel: 'Add Item' }`
     */
    controlArrayConfig;
    /** Currency code for number inputs of type currency
     * @example `numberCurrency: 'USD'` // Displays values in US Dollars
     */
    numberCurrency;
    /** Custom component to use as the form control instead of built-in types
     * @example `customComponent: MyCustomControlComponent` // Renders a custom Angular component as the form control
     **/
    customComponent;
    /** Dates that should be disabled (not selectable) in the date picker
     * @example `dateDisabledDates: [new Date(2023, 0, 1), new Date(2023, 11, 25)]` // Disables January 1 and December 25, 2023
     */
    dateDisabledDates;
    /** Days of the week that should be disabled in the date picker
     * 0 = Sunday, 1 = Monday, ..., 6 = Saturday
     * @example `dateDisabledDays: [0,6]` // Disables all Sundays and Saturdays
     */
    dateDisabledDays;
    /** Date format string for displaying dates in the control
     * @example `dateFormat: 'dd/mm/yy'` // Displays dates in day/month/year format
     * @default 'yy-mm-dd'
     */
    dateFormat;
    /** Minimum selectable date in the date picker
     * @example `dateMin: new Date(2020, 0, 1)` // Users cannot select dates before January 1, 2020
     */
    dateMin;
    /** Maximum selectable date in the date picker
     * @example `dateMax: new Date(2025, 11, 31)` // Users cannot select dates after December 31, 2025
     */
    dateMax;
    /** Should the date picker overlay hide automatically upon selecting a date
     * @default false
     * @example `dateHideOverlayOnSelect: true` // Closes the overlay when a date is selected
     */
    dateHideOverlayOnSelect;
    /** Maximum number of dates that can be selected in 'multiple' selection mode
     * @example `dateMaxCount: 3` // Limits selection to 3 dates when in multiple mode
     */
    dateMaxCount;
    /** Number of months to display simultaneously in the date picker overlay
     * Consider adjusting dateOverlayWidth accordingly for better display
     * @example `dateNumberOfMonths: 2` // Shows two months side by side in the overlay
     * @default 1
     */
    dateNumberOfMonths;
    /** Width of the date picker overlay panel
     * @example `dateOverlayWidth: '400px'` // Sets the overlay width to 400 pixels
     * @default '500px'
     */
    dateOverlayWidth;
    /** Should the date input be read-only, preventing manual typing
     * @example `dateReadonlyInput: true` // Users can only select dates via the picker, not type them
     * @default false
     */
    dateReadonlyInput;
    /**
     * PrimeNG calendar mode: 'single' for one date, 'multiple' for several dates, 'range' for date range
     * @default 'single'
     * @example `dateSelectionMode: 'range'` // Allows selecting a start and end date
     */
    dateSelectionMode;
    /** Should the date picker show seconds in addition to hours and minutes
     * @example `dateShowSeconds: true` // Displays seconds selector in time selection
     */
    dateShowSeconds;
    /**
     * Should the date picker show time selection in addition to date
     * Applicable only when dateSelectionMode is not defined or 'single'
     * @example `dateShowTime: true` // Shows hour and minute selectors
     */
    dateShowTime;
    /** If true, only time selection will be shown without date
     * @example `dateTimeOnly: true` // Displays only time picker
     */
    dateTimeOnly;
    /** Step increment for hours in time selection
     * @example `dateStepHours: 2` // Hours will increment in steps of 2
     */
    dateStepHours;
    /** Step increment for minutes in time selection
     * @example `dateStepMinutes: 15` // Minutes will increment in steps of 15
     */
    dateStepMinutes;
    /** Initial view mode for the date picker: 'date', 'month', or 'year'
     * @default 'date'
     * @example `dateViewMode: 'year'` // Opens the calendar in year selection mode
     */
    dateViewMode;
    /**
     * Defines the default value for an input when the form is initialized
     * @example `defaultValue: 'admin@example.com'` // Pre-fills the input with this value
     */
    defaultValue;
    /**
     * Should the control be disabled (visible but not editable)
     * @example `disabled: true` // Control is grayed out and cannot be modified
     */
    disabled;
    /**
     * @deprecated
     * Non applicable property - this will have no effect
     * If set to true, will force the control to always reset to the default value
     * @example `forceDefaultValue: true` // Control value will be reset to defaultValue on form reset
     */
    forceDefaultValue;
    /**
     * Help text to display under the field to provide additional guidance
     * @example `helpText: 'Password must contain at least 8 characters with one uppercase letter'`
     */
    helpText;
    /**
     * Should the control be hidden from the form
     * @example `hidden: true` // Control won't be displayed but will still be part of the form
     */
    hidden;
    /**
     * Displays an icon in the left side of the input using PrimeNG icon classes
     * @example `inputIcon: 'pi pi-user'` // Shows a user icon inside the input field
     */
    inputIcon;
    /** If true, allows clearing the field. Applicable for: number inputs, radio buttons, dropdowns, and autocomplete
     * @example `isClearable: true` // Shows a clear icon
     * @default true
     */
    isClearable;
    /** If true, will prevent the options panel to show on focus */
    isCompleteOnFocusDisabled;
    /**
     * Should the control be a FormArray instance for handling multiple values
     * @example `isFormArray: true` // Creates a FormArray instead of a FormControl
     */
    isFormArray;
    /** If true, allows toggling between rich text and HTML source view in rich text editors
     * @example `isHtmlToggleable: true` // Shows a button to switch to HTML view
     */
    isHtmlToggleable;
    /**
     * When enabled, allows user to create and select a new option in autocomplete when no results match
     * @example `isOptionCreationEnabled: true` // User can type a new value and it will be added as an option
     */
    isOptionCreationEnabled;
    /** Enables a "Select All" option in multi-select controls
     * @default true
     * @example `isSelectAllEnabled: true` // Adds a "Select All" checkbox to select/deselect all options
     */
    isSelectAllEnabled;
    /**
     * If the control should have a different label than the main label defined in CrudItemOptions
     * @example `label: 'Custom Field Name'` // Overrides the default label from CrudItemOptions
     */
    label;
    /**
     * Defines the max value for an input of type number - should be used with corresponding validator
     * @example `max: 100` // Input value cannot exceed 100, use with Validators.max(100)
     */
    max;
    /** Maximum number of fraction digits to display for number inputs */
    maxFractionDigits;
    /**
     * Defines the max length for an input - should be used with corresponding validator
     * @example `maxLength: 50` // Input limited to 50 characters, use with Validators.maxLength(50)
     */
    maxLength;
    /**
     * Specifies the maximum number of selected labels in a multi-select control
     * @example `maxSelectedLabels: 5` // Multi-select will show up to 5 selected labels before collapsing
     * @default undefined
     */
    maxSelectedLabels;
    /**
     * Specifies a maximum width for the control, defaults to 50%
     * @example `maxWidth: '80%'` // Control will not exceed 80% of container width
     */
    maxWidth;
    /**
     * Defines the min value for an input of type number - should be used with corresponding validator
     * @example `min: 100` // Input value cannot be less than 100, use with Validators.min(100)
     */
    min;
    /** Minimum number of fraction digits to display for number inputs */
    minFractionDigits;
    /**
     * Defines the min length for an input - should be used with corresponding validator
     * @example `minLength: 3` // Input requires at least 3 characters, use with Validators.minLength(3)
     */
    minLength;
    /**
     * Specifies a minimum width for the control, defaults to 50%
     * @example `minWidth: '300px'` // Control will be at least 300px wide
     */
    minWidth;
    /**
     * Enables multiple selection for select button controls - allows selecting multiple options simultaneously
     * @example `multipleSelectButton: true` // User can select multiple button options at once
     */
    multipleSelectButton;
    /**
     * Allows deselecting/toggling select button options - enables clicking to unselect a previously selected option
     * @example `isSelectButtonOptionToggleable: true` // User can click a selected button to deselect it
     */
    isSelectButtonOptionToggleable;
    /**
     * Placeholder text to display when the control has no value
     * @example `placeholder: 'Select an option'`
     */
    placeholder;
    /** Direction for radio button options layout - 'row' for horizontal, 'column' for vertical
     * @example `radioOptionsDirection: 'row'` // Displays radio buttons in a horizontal row
     */
    radioOptionsDirection;
    /**
     * Specifies if the FormControl should be non-nullable (cannot have null values)
     * @example `nonNullable: true` // FormControl will reject null values and use default value instead
     */
    nonNullable;
    /**
     * Defines the method to trigger for autocomplete suggestions - returns observable of options
     * @example `searchOptionsFn: (term) => this.userService.searchUsers(term)`
     */
    searchOptionsFn;
    /** Step value for number inputs - defines the increment/decrement step */
    step;
    /** CSS class to apply to the form field wrapper component for styling purposes */
    styleClass;
    /**
     * Columns to display when using TABLE control type - defines the table structure
     * @example `tableCtrlColumns: [
     *   { key: 'name', label: 'Name', controlType: CONTROL_TYPES.INPUT, type: INPUT_TYPES.TEXT },
     *   { key: 'age', label: 'Age', controlType: CONTROL_TYPES.INPUT, type: INPUT_TYPES.NUMBER }
     * ]`
     * @note Validators only handle 'required' at the moment for table-control columns
     */
    tableCtrlColumns;
    /**
     * Store advanced configuration for table controls such as pagination, sorting, etc.
     * @example `tableCtrlConfig: { paginator: true, rows: 10, sortable: true }`
     */
    tableCtrlConfig;
    /** Height of the rich text editor control
     * @example `richTextEditorHeight: '300px'` // Sets the editor height to 300 pixels
     */
    textEditorHeight;
    /**
     * Optional tooltip label that appears when hovering over the control
     * @example `tooltipLabel: 'Enter your email address used for notifications'`
     */
    tooltipLabel;
    /** Whether to use grouping separators (e.g., thousands separators) for number inputs
     * @default false
     * @example `useNumberGrouping: true` // Displays numbers with grouping separators
     */
    useNumberGrouping;
    /**
     * Specifies validators for form control
     *
     * When enabled on a simple FormControl, the validator will be applied on the control
     *
     * When enabled on a array control, the validator will be applied on each child
     * @example `validators: [Validators.required]` // or use `required` shared validator.
     */
    validators;
    /**
     * Specifies a fixed width for the control, will set both minWidth and maxWidth
     * @example `width: '250px'` // Control will be exactly 250px wide
     */
    width;
    /**
     * Specifies the media type for the control of type FILES
     * @example `mediaType: 'image'` // Control will accept image files
     */
    mediaType;
    /**
     * Whether to enable preview for uploaded files
     * @example `isPreviewEnabled: true` // Enables preview for uploaded images
     */
    isPreviewEnabled;
    /**
     * Can the file input control accept multiple files for upload
     * @example `multiple: true` // User can select and upload multiple files at once
     */
    multiple;
    /**
     * Maximum file size allowed in bytes
     * Will produce a form error when exceeded
     * @example `maxFileSize: 8000000` // Limits file size to 8MB
     */
    maxFileSize;
}

const CONTROL_TYPES = {
    AUTOCOMPLETE: "autocomplete",
    CHECKBOX: "checkbox",
    CUSTOM: "custom",
    DATE: "date",
    FILES: "files",
    GROUP: "group", // Stores nested formGroups
    INPUT: "input",
    MULTISELECT: "multiselect",
    PICKLIST: "picklist",
    RADIO: "radio",
    SELECT: "select",
    SELECT_BUTTON: "select_button",
    TABLE: "table",
    TEXTAREA: "textarea",
    WYSIWYG: "wysiwyg",
};

class CrudItemBase {
    id = null;
    archived = false;
    archivedAt = null;
    updatedAt = null;
    updaterId = null;
    updaterName = null;
    createdAt = null;
    creatorId = null;
    creatorName = null;
}

const INPUT_TYPES = {
    TEXT: "text",
    NUMBER: "number",
};

class CrudButtonComponent {
    /** Template type of the button */
    type = input.required(...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /** Is the button disabled */
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Is the button loading */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    /** Label of the button, if not provide, the default label will be used */
    label = input("", ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Icons */
    icon = input(...(ngDevMode ? [undefined, { debugName: "icon" }] : /* istanbul ignore next */ []));
    /** Optional color for the button */
    severity = input(...(ngDevMode ? [undefined, { debugName: "severity" }] : /* istanbul ignore next */ []));
    /** Event emitted each time the button is clicked */
    clicked = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CrudButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: CrudButtonComponent, isStandalone: true, selector: "crd-crud-button", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clicked: "clicked" }, host: { styleAttribute: "margin: 0 0.25rem" }, ngImport: i0, template: "@switch (type()) {\n    @case (\"validate\") {\n        <p-button\n            [label]=\"label() ? label() : 'Valider'\"\n            [icon]=\"icon() ? icon() : ''\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [disabled]=\"disabled()\"\n            [loading]=\"loading()\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"validate-button\"\n        />\n    }\n    @case (\"cancel\") {\n        <p-button pRipple    \n            [label]=\"label() ? label() : 'Annuler'\"\n            [disabled]=\"disabled()\"\n            [loading]=\"loading()\"\n            [icon]=\"icon() ? icon() : 'pi pi-times'\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            icon=\"pi pi-times\"\n            iconPos=\"left\"\n            text\n            outlined\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"cancel-button\"\n        />\n    }\n    @case (\"delete\") {\n        <p-button pRipple\n            outlined\n            [label]=\"label() ? label() : 'Supprimer'\"\n            [disabled]=\"disabled()\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [loading]=\"loading()\"\n            [icon]=\"icon() ? icon() : ''\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"delete-button\"\n        />\n    }\n    @case (\"restore\") {\n        <p-button pRipple\n            outlined\n            [label]=\"label() ? label() : 'Restaurer'\"\n            [disabled]=\"disabled()\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [loading]=\"loading()\"\n            [icon]=\"icon() ? icon() : ''\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"restore-button\"\n        />\n    }\n    @case (\"edit\") {\n        <p-button pRipple\n            [outlined]=\"true\"\n            [label]=\"label() ? label() : 'Modifier'\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [disabled]=\"disabled()\"\n            [loading]=\"loading()\"\n            [icon]=\"icon() ? icon() : ''\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"edit-button\"\n        />\n    }\n    @case (\"simple-icon\") {\n        <p-button pRipple\n            text\n            [icon]=\"icon()\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [disabled]=\"disabled()\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"simple-icon-button\"\n        />\n    }\n}", dependencies: [{ kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i1.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CrudButtonComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, imports: [ButtonModule], selector: "crd-crud-button", host: { style: "margin: 0 0.25rem" }, template: "@switch (type()) {\n    @case (\"validate\") {\n        <p-button\n            [label]=\"label() ? label() : 'Valider'\"\n            [icon]=\"icon() ? icon() : ''\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [disabled]=\"disabled()\"\n            [loading]=\"loading()\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"validate-button\"\n        />\n    }\n    @case (\"cancel\") {\n        <p-button pRipple    \n            [label]=\"label() ? label() : 'Annuler'\"\n            [disabled]=\"disabled()\"\n            [loading]=\"loading()\"\n            [icon]=\"icon() ? icon() : 'pi pi-times'\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            icon=\"pi pi-times\"\n            iconPos=\"left\"\n            text\n            outlined\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"cancel-button\"\n        />\n    }\n    @case (\"delete\") {\n        <p-button pRipple\n            outlined\n            [label]=\"label() ? label() : 'Supprimer'\"\n            [disabled]=\"disabled()\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [loading]=\"loading()\"\n            [icon]=\"icon() ? icon() : ''\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"delete-button\"\n        />\n    }\n    @case (\"restore\") {\n        <p-button pRipple\n            outlined\n            [label]=\"label() ? label() : 'Restaurer'\"\n            [disabled]=\"disabled()\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [loading]=\"loading()\"\n            [icon]=\"icon() ? icon() : ''\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"restore-button\"\n        />\n    }\n    @case (\"edit\") {\n        <p-button pRipple\n            [outlined]=\"true\"\n            [label]=\"label() ? label() : 'Modifier'\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [disabled]=\"disabled()\"\n            [loading]=\"loading()\"\n            [icon]=\"icon() ? icon() : ''\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"edit-button\"\n        />\n    }\n    @case (\"simple-icon\") {\n        <p-button pRipple\n            text\n            [icon]=\"icon()\"\n            [severity]=\"severity() ? severity() : 'primary'\"\n            [disabled]=\"disabled()\"\n            (onClick)=\"clicked.emit()\"\n            data-testid=\"simple-icon-button\"\n        />\n    }\n}" }]
        }], propDecorators: { type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }], clicked: [{ type: i0.Output, args: ["clicked"] }] } });

const isEqual = (val1, val2) => {
    return JSON.stringify(val1) === JSON.stringify(val2);
};

const DEFAULT_CRUD_LABELS = {
    toolbar: {
        export: "Exporter les données",
        configureColumns: "Configurer les colonnes",
        refresh: "Rafraîchir les données",
    },
    exportDialog: {
        header: "Exporter les données",
        chooseFormat: "Choisir le format",
        chooseData: "Quelles données ?",
        all: "Tout",
        selection: "Sélection",
        cancel: "Annuler",
        export: "Exporter",
    },
    columnsDialog: {
        header: "Gestion des colonnes",
        cancel: "Annuler",
        save: "Valider",
    },
    columnsViews: {
        title: "Vues",
        add: "Ajouter",
        delete: "Supprimer",
        validate: "Valider",
        cancel: "Annuler",
        deleteConfirmation: "Êtes-vous sûr de vouloir supprimer cette vue ?",
    },
    tableActions: {
        edit: "Editer",
        delete: "Supprimer",
    },
    tableControl: {
        add: "Ajouter",
        delete: "Supprimer",
        noData: "Aucune donnée",
        actionsColumnHeader: "Actions",
        multiselectValidate: "Valider",
        multiselectUnsavedChanges: "Pensez à valider vos modifications",
    },
    history: {
        restore: "Restaurer",
        updatedAt: "Mis à jour le",
        updatedBy: "Mis à jour par",
        property: "Propriété",
        value: "Valeur",
        previousValue: "Ancienne valeur",
        showPreviousValue: "Afficher l'ancienne valeur",
        noChanges: "Aucun changement",
    },
    editionDialog: {
        historyHeader: "Historique des modifications",
        archive: "Archiver",
        validate: "Valider",
        modeCreate: "Création",
        modeConsult: "Consultation",
        modeEdit: "Édition",
        cancel: "Annuler",
        close: "Fermer",
    },
    form: {
        reset: "Réinitialiser",
        submit: "Valider",
        noFields: "Aucun champ disponible",
    },
    arrayElement: {
        delete: "Supprimer",
    },
    picklist: {
        sourceHeader: "Disponibles",
        targetHeader: "Choix",
    },
    dateControl: {
        close: "Fermer",
        clear: "Effacer",
        today: "Aujourd'hui",
        validate: "Valider",
    },
    richTextEditor: {
        editHtml: "Editer HTML",
    },
    fileUpload: {
        chooseFile: "Choisir un fichier",
        dragDropLabel: "Glissez-déposez vos fichiers ici, ou cliquez pour sélectionner",
        uploadedFilesTitle: "Fichiers téléchargés",
        canAddMore: "Vous pouvez ajouter plusieurs fichiers.",
        cannotAddMore: "Vous ne pouvez ajouter qu'un seul fichier. Veuillez supprimer le fichier actuel pour en ajouter un nouveau.",
        maxFileSizeExceeded: (fileName, maxFileSize) => `Le fichier "${fileName}" dépasse la taille maximale autorisée de ${maxFileSize} octets.`,
    },
    autocomplete: {
        newOption: "(nouveau)",
    },
    validators: {
        invalid: "La valeur saisie est invalide",
        required: "Ce champ est obligatoire",
        unknownValue: "Merci de sélectionner une des valeurs suggérées",
        emailInvalid: "L'email est invalide",
        minlength: "La valeur saisie est trop courte ({requiredLength} caractères minimum)",
        maxlength: "La valeur saisie est trop longue ({requiredLength} caractères maximum)",
        max: "La valeur doit être inférieure ou égale à {max}",
        min: "La valeur doit être supérieure ou égale à {min}",
        maxFileSize: "La taille du fichier dépasse la taille maximale autorisée",
    },
    patterns: {
        nameWithDashes: "Caractères autorisés : lettres, espaces et tirets",
        lettersWithSpaces: "Caractères autorisés : lettres et espaces",
        lettersWithoutSpaces: "Caractères autorisés : lettres",
        alphanumericalWithSpaces: "Caractères autorisés : lettres, chiffres et espaces",
        alphanumerical: "Caractères autorisés : lettres et chiffres",
        onlyCaps: "Caractères autorisés : majuscules et chiffres",
        integer: "Un nombre entier est requis",
        phoneNumber: "Format de numéro de téléphone non valide",
        withExtension: "L'extension du fichier est obligatoire",
    },
    archivedConfig: {
        label: "Archivé",
        labelAt: "Archivé le",
        archived: "Archivé",
        active: "Actif",
    },
    tableRegular: {
        currentPageReport: (first, last, total) => `De ${first} à ${last} sur ${total} élément(s)`,
    },
    table: {
        exportFailedTitle: "Echec de l'export",
        exportFailedDetail: "Une erreur est survenue lors de l'export des données.",
        deleteConfirmationSingle: "Etes-vous sûr de vouloir archiver cet élément ?",
        deleteConfirmationMultiple: (count) => `Etes-vous sûr de vouloir archiver ces ${count} éléments ?`,
        restoreConfirmationSingle: "Etes-vous sûr de vouloir restaurer cet élément ?",
        restoreConfirmationMultiple: (count) => `Etes-vous sûr de vouloir restaurer ces ${count} éléments ?`,
        confirmationHeader: "Confirmation",
        confirmationCancel: "Annuler",
        confirmationConfirm: "Confirmer",
        defaultViewName: "Default",
    },
    download: {
        noPdfPrintWarning: "Le fichier n'est pas un PDF, l'impression n'est pas disponible. Il sera téléchargé à la place.",
    },
    checkbox: {
        yes: "Oui",
        no: "Non",
    },
    auditConfig: {
        createdAt: "Créé le",
        createdBy: "Créé par",
        updatedAt: "Mis à jour le",
        updatedBy: "Mis à jour par",
    },
};
const CRUD_LABELS = new InjectionToken("CRUD_LABELS", {
    factory: () => {
        return DEFAULT_CRUD_LABELS;
    },
});
/**
 * Provides a partial translation override merged with the French defaults.
 * Only supply the sections/keys you want to change.
 *
 * @example
 * providers: [
 *   provideCrudLabels({
 *     toolbar: { export: 'Export data', refresh: 'Refresh' },
 *     tableActions: { edit: 'Edit', delete: 'Delete' },
 *   })
 * ]
 */
function provideCrudLabels(labels, primeNGTranslation) {
    const merged = Object.fromEntries(Object.keys(DEFAULT_CRUD_LABELS).map((key) => [
        key,
        { ...DEFAULT_CRUD_LABELS[key], ...(labels[key] ?? {}) },
    ]));
    const providers = [
        { provide: CRUD_LABELS, useValue: merged },
    ];
    if (primeNGTranslation) {
        providers.push(provideAppInitializer(() => {
            inject(PrimeNG).setTranslation(primeNGTranslation);
        }));
    }
    return providers;
}

/**
 * Replaces all interpolations in a string with format '{key}' by a value
 * defined in a object map 'key' => value.
 *
 * Based on supplant function by 'Douglas Crockford's Remedial JavaScript'
 *
 * Examples of usage:
 *
 *      supplant("I'm {age} years old!", { age: 29 });
 *      supplant("The {a} says {n}, {n}, {n}!", { a: 'cow', n: 'moo' });
 *
 * @param str string target in which do the replace
 * @param o an object with parameters to be interpolated
 */
const supplant = (str, o) => {
    return str.replace(/{([^{}]*)}/g, (a, b) => {
        const r = o[b];
        return typeof r === "string" || typeof r === "number" ? `${r}` : a;
    });
};

class FormBuilderService {
    toFormGroup(items, values, groupValidator, isReadonlyMode) {
        const group = new UntypedFormGroup({});
        for (const item of items) {
            const baseValue = values?.[item.key];
            // Form Group
            if (item.children?.length) {
                const formGroup = this.toFormGroup(item.children, baseValue, undefined, isReadonlyMode);
                group.addControl(item.key, formGroup);
                // Form Array
            }
            else if (item.controlOptions?.isFormArray) {
                const formArray = this.toFormArray(item, baseValue, isReadonlyMode);
                group.addControl(item.key, formArray);
                // Form Control
            }
            else {
                const value = this.getValue(item, baseValue);
                const formControl = this.toFormControl(item, value, isReadonlyMode);
                group.addControl(item.key, formControl);
            }
        }
        if (groupValidator) {
            group.setValidators(groupValidator);
        }
        return group;
    }
    toFormArray(item, values, isReadonlyMode) {
        // First we must validate that we are working on an array
        if (!isArray(values)) {
            throw Error(`Values provided for control ${item.key} are not a valid array: ${values}`);
        }
        const controls = values.map((value) => this.toFormControl(item, value, isReadonlyMode));
        return new FormArray(controls);
    }
    toFormControl(item, value, isReadonlyMode) {
        const { validators, asyncValidators, disabled, nonNullable } = this.getFormControlOptions(item, isReadonlyMode);
        return new FormControl({ value, disabled }, { validators, asyncValidators, nonNullable });
    }
    getValue(item, baseValue) {
        let value = baseValue;
        const { defaultValue } = item.controlOptions ?? {};
        if (isNil(value) || value === "") {
            value = defaultValue;
        }
        return value ?? null;
    }
    /**
     * Generates form control options including validators, async validators, disabled state, and non-nullability
     * based on the provided `CrudItemOptions` and the current readonly mode.
     *
     * @param item - The CRUD item options containing control configuration.
     * @param isReadonlyMode - Indicates if the form is in readonly mode.
     * @returns An object containing:
     *   - `validators`: An array of synchronous validator functions.
     *   - `asyncValidators`: An array of asynchronous validator functions.
     *   - `disabled`: Whether the control should be disabled.
     *   - `nonNullable`: Whether the control value should be non-nullable.
     */
    getFormControlOptions(item, isReadonlyMode) {
        let validators = [];
        let asyncValidators = [];
        const disabled = this.getDisableState(item.controlOptions ?? {}, isReadonlyMode);
        let nonNullable = false;
        const controlOptions = item.controlOptions;
        if (controlOptions) {
            validators = this.getValidators(controlOptions);
            asyncValidators = this.getAsyncValidators(controlOptions);
            nonNullable = controlOptions.nonNullable ?? false;
        }
        return { validators, asyncValidators, disabled, nonNullable };
    }
    getDisableState(controlOptions, isReadonlyMode) {
        return controlOptions.disabled || isReadonlyMode;
    }
    getValidators(controlOptions) {
        return controlOptions.validators?.length ? controlOptions.validators : [];
    }
    getAsyncValidators(controlOptions) {
        return controlOptions.asyncValidators?.length
            ? controlOptions.asyncValidators
            : [];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormBuilderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormBuilderService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormBuilderService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

/**
 * Base error messages for form validation.
 * Strings are provided via the CRUD_LABELS injection token.
 * This object is kept for backwards compatibility with customErrorMessages override.
 */
const BASE_FORM_ERROR_MESSAGES = {
    pattern: "{expected}",
};

const defaultValue = {
    customErrorMessages: {},
};
const APP_FORM_CONFIG = new InjectionToken("APP_FORM_CONFIG", {
    providedIn: "root",
    factory: () => defaultValue,
});

class FormErrorMessage {
    controlErrors = input.required(...(ngDevMode ? [{ debugName: "controlErrors" }] : /* istanbul ignore next */ []));
    customErrorMessages = inject(APP_FORM_CONFIG).customErrorMessages;
    labels = inject(CRUD_LABELS);
    errorMessage = computed(() => {
        const controlErrors = this.controlErrors() ?? {};
        const errorKeys = Object.keys(controlErrors);
        // No error keys: no errors to show
        if (!errorKeys.length)
            return "";
        // If control has errors, we show the first error
        const firstError = errorKeys[0];
        const errorContent = controlErrors[firstError];
        // errorContent is like: { requiredLength: 3, actualLength: 1 }
        if (errorContent) {
            const message = this.getMessage(firstError);
            // Enriches error message with error actual content
            return supplant(message, errorContent);
        }
        // Fallback to default message
        return this.getDefaultMessage();
    }, ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    // Merge base messages with custom messages
    messages = {
        ...BASE_FORM_ERROR_MESSAGES,
        ...this.labels.validators,
        ...this.customErrorMessages,
    };
    getMessage(key) {
        return this.messages[key] ?? this.getDefaultMessage();
    }
    getDefaultMessage() {
        return this.messages["invalid"] ?? "";
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormErrorMessage, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.7", type: FormErrorMessage, isStandalone: true, selector: "frm-error-message", inputs: { controlErrors: { classPropertyName: "controlErrors", publicName: "controlErrors", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `    
    @let message = errorMessage();
    <small class="control-error" [title]="message">
        {{ message }}
    </small>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormErrorMessage, decorators: [{
            type: Component,
            args: [{
                    selector: "frm-error-message",
                    template: `    
    @let message = errorMessage();
    <small class="control-error" [title]="message">
        {{ message }}
    </small>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { controlErrors: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlErrors", required: true }] }] } });

/** Validator to check if the value is required */
const required = Validators.required;
/** Validator to check if the value is true */
const requiredTrue = Validators.requiredTrue;
/** Validator to check if the value is greater than x */
const min = (x) => Validators.min(x);
/** Validator to check if the value is less than x */
const max = (x) => Validators.max(x);
/** Validator to check if the value has a length greater than x */
const minlength = (x) => Validators.minLength(x);
/** Validator to check if the value has a length less than x */
const maxlength = (x) => Validators.maxLength(x);

class FormFieldBaseComponent {
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    control = input.required(...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    isFormReadonly = input.required(...(ngDevMode ? [{ debugName: "isFormReadonly" }] : /* istanbul ignore next */ []));
    /**
     * Stores a incremental value to trigger change detection on the form field
     * Determines if the form field value should be synchronized with the model
     * Will be the default for every form control that use the reactive approach (e.g. [control])
     * But can be used for controls using template approach (e.g. [(ngModel)]), as Date and Radio controls.
     */
    syncValueInc = input(...(ngDevMode ? [undefined, { debugName: "syncValueInc" }] : /* istanbul ignore next */ []));
    fieldInteraction = output();
    isDisabled = computed(() => this.control().disabled, ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    options = computed(() => {
        return this.config().controlOptions ?? {};
    }, ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    placeholder = computed(() => {
        return this.options().placeholder ?? "";
    }, ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    isRequired = computed(() => {
        return (!!this.config().key &&
            (this.control().hasValidator(required) ||
                this.control().hasValidator(requiredTrue)));
    }, ...(ngDevMode ? [{ debugName: "isRequired" }] : /* istanbul ignore next */ []));
    label = computed(() => {
        return this.options().label ?? this.config().label;
    }, ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    selectOptions = computed(() => {
        return this.config().options ?? [];
    }, ...(ngDevMode ? [{ debugName: "selectOptions" }] : /* istanbul ignore next */ []));
    showClear = computed(() => {
        return this.options().isClearable ?? true;
    }, ...(ngDevMode ? [{ debugName: "showClear" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        // Display error in case of invalid form control
        const { value, valid } = this.control() || {};
        let hasValue = !!value;
        if (isArray(value)) {
            hasValue = value.length > 0;
        }
        if (hasValue && !valid) {
            this.control().markAsTouched();
        }
    }
    emitInteractionEvent(interactionType, extraData) {
        const event = this.buildInteractionEvent(interactionType, extraData);
        this.fieldInteraction.emit(event);
    }
    buildInteractionEvent(interactionType, extraData) {
        return {
            key: this.config().key,
            controlType: this.config().controlType,
            value: this.control().value,
            interactionType,
            timestamp: new Date(),
            extraData,
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormFieldBaseComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.7", type: FormFieldBaseComponent, isStandalone: true, selector: "frm-field-base", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, isFormReadonly: { classPropertyName: "isFormReadonly", publicName: "isFormReadonly", isSignal: true, isRequired: true, transformFunction: null }, syncValueInc: { classPropertyName: "syncValueInc", publicName: "syncValueInc", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { fieldInteraction: "fieldInteraction" }, ngImport: i0, template: "", isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormFieldBaseComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "frm-field-base",
                    template: "",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], control: [{ type: i0.Input, args: [{ isSignal: true, alias: "control", required: true }] }], isFormReadonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "isFormReadonly", required: true }] }], syncValueInc: [{ type: i0.Input, args: [{ isSignal: true, alias: "syncValueInc", required: false }] }], fieldInteraction: [{ type: i0.Output, args: ["fieldInteraction"] }] } });

const newOption = (query, subLabel) => [
    {
        value: query,
        label: query,
        extraData: {
            customLabelDisplay: {
                mainLabel: query,
                subLabel,
            },
        },
    },
];
class AutocompleteControlComponent extends FormFieldBaseComponent {
    labels = inject(CRUD_LABELS);
    autocomplete = viewChild(AutoComplete, ...(ngDevMode ? [{ debugName: "autocomplete" }] : /* istanbul ignore next */ []));
    isCompleteOnFocusDisabled = computed(() => this.options().isCompleteOnFocusDisabled ?? false, ...(ngDevMode ? [{ debugName: "isCompleteOnFocusDisabled" }] : /* istanbul ignore next */ []));
    isOptionCreationEnabled = computed(() => this.options().isOptionCreationEnabled ?? false, ...(ngDevMode ? [{ debugName: "isOptionCreationEnabled" }] : /* istanbul ignore next */ []));
    autocompleteQuery$ = new BehaviorSubject("");
    autocompleteSuggestions$ = this.autocompleteQuery$.pipe(switchMap((query) => {
        const searchFunction = this.options()?.searchOptionsFn;
        if (!searchFunction) {
            const filteredOptions = (this.selectOptions() ?? []).filter((opt) => opt.label?.toLowerCase().includes(query.toLowerCase()));
            return of(filteredOptions);
        }
        return searchFunction(query).pipe(catchError(() => of([])));
    }), map((options) => {
        const query = this.autocompleteQuery$.getValue();
        if (this.isOptionCreationEnabled() && !options.length && query.trim()) {
            return newOption(query, this.labels.autocomplete.newOption);
        }
        return this.getActiveSuggestionsOnly(options);
    }), tap((suggestions) => {
        this.writeAsyncValue(suggestions);
    }));
    /**
     * Updates the autocomplete input with the label of the currently selected option
     * when there are no base select options and asynchronous suggestions are available.
     *
     * @param suggestions - An array of `SelectItem` objects representing asynchronous suggestions.
     *
     * The method checks if there are no base select options and if there are asynchronous suggestions.
     * If so, it finds the suggestion matching the current control value and writes its label
     * to the autocomplete input, ensuring the displayed value matches the selected option.
     */
    writeAsyncValue(suggestions) {
        const hasNoBaseSelectOptions = !this.selectOptions()?.length;
        const hasAsyncSuggestions = suggestions.length > 0;
        if (hasNoBaseSelectOptions && hasAsyncSuggestions) {
            const selectedOption = suggestions.find((option) => option.value === this.control().value);
            const autocomplete = this.autocomplete();
            if (selectedOption && autocomplete) {
                autocomplete.writeValue(selectedOption.label);
            }
        }
    }
    getActiveSuggestionsOnly(options) {
        const selectedValue = this.control().value;
        const selectedOption = options.find((option) => option.value === selectedValue);
        const activeSuggestions = options.filter((option) => !option.disabled);
        if (selectedOption?.disabled) {
            activeSuggestions.unshift(selectedOption);
        }
        return activeSuggestions;
    }
    handleOnAutocomplete(event) {
        this.autocompleteQuery$.next(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: AutocompleteControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: AutocompleteControlComponent, isStandalone: true, selector: "frm-autocomplete-control", viewQueries: [{ propertyName: "autocomplete", first: true, predicate: AutoComplete, descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "@let suggestions = autocompleteSuggestions$ | async;\n@let id = config().key.toString();\n<p-autoComplete\n    #autocomplete\n    [id]=\"id\"\n    [formControl]=\"control()\"\n    [placeholder]=\"placeholder()\"\n    [suggestions]=\"suggestions ?? []\"\n    [forceSelection]=\"true\"\n    [showClear]=\"showClear() && !isRequired() && !options().autocompleteMultiple\"\n    [completeOnFocus]=\"!isCompleteOnFocusDisabled()\"\n    (completeMethod)=\"handleOnAutocomplete($event.query)\"\n    [minQueryLength]=\"options().autocompleteMinQueryLength\"\n    [delay]=\"options().autocompleteDelay\"\n    [multiple]=\"options().autocompleteMultiple\"\n    [dropdown]=\"options().autocompleteDropdown\"\n    [scrollHeight]=\"options().autocompleteScrollHeight ?? '200px'\"\n    (onSelect)=\"emitInteractionEvent('select')\"\n    (onKeyUp)=\"emitInteractionEvent('keyup')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onClear)=\"emitInteractionEvent('clear')\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onShow)=\"emitInteractionEvent('panelOpen')\"\n    (onHide)=\"emitInteractionEvent('panelClose')\"\n    scrollHeight=\"200px\"\n    optionValue=\"value\"\n    optionLabel=\"label\"\n    appendTo=\"body\">\n    <!-- selected item template does not work... https://github.com/primefaces/primeng/issues/2242 -->\n    <ng-template let-option #selecteditem>\n        <div class=\"flex align-items-center\">\n            @if (options().inputIcon) {\n                <i [class]=\"options().inputIcon\" class=\"mr-2\"></i>\n            }\n            @if (option.icon) {\n                <span [innerHtml]=\"option.icon\" class=\"mr-2\"></span>\n            }\n            <span>{{ option.label }}</span>\n        </div>\n    </ng-template>\n    <ng-template let-option pTemplate=\"item\">\n        <div class=\"flex\">\n            @if (option.icon) {\n                <span [innerHtml]=\"option.icon\" class=\"mr-2\"></span>\n            }\n            @if (option.extraData?.customLabelDisplay) {\n                @let customLabelDisplay = option.extraData.customLabelDisplay;\n                <span>\n                    {{ customLabelDisplay.mainLabel }} - \n                    <span class=\"text-400\">{{customLabelDisplay.subLabel}}</span>\n                </span>\n            } @else {\n                <span>{{ option.label }}</span>\n            }\n        </div>\n    </ng-template>\n</p-autoComplete>", dependencies: [{ kind: "ngmodule", type: AutoCompleteModule }, { kind: "component", type: i1$1.AutoComplete, selector: "p-autoComplete, p-autocomplete, p-auto-complete", inputs: ["minLength", "minQueryLength", "delay", "panelStyle", "styleClass", "panelStyleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "readonly", "scrollHeight", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "autoHighlight", "forceSelection", "type", "autoZIndex", "baseZIndex", "ariaLabel", "dropdownAriaLabel", "ariaLabelledBy", "dropdownIcon", "unique", "group", "completeOnFocus", "showClear", "dropdown", "showEmptyMessage", "dropdownMode", "multiple", "addOnTab", "tabindex", "dataKey", "emptyMessage", "showTransitionOptions", "hideTransitionOptions", "autofocus", "autocomplete", "optionGroupChildren", "optionGroupLabel", "overlayOptions", "suggestions", "optionLabel", "optionValue", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "selectOnFocus", "searchLocale", "optionDisabled", "focusOnHover", "typeahead", "addOnBlur", "separator", "appendTo", "motionOptions"], outputs: ["completeMethod", "onSelect", "onUnselect", "onAdd", "onFocus", "onBlur", "onDropdownClick", "onClear", "onInputKeydown", "onKeyUp", "onShow", "onHide", "onLazyLoad"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: AutocompleteControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-autocomplete-control", imports: [AutoCompleteModule, ReactiveFormsModule, AsyncPipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "@let suggestions = autocompleteSuggestions$ | async;\n@let id = config().key.toString();\n<p-autoComplete\n    #autocomplete\n    [id]=\"id\"\n    [formControl]=\"control()\"\n    [placeholder]=\"placeholder()\"\n    [suggestions]=\"suggestions ?? []\"\n    [forceSelection]=\"true\"\n    [showClear]=\"showClear() && !isRequired() && !options().autocompleteMultiple\"\n    [completeOnFocus]=\"!isCompleteOnFocusDisabled()\"\n    (completeMethod)=\"handleOnAutocomplete($event.query)\"\n    [minQueryLength]=\"options().autocompleteMinQueryLength\"\n    [delay]=\"options().autocompleteDelay\"\n    [multiple]=\"options().autocompleteMultiple\"\n    [dropdown]=\"options().autocompleteDropdown\"\n    [scrollHeight]=\"options().autocompleteScrollHeight ?? '200px'\"\n    (onSelect)=\"emitInteractionEvent('select')\"\n    (onKeyUp)=\"emitInteractionEvent('keyup')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onClear)=\"emitInteractionEvent('clear')\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onShow)=\"emitInteractionEvent('panelOpen')\"\n    (onHide)=\"emitInteractionEvent('panelClose')\"\n    scrollHeight=\"200px\"\n    optionValue=\"value\"\n    optionLabel=\"label\"\n    appendTo=\"body\">\n    <!-- selected item template does not work... https://github.com/primefaces/primeng/issues/2242 -->\n    <ng-template let-option #selecteditem>\n        <div class=\"flex align-items-center\">\n            @if (options().inputIcon) {\n                <i [class]=\"options().inputIcon\" class=\"mr-2\"></i>\n            }\n            @if (option.icon) {\n                <span [innerHtml]=\"option.icon\" class=\"mr-2\"></span>\n            }\n            <span>{{ option.label }}</span>\n        </div>\n    </ng-template>\n    <ng-template let-option pTemplate=\"item\">\n        <div class=\"flex\">\n            @if (option.icon) {\n                <span [innerHtml]=\"option.icon\" class=\"mr-2\"></span>\n            }\n            @if (option.extraData?.customLabelDisplay) {\n                @let customLabelDisplay = option.extraData.customLabelDisplay;\n                <span>\n                    {{ customLabelDisplay.mainLabel }} - \n                    <span class=\"text-400\">{{customLabelDisplay.subLabel}}</span>\n                </span>\n            } @else {\n                <span>{{ option.label }}</span>\n            }\n        </div>\n    </ng-template>\n</p-autoComplete>" }]
        }], propDecorators: { autocomplete: [{ type: i0.ViewChild, args: [i0.forwardRef(() => AutoComplete), { isSignal: true }] }] } });

class CheckboxControlComponent extends FormFieldBaseComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CheckboxControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.7", type: CheckboxControlComponent, isStandalone: true, selector: "frm-checkbox-control", usesInheritance: true, ngImport: i0, template: "<div class=\"checkbox-container p-inputtext p-component\"\n    [class.p-disabled]=\"isDisabled()\">\n    <p-checkbox \n        [formControl]=\"control()\"\n        [binary]=\"true\"\n        class=\"checkbox-input\"\n        [id]=\"config().key\"\n        (onChange)=\"emitInteractionEvent('valueChange')\"\n        (onBlur)=\"emitInteractionEvent('blur')\"\n        (onFocus)=\"emitInteractionEvent('focus')\"\n    />\n</div>", styles: [".checkbox-container{padding-block:4px var(--p-inputtext-padding-y)}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: CheckboxModule }, { kind: "component", type: i2$2.Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CheckboxControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-checkbox-control", imports: [ReactiveFormsModule, CheckboxModule], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<div class=\"checkbox-container p-inputtext p-component\"\n    [class.p-disabled]=\"isDisabled()\">\n    <p-checkbox \n        [formControl]=\"control()\"\n        [binary]=\"true\"\n        class=\"checkbox-input\"\n        [id]=\"config().key\"\n        (onChange)=\"emitInteractionEvent('valueChange')\"\n        (onBlur)=\"emitInteractionEvent('blur')\"\n        (onFocus)=\"emitInteractionEvent('focus')\"\n    />\n</div>", styles: [".checkbox-container{padding-block:4px var(--p-inputtext-padding-y)}\n"] }]
        }] });

const DATE_FORMAT = "yyyy-MM-dd";
const DATE_WITH_TIME_FORMAT = "yyyy-MM-dd HH:mm";
const DATE_WITH_SECONDS_FORMAT = "yyyy-MM-dd HH:mm:ss";
const DATE_FORMAT_CALENDAR = "yy-mm-dd";
const getMidnightTimeStamp = (value) => {
    let date = value;
    if (typeof date === "string") {
        date = new Date(date);
    }
    return date ? date.setHours(0, 0, 0, 0) : null;
};
const getDateRangeWithoutTime = (dateRange) => {
    const [from, to] = dateRange;
    const userTimezoneOffset = from.getTimezoneOffset() * 60000;
    const fromTimeStamp = getMidnightTimeStamp(from);
    let toTimeStamp = getMidnightTimeStamp(to);
    if (!fromTimeStamp) {
        return [];
    }
    // If no end is defined, set it to start date at 23:00:00
    if (!toTimeStamp) {
        const oneDay = 23 * 60 * 60 * 1000;
        toTimeStamp = fromTimeStamp + oneDay;
    }
    const start = new Date(fromTimeStamp - userTimezoneOffset);
    const end = toTimeStamp ? new Date(toTimeStamp - userTimezoneOffset) : null;
    return [start, end];
};
const canBeDate = (d) => {
    if (isString(d) || isNumber(d)) {
        return true;
    }
    if (isDate(d)) {
        return !Number.isNaN(d.getTime());
    }
    return false;
};
const isValidDateString = (value) => {
    if (!isString(value)) {
        return false;
    }
    const timestamp = Date.parse(value);
    if (Number.isNaN(timestamp)) {
        return false;
    }
    return true;
};
const formatDate = (value, withTime = false) => {
    const format = withTime ? DATE_WITH_TIME_FORMAT : DATE_FORMAT;
    return formatDate$1(value, format, "fr-FR");
};
const getDifferenceInDays = (date1, date2) => {
    const oneDay = 24 * 60 * 60 * 1000;
    const diffInTime = date2.setHours(0, 0, 0, 0) - date1.setHours(0, 0, 0, 0);
    return Math.round(diffInTime / oneDay);
};

class DateControlComponent extends FormFieldBaseComponent {
    labels = inject(CRUD_LABELS);
    setDateEffect = effect(() => {
        const _trigger = this.syncValueInc(); // trigger effect on syncValueInc change
        const value = this.control().value;
        this.computeDateValue(value);
        this.manualDateSet(this.dateValue);
    }, ...(ngDevMode ? [{ debugName: "setDateEffect" }] : /* istanbul ignore next */ []));
    dateSelectionMode = computed(() => this.options().dateSelectionMode || "single", ...(ngDevMode ? [{ debugName: "dateSelectionMode" }] : /* istanbul ignore next */ []));
    dateShowTime = computed(() => this.options().dateShowTime === true &&
        this.dateSelectionMode() === "single", ...(ngDevMode ? [{ debugName: "dateShowTime" }] : /* istanbul ignore next */ []));
    dateFormat = computed(() => {
        const customFormat = this.options().dateFormat;
        if (customFormat) {
            return customFormat;
        }
        if (this.options().dateViewMode === "month") {
            return "mm/yy";
        }
        if (this.options().dateViewMode === "year") {
            return "yy";
        }
        return DATE_FORMAT_CALENDAR;
    }, ...(ngDevMode ? [{ debugName: "dateFormat" }] : /* istanbul ignore next */ []));
    dateOverlayWidth = computed(() => {
        // custom width
        if (this.options().dateOverlayWidth) {
            return this.options().dateOverlayWidth;
        }
        // default
        return this.options().dateTimeOnly ? "200px" : "500px";
    }, ...(ngDevMode ? [{ debugName: "dateOverlayWidth" }] : /* istanbul ignore next */ []));
    dateValue = "";
    onDateTyped(event) {
        if (this.options().dateSelectionMode === "range") {
            return;
        }
        const value = event.target.value;
        const validDateLength = 10;
        if (value.length !== validDateLength) {
            this.manualDateSet(null);
        }
        else {
            this.manualDateSet(new Date(value));
        }
    }
    selectToday() {
        const today = new Date();
        this.computeDateValue(today);
        this.onDateSelected();
    }
    onDateSelected() {
        this.manualDateSet(this.dateValue);
        this.emitInteractionEvent("valueChange");
        this.control().markAsTouched();
        this.control().markAsDirty();
    }
    onDateCleared() {
        this.manualDateSet(null);
        this.emitInteractionEvent("clear");
        this.control().markAsTouched();
        this.control().markAsDirty();
    }
    manualDateSet(value) {
        const newValue = this.getTimeFromControl(value);
        this.control().setValue(newValue);
    }
    getTimeFromControl(value) {
        if (!value) {
            return null;
        }
        if (value instanceof Date) {
            return value.getTime();
        }
        return value.map((v) => (v ? new Date(v).getTime() : null));
    }
    computeDateValue(value) {
        switch (this.dateSelectionMode()) {
            case "single": {
                if (isArray(value)) {
                    this.dateValue = value.length ? new Date(value[0]) : "";
                }
                else {
                    this.dateValue = value ? new Date(value) : "";
                }
                break;
            }
            // Multiple and range modes both use array of dates
            default: {
                if (isArray(value)) {
                    const dates = value;
                    this.dateValue = dates.map((v) => new Date(v));
                }
                else {
                    this.dateValue = value ? [new Date(value)] : [];
                }
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: DateControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: DateControlComponent, isStandalone: true, selector: "frm-date-control", usesInheritance: true, ngImport: i0, template: "<p-datepicker #calendar\n  [(ngModel)]=\"dateValue\"\n  appendTo=\"body\"\n  [dateFormat]=\"dateFormat()\"\n  [selectionMode]=\"dateSelectionMode()\"\n  [showTime]=\"dateShowTime()\"\n  [timeOnly]=\"options().dateTimeOnly\"\n  [showSeconds]=\"options().dateShowSeconds\"\n  [stepHour]=\"options().dateStepHours ?? 1\"\n  [stepMinute]=\"options().dateStepMinutes ?? 1\"\n  [panelStyle]=\"{width: dateOverlayWidth() }\"\n  [hideOnDateTimeSelect]=\"options().dateHideOverlayOnSelect ?? false\"\n  [firstDayOfWeek]=\"1\"\n  [minDate]=\"options().dateMin\"\n  [maxDate]=\"options().dateMax\"\n  [maxDateCount]=\"options().dateMaxCount\"\n  [disabledDates]=\"options().dateDisabledDates ?? []\"\n  [disabledDays]=\"options().dateDisabledDays ?? []\"\n  [numberOfMonths]=\"options().dateNumberOfMonths ?? 1\"\n  [view]=\"options().dateViewMode ?? 'date'\"\n  [readonlyInput]=\"options().dateReadonlyInput ?? false\"\n  [disabled]=\"isDisabled()\"\n  (onInput)=\"onDateTyped($event)\"\n  (onSelect)=\"onDateSelected()\"\n  (onClearClick)=\"onDateCleared()\"\n  (onShow)=\"emitInteractionEvent('panelOpen')\"\n  (onClose)=\"emitInteractionEvent('panelClose')\">\n\n    <ng-template #footer>\n        <div class=\"calendar-footer\">  \n            <div>          \n                <p-button \n                    [label]=\"labels.dateControl.close\"\n                    [text]=\"true\"\n                    (click)=\"calendar.hideOverlay()\"\n                />\n                @if (!options().dateTimeOnly) {\n                    <p-button \n                        [label]=\"labels.dateControl.clear\"\n                        [text]=\"true\"\n                        severity=\"warn\"\n                        (click)=\"calendar.clear()\"\n                    />\n                }\n            </div>\n            <div>\n                @if (!options().dateTimeOnly) {\n                    <p-button \n                        [label]=\"labels.dateControl.today\" \n                        [outlined]=\"true\"\n                        (click)=\"selectToday()\"\n                    />\n                }\n                <p-button \n                    [label]=\"labels.dateControl.validate\" \n                    (click)=\"calendar.hideOverlay()\"\n                />\n            </div>\n        </div>\n    </ng-template>\n\n</p-datepicker>", styles: [".calendar-footer{display:flex;flex-wrap:wrap;justify-content:space-between}.calendar-footer p-button{margin-left:.5rem}\n"], dependencies: [{ kind: "ngmodule", type: DatePickerModule }, { kind: "component", type: i1$2.DatePicker, selector: "p-datePicker, p-datepicker, p-date-picker", inputs: ["iconDisplay", "styleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "ariaLabelledBy", "ariaLabel", "iconAriaLabel", "dateFormat", "multipleSeparator", "rangeSeparator", "inline", "showOtherMonths", "selectOtherMonths", "showIcon", "icon", "readonlyInput", "shortYearCutoff", "hourFormat", "timeOnly", "stepHour", "stepMinute", "stepSecond", "showSeconds", "showOnFocus", "showWeek", "startWeekFromFirstDayOfYear", "showClear", "dataType", "selectionMode", "maxDateCount", "showButtonBar", "todayButtonStyleClass", "clearButtonStyleClass", "autofocus", "autoZIndex", "baseZIndex", "panelStyleClass", "panelStyle", "keepInvalid", "hideOnDateTimeSelect", "touchUI", "timeSeparator", "focusTrap", "showTransitionOptions", "hideTransitionOptions", "tabindex", "minDate", "maxDate", "disabledDates", "disabledDays", "showTime", "responsiveOptions", "numberOfMonths", "firstDayOfWeek", "view", "defaultDate", "appendTo", "motionOptions"], outputs: ["onFocus", "onBlur", "onClose", "onSelect", "onClear", "onInput", "onTodayClick", "onClearClick", "onMonthChange", "onYearChange", "onClickOutside", "onShow"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: DividerModule }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i1.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: DateControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-date-control", encapsulation: ViewEncapsulation.None, imports: [
                        DatePickerModule,
                        FormsModule,
                        SharedModule,
                        DividerModule,
                        ButtonModule,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<p-datepicker #calendar\n  [(ngModel)]=\"dateValue\"\n  appendTo=\"body\"\n  [dateFormat]=\"dateFormat()\"\n  [selectionMode]=\"dateSelectionMode()\"\n  [showTime]=\"dateShowTime()\"\n  [timeOnly]=\"options().dateTimeOnly\"\n  [showSeconds]=\"options().dateShowSeconds\"\n  [stepHour]=\"options().dateStepHours ?? 1\"\n  [stepMinute]=\"options().dateStepMinutes ?? 1\"\n  [panelStyle]=\"{width: dateOverlayWidth() }\"\n  [hideOnDateTimeSelect]=\"options().dateHideOverlayOnSelect ?? false\"\n  [firstDayOfWeek]=\"1\"\n  [minDate]=\"options().dateMin\"\n  [maxDate]=\"options().dateMax\"\n  [maxDateCount]=\"options().dateMaxCount\"\n  [disabledDates]=\"options().dateDisabledDates ?? []\"\n  [disabledDays]=\"options().dateDisabledDays ?? []\"\n  [numberOfMonths]=\"options().dateNumberOfMonths ?? 1\"\n  [view]=\"options().dateViewMode ?? 'date'\"\n  [readonlyInput]=\"options().dateReadonlyInput ?? false\"\n  [disabled]=\"isDisabled()\"\n  (onInput)=\"onDateTyped($event)\"\n  (onSelect)=\"onDateSelected()\"\n  (onClearClick)=\"onDateCleared()\"\n  (onShow)=\"emitInteractionEvent('panelOpen')\"\n  (onClose)=\"emitInteractionEvent('panelClose')\">\n\n    <ng-template #footer>\n        <div class=\"calendar-footer\">  \n            <div>          \n                <p-button \n                    [label]=\"labels.dateControl.close\"\n                    [text]=\"true\"\n                    (click)=\"calendar.hideOverlay()\"\n                />\n                @if (!options().dateTimeOnly) {\n                    <p-button \n                        [label]=\"labels.dateControl.clear\"\n                        [text]=\"true\"\n                        severity=\"warn\"\n                        (click)=\"calendar.clear()\"\n                    />\n                }\n            </div>\n            <div>\n                @if (!options().dateTimeOnly) {\n                    <p-button \n                        [label]=\"labels.dateControl.today\" \n                        [outlined]=\"true\"\n                        (click)=\"selectToday()\"\n                    />\n                }\n                <p-button \n                    [label]=\"labels.dateControl.validate\" \n                    (click)=\"calendar.hideOverlay()\"\n                />\n            </div>\n        </div>\n    </ng-template>\n\n</p-datepicker>", styles: [".calendar-footer{display:flex;flex-wrap:wrap;justify-content:space-between}.calendar-footer p-button{margin-left:.5rem}\n"] }]
        }] });

const delayBetweenTries = 2000;
const maxRetry = 5;
class DownloadService {
    http = inject(HttpClient);
    snackbarService = inject(SnackbarService);
    labels = inject(CRUD_LABELS);
    /**
     * Downloads a blob as a file or opens it in a print module for PDFs.
     *
     * @param data - The blob data to download. Throws an error if null.
     * @param fileName - The name to use for the downloaded file.
     * @param openPrintModule - If true, opens PDF files in print module instead of downloading.
     *                          Shows info message for non-PDF files. Defaults to false.
     *
     * @throws {Error} When data is null or undefined.
     */
    downloadBlob(data, fileName, openPrintModule = false) {
        if (!data) {
            throw new Error("No data to download");
        }
        const blob = new Blob([data], {
            type: data.type,
        });
        // If an automatic print is requested and blob is .pdf, open the print module
        const isPdf = data.type === "application/pdf";
        if (openPrintModule) {
            if (isPdf) {
                this.openPrintModule(blob);
                return;
            }
            this.snackbarService.displayInfo(this.labels.download.noPdfPrintWarning);
        }
        // Otherwise, download the file
        saveAs(blob, fileName);
    }
    /**
     * Downloads a file from the given location and saves it locally.
     * If the file is not found, it retries the download up to 5 times with a
     * 2 second delay between each try.
     *
     * @param location the URL of the file to download
     * @returns an Observable that emits nothing
     * @throws an error if the file is not found after the maximum number of retries
     */
    tryDownloadFile(location, filename = "", openPrintModule = false) {
        console.log("Downloading file from:", location, filename);
        return this.http.get(location, { responseType: "blob" }).pipe(delay(delayBetweenTries), tap((blob) => {
            const filenameFromLocation = location.split("/").pop();
            const finalFilename = filename || filenameFromLocation || "downloaded_file";
            this.downloadBlob(blob, finalFilename, openPrintModule);
        }), retry(maxRetry));
    }
    openPrintModule(blob) {
        // Create object URL
        const fileUrl = URL.createObjectURL(blob);
        // Open in new window and print
        const printWindow = window.open(fileUrl, "_blank");
        if (printWindow) {
            printWindow.onload = () => {
                printWindow.print();
                // Clean up URL after a delay
                setTimeout(() => URL.revokeObjectURL(fileUrl), 1000);
            };
        }
    }
    /**
     * Extracts the file name from the content disposition header of the response.
     * @param response The HTTP response containing the blob.
     * @returns The extracted file name or "undefined" if not found.
     */
    extractFileInfo(response) {
        // Extract content disposition header
        const contentDisposition = response.headers.get("content-disposition") ?? "";
        // Extract the file name
        const filename = contentDisposition
            .split(";")[1]
            .split("filename")[1]
            .split("=")[1]
            .trim();
        return filename;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: DownloadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: DownloadService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: DownloadService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

class FileInfo {
    src = "";
    file;
    constructor(fileInfoBuilder) {
        if (fileInfoBuilder.type === "server") {
            this.src = fileInfoBuilder.src;
        }
        else {
            this.src = URL.createObjectURL(fileInfoBuilder.file);
            this.file = fileInfoBuilder.file;
        }
    }
    get name() {
        return typeof this.src === "string"
            ? // Extract last part of src
                this.src.substring(this.src.lastIndexOf("/") + 1)
            : // Get name from file
                this.file?.name || "";
    }
}

class FileNamePipe {
    transform(value) {
        if (value.file) {
            return value.file.name;
        }
        return value.name;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FileNamePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.7", ngImport: i0, type: FileNamePipe, isStandalone: true, name: "fileName" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FileNamePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "fileName",
                }]
        }] });

class FileUploadInputComponent extends FormFieldBaseComponent {
    dlService = inject(DownloadService);
    snackbarService = inject(SnackbarService);
    labels = inject(CRUD_LABELS);
    isImage = computed(() => this.config().controlType === "files" &&
        this.options().mediaType === "image", ...(ngDevMode ? [{ debugName: "isImage" }] : /* istanbul ignore next */ []));
    accept = computed(() => {
        const mediaType = this.options().mediaType;
        if (!mediaType) {
            return "";
        }
        if (mediaType.startsWith(".")) {
            return mediaType;
        }
        return `${mediaType}/*`;
    }, ...(ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []));
    canAddMore = computed(() => {
        return this.options().multiple ? true : this.localFiles().length === 0;
    }, ...(ngDevMode ? [{ debugName: "canAddMore" }] : /* istanbul ignore next */ []));
    localFiles = linkedSignal(() => {
        if (this.control().value) {
            return this.control().value;
        }
        return [];
    }, ...(ngDevMode ? [{ debugName: "localFiles" }] : /* istanbul ignore next */ []));
    isDraggedOver = false;
    async onFileUploaded(fileInput) {
        const filesList = fileInput.files;
        const validatedFilesList = await this.validateFilesList(filesList);
        if (!validatedFilesList.length) {
            return;
        }
        const files = this.options().multiple
            ? this.localFiles().concat(validatedFilesList)
            : validatedFilesList;
        this.localFiles.set(files);
        // Update control value
        this.setControlValue();
        this.emitInteractionEvent("uploadFile", this.localFiles());
    }
    onDrop(event, fileInput) {
        if (!event.dataTransfer) {
            return;
        }
        fileInput.files = event.dataTransfer.files;
        this.isDraggedOver = false;
        this.onFileUploaded(fileInput);
        this.prevent(event);
    }
    onDragOver(event) {
        this.isDraggedOver = true;
        this.prevent(event);
    }
    onDragLeave(event) {
        this.isDraggedOver = false;
        this.prevent(event);
    }
    clearAll(fileInput) {
        this.localFiles.set([]);
        this.emitInteractionEvent("clearAllFiles");
        fileInput.value = "";
        // Update control value
        this.setControlValue();
    }
    clear(index, fileInput) {
        // Delete locally uploaded file
        this.localFiles.update((f) => f.filter((_, i) => i !== index));
        // Emit event
        this.emitInteractionEvent("clearFile", index);
        // Clear native input
        fileInput.value = "";
        // Update control value
        this.setControlValue();
    }
    prevent(event) {
        event.preventDefault();
    }
    onDownload(file) {
        if (file.file) {
            const blob = new Blob([file.file], { type: file.file.type });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = file.name;
            a.click();
            window.URL.revokeObjectURL(url);
        }
        else {
            this.dlService.tryDownloadFile(file.src, file.name, false).subscribe();
        }
    }
    setControlValue() {
        this.control().setValue(this.localFiles());
    }
    async validateFilesList(filesList) {
        if (!filesList || !filesList?.length) {
            return [];
        }
        const files = [];
        for (let i = 0; i < filesList.length; i++) {
            const file = filesList[i];
            const maxFileSize = this.options().maxFileSize;
            if (maxFileSize && file.size > maxFileSize) {
                const message = this.labels.fileUpload.maxFileSizeExceeded(file.name, maxFileSize);
                this.snackbarService.displayError(message);
                this.control().setErrors({ maxFileSize: true }); // does not work
                this.control().markAsTouched();
            }
            else {
                const fileInfo = await this.readLocalFile(file);
                files.push(fileInfo);
            }
        }
        return files;
    }
    readLocalFile(file) {
        return new Promise((resolve) => {
            const reader = new FileReader();
            if (this.isImage()) {
                reader.readAsDataURL(file);
            }
            else {
                reader.readAsText(file, "utf8");
            }
            reader.onload = () => {
                const fileInfo = new FileInfo({
                    type: "local",
                    file,
                    src: reader.result,
                });
                resolve(fileInfo);
            };
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FileUploadInputComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: FileUploadInputComponent, isStandalone: true, selector: "frm-file-upload-input", usesInheritance: true, ngImport: i0, template: "<input #fileInput\n  [id]=\"'file-upload' + config().key\"\n  type=\"file\"\n  [accept]=\"accept()\"\n  [multiple]=\"options().multiple\"\n  [disabled]=\"isDisabled()\"\n  (change)=\"onFileUploaded(fileInput)\"\n/>\n\n<label\n  [for]=\"'file-upload' + config().key\"\n  class=\"custom-file-upload\"\n  [class.p-disabled]=\"isDisabled()\"\n  [class.dragged-over]=\"isDraggedOver\"\n  (drop)=\"onDrop($event, fileInput)\"\n  (dragover)=\"onDragOver($event)\"\n  (dragleave)=\"onDragLeave($event)\"\n  (dragenter)=\"prevent($event)\">\n  <div class=\"dropbox-toolbar\">\n    <div class=\"toolbar-left\">\n      <p-button\n        (onClick)=\"fileInput.click()\"\n        icon=\"pi pi-cloud-upload\"\n        [rounded]=\"true\"\n        [outlined]=\"true\"\n        [disabled]=\"!canAddMore()\"\n        [pTooltip]=\"labels.fileUpload.chooseFile\"\n      />\n      <p-button\n        (onClick)=\"clearAll(fileInput)\"\n        icon=\"pi pi-times\"\n        [rounded]=\"true\"\n        [outlined]=\"true\"\n        severity=\"danger\"\n        [disabled]=\"!localFiles() || localFiles().length === 0\"\n        pTooltip=\"Tout supprimer\"\n      />\n    </div>\n    <div class=\"toolbar-right\">\n      <p-button\n        icon=\"pi pi-lightbulb\"\n        severity=\"help\"\n        [rounded]=\"true\"\n        [outlined]=\"true\"\n        [pTooltip]=\"infoTooltip\"\n        tooltipPosition=\"left\"\n      />\n    </div>\n  </div>\n  <div class=\"dropbox-container\">  \n    @let hasFiles = localFiles() && localFiles().length > 0;     \n    @if (!hasFiles) {\n      <i class=\"pi pi-cloud-upload upload-icon\"></i>\n      <p>\n        {{ labels.fileUpload.dragDropLabel }}\n      </p>\n    } @else {\n      <div class=\"uploaded-files-container\">\n        <div class=\"container-title\">\n          {{ labels.fileUpload.uploadedFilesTitle }}\n        </div>\n        @for (file of localFiles(); track file; let i = $index) {\n          <div class=\"file-row\">\n            <p-button\n              (onClick)=\"clear(i, fileInput)\"\n              icon=\"pi pi-times\"\n              rounded\n              text\n              size=\"small\"\n              severity=\"danger\"\n              pTooltip=\"Supprimer\"\n              class=\"file-button\"\n            />\n            <p-button\n              (onClick)=\"onDownload(file)\"\n              icon=\"pi pi-download\"\n              rounded\n              text\n              size=\"small\"\n              severity=\"primary\"\n              pTooltip=\"T\u00E9l\u00E9charger\"\n              class=\"file-button\"\n            />\n            <div class=\"file-name\">{{ file | fileName }}</div>\n          </div>\n        } \n      </div>\n    }\n  </div>\n</label>\n\n\n\n<ng-template #infoTooltip>\n  @if (options().maxFileSize; as maxFileSize) {\n    <p class=\"small\">Taille maximum : {{maxFileSize / 1000000}} Mb</p>\n  }\n  @if (options().mediaType; as mediaType) {\n    <p class=\"small\">\n      Type de m\u00E9dia : \n      {{ mediaType }}\n    </p>\n  }\n  <p class=\"small\">\n    @if (canAddMore()) {\n      {{ labels.fileUpload.canAddMore }}\n    } @else {\n      {{ labels.fileUpload.cannotAddMore }}\n    }\n  </p>\n</ng-template>", styles: [":host{display:flex;align-items:center;flex-direction:column}input[type=file]{display:none}.custom-file-upload{border:1px solid var(--p-inputtext-border-color);display:inline-block;padding:.75rem;cursor:pointer;text-align:center;width:100%;border-radius:6px}.custom-file-upload:not(.p-disabled){background-color:var(--p-inputtext-background)}.custom-file-upload p{margin:0}.custom-file-upload .upload-icon{font-size:2rem}.custom-file-upload.dragged-over{font-weight:700}.custom-file-upload .dropbox-toolbar{display:flex;justify-content:space-between}.custom-file-upload .dropbox-toolbar .toolbar-left{display:flex}.custom-file-upload .dropbox-toolbar p-button{margin-right:10px}.uploaded-files-container{margin-top:1rem;width:100%}.uploaded-files-container .container-title{font-weight:700;margin-bottom:.5rem;text-align:left}.uploaded-files-container .file-row{display:flex;align-items:center;width:100%;padding:.25rem .5rem}.uploaded-files-container .file-row .file-button{margin-right:.5rem}.uploaded-files-container .no-file{text-align:left}\n"], dependencies: [{ kind: "ngmodule", type: DividerModule }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i1.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i2$3.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "pipe", type: FileNamePipe, name: "fileName" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FileUploadInputComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-file-upload-input", imports: [DividerModule, ButtonModule, TooltipModule, FileNamePipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "<input #fileInput\n  [id]=\"'file-upload' + config().key\"\n  type=\"file\"\n  [accept]=\"accept()\"\n  [multiple]=\"options().multiple\"\n  [disabled]=\"isDisabled()\"\n  (change)=\"onFileUploaded(fileInput)\"\n/>\n\n<label\n  [for]=\"'file-upload' + config().key\"\n  class=\"custom-file-upload\"\n  [class.p-disabled]=\"isDisabled()\"\n  [class.dragged-over]=\"isDraggedOver\"\n  (drop)=\"onDrop($event, fileInput)\"\n  (dragover)=\"onDragOver($event)\"\n  (dragleave)=\"onDragLeave($event)\"\n  (dragenter)=\"prevent($event)\">\n  <div class=\"dropbox-toolbar\">\n    <div class=\"toolbar-left\">\n      <p-button\n        (onClick)=\"fileInput.click()\"\n        icon=\"pi pi-cloud-upload\"\n        [rounded]=\"true\"\n        [outlined]=\"true\"\n        [disabled]=\"!canAddMore()\"\n        [pTooltip]=\"labels.fileUpload.chooseFile\"\n      />\n      <p-button\n        (onClick)=\"clearAll(fileInput)\"\n        icon=\"pi pi-times\"\n        [rounded]=\"true\"\n        [outlined]=\"true\"\n        severity=\"danger\"\n        [disabled]=\"!localFiles() || localFiles().length === 0\"\n        pTooltip=\"Tout supprimer\"\n      />\n    </div>\n    <div class=\"toolbar-right\">\n      <p-button\n        icon=\"pi pi-lightbulb\"\n        severity=\"help\"\n        [rounded]=\"true\"\n        [outlined]=\"true\"\n        [pTooltip]=\"infoTooltip\"\n        tooltipPosition=\"left\"\n      />\n    </div>\n  </div>\n  <div class=\"dropbox-container\">  \n    @let hasFiles = localFiles() && localFiles().length > 0;     \n    @if (!hasFiles) {\n      <i class=\"pi pi-cloud-upload upload-icon\"></i>\n      <p>\n        {{ labels.fileUpload.dragDropLabel }}\n      </p>\n    } @else {\n      <div class=\"uploaded-files-container\">\n        <div class=\"container-title\">\n          {{ labels.fileUpload.uploadedFilesTitle }}\n        </div>\n        @for (file of localFiles(); track file; let i = $index) {\n          <div class=\"file-row\">\n            <p-button\n              (onClick)=\"clear(i, fileInput)\"\n              icon=\"pi pi-times\"\n              rounded\n              text\n              size=\"small\"\n              severity=\"danger\"\n              pTooltip=\"Supprimer\"\n              class=\"file-button\"\n            />\n            <p-button\n              (onClick)=\"onDownload(file)\"\n              icon=\"pi pi-download\"\n              rounded\n              text\n              size=\"small\"\n              severity=\"primary\"\n              pTooltip=\"T\u00E9l\u00E9charger\"\n              class=\"file-button\"\n            />\n            <div class=\"file-name\">{{ file | fileName }}</div>\n          </div>\n        } \n      </div>\n    }\n  </div>\n</label>\n\n\n\n<ng-template #infoTooltip>\n  @if (options().maxFileSize; as maxFileSize) {\n    <p class=\"small\">Taille maximum : {{maxFileSize / 1000000}} Mb</p>\n  }\n  @if (options().mediaType; as mediaType) {\n    <p class=\"small\">\n      Type de m\u00E9dia : \n      {{ mediaType }}\n    </p>\n  }\n  <p class=\"small\">\n    @if (canAddMore()) {\n      {{ labels.fileUpload.canAddMore }}\n    } @else {\n      {{ labels.fileUpload.cannotAddMore }}\n    }\n  </p>\n</ng-template>", styles: [":host{display:flex;align-items:center;flex-direction:column}input[type=file]{display:none}.custom-file-upload{border:1px solid var(--p-inputtext-border-color);display:inline-block;padding:.75rem;cursor:pointer;text-align:center;width:100%;border-radius:6px}.custom-file-upload:not(.p-disabled){background-color:var(--p-inputtext-background)}.custom-file-upload p{margin:0}.custom-file-upload .upload-icon{font-size:2rem}.custom-file-upload.dragged-over{font-weight:700}.custom-file-upload .dropbox-toolbar{display:flex;justify-content:space-between}.custom-file-upload .dropbox-toolbar .toolbar-left{display:flex}.custom-file-upload .dropbox-toolbar p-button{margin-right:10px}.uploaded-files-container{margin-top:1rem;width:100%}.uploaded-files-container .container-title{font-weight:700;margin-bottom:.5rem;text-align:left}.uploaded-files-container .file-row{display:flex;align-items:center;width:100%;padding:.25rem .5rem}.uploaded-files-container .file-row .file-button{margin-right:.5rem}.uploaded-files-container .no-file{text-align:left}\n"] }]
        }] });

class InputNumberControlComponent extends FormFieldBaseComponent {
    currency = computed(() => this.options().numberCurrency, ...(ngDevMode ? [{ debugName: "currency" }] : /* istanbul ignore next */ []));
    mode = computed(() => this.currency() ? 'currency' : undefined, ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: InputNumberControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.7", type: InputNumberControlComponent, isStandalone: true, selector: "frm-inputnumber-control", usesInheritance: true, ngImport: i0, template: "<p-inputNumber \n    [formControl]=\"control()\"\n    [showClear]=\"showClear()\"\n    [placeholder]=\"placeholder()\"\n    [max]=\"options().max\"\n    [min]=\"options().min\"\n    [minFractionDigits]=\"options().minFractionDigits\"\n    [maxFractionDigits]=\"options().maxFractionDigits\"\n    [step]=\"options().step\"\n    [showButtons]=\"options().areNumberInputButtonsVisible ?? true\"\n    [useGrouping]=\"options().useNumberGrouping ?? false\"\n    [currency]=\"currency()\"\n    [mode]=\"mode()\"\n    (onClear)=\"emitInteractionEvent('clear')\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onInput)=\"emitInteractionEvent('keyup')\"\n/>", dependencies: [{ kind: "ngmodule", type: InputNumberModule }, { kind: "component", type: i1$3.InputNumber, selector: "p-inputNumber, p-inputnumber, p-input-number", inputs: ["showButtons", "format", "buttonLayout", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabelledBy", "ariaDescribedBy", "ariaLabel", "ariaRequired", "autocomplete", "incrementButtonClass", "decrementButtonClass", "incrementButtonIcon", "decrementButtonIcon", "readonly", "allowEmpty", "locale", "localeMatcher", "mode", "currency", "currencyDisplay", "useGrouping", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "inputStyle", "inputStyleClass", "showClear", "autofocus"], outputs: ["onInput", "onFocus", "onBlur", "onKeyDown", "onClear"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: InputNumberControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-inputnumber-control", imports: [InputNumberModule, ReactiveFormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<p-inputNumber \n    [formControl]=\"control()\"\n    [showClear]=\"showClear()\"\n    [placeholder]=\"placeholder()\"\n    [max]=\"options().max\"\n    [min]=\"options().min\"\n    [minFractionDigits]=\"options().minFractionDigits\"\n    [maxFractionDigits]=\"options().maxFractionDigits\"\n    [step]=\"options().step\"\n    [showButtons]=\"options().areNumberInputButtonsVisible ?? true\"\n    [useGrouping]=\"options().useNumberGrouping ?? false\"\n    [currency]=\"currency()\"\n    [mode]=\"mode()\"\n    (onClear)=\"emitInteractionEvent('clear')\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onInput)=\"emitInteractionEvent('keyup')\"\n/>" }]
        }] });

class InputTextControlComponent extends FormFieldBaseComponent {
    maxLength = computed(() => {
        return this.options().maxLength || null;
    }, ...(ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []));
    minLength = computed(() => {
        return this.options().minLength || null;
    }, ...(ngDevMode ? [{ debugName: "minLength" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: InputTextControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.7", type: InputTextControlComponent, isStandalone: true, selector: "frm-inputtext-control", usesInheritance: true, ngImport: i0, template: "<input\n    type=\"text\"\n    pInputText\n    [placeholder]=\"placeholder()\"\n    [formControl]=\"control()\"\n    [minlength]=\"minLength()\"\n    [maxlength]=\"maxLength()\"\n    (input)=\"emitInteractionEvent('keyup')\"\n    (focus)=\"emitInteractionEvent('focus')\"\n    (blur)=\"emitInteractionEvent('blur')\"\n/>", dependencies: [{ kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i1$4.InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i2$1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: InputTextControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-inputtext-control", imports: [InputTextModule, ReactiveFormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<input\n    type=\"text\"\n    pInputText\n    [placeholder]=\"placeholder()\"\n    [formControl]=\"control()\"\n    [minlength]=\"minLength()\"\n    [maxlength]=\"maxLength()\"\n    (input)=\"emitInteractionEvent('keyup')\"\n    (focus)=\"emitInteractionEvent('focus')\"\n    (blur)=\"emitInteractionEvent('blur')\"\n/>" }]
        }] });

class MultiSelectControlComponent extends FormFieldBaseComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: MultiSelectControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.7", type: MultiSelectControlComponent, isStandalone: true, selector: "frm-multi-select-control", usesInheritance: true, ngImport: i0, template: "<p-multiSelect\n    [id]=\"config().key.toString()\"\n    [options]=\"selectOptions()\"\n    [formControl]=\"control()\"\n    [placeholder]=\"placeholder()\"\n    filterPlaceHolder=\"---\"\n    appendTo=\"body\"        \n    display=\"chip\"\n    [maxSelectedLabels]=\"options().maxSelectedLabels ?? 5\"\n    [filter]=\"options().areOptionsFilterable ?? true\"\n    [showToggleAll]=\"options().isSelectAllEnabled ?? true\"\n    [showClear]=\"showClear() && !isRequired()\"\n    (onChange)=\"emitInteractionEvent('valueChange')\"\n    (onClear)=\"emitInteractionEvent('clear')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onPanelShow)=\"emitInteractionEvent('panelOpen')\"\n    (onPanelHide)=\"emitInteractionEvent('panelClose')\"\n/>", styles: [".p-multiselect-chip{height:20px;line-height:20px}\n"], dependencies: [{ kind: "ngmodule", type: MultiSelectModule }, { kind: "component", type: i1$5.MultiSelect, selector: "p-multiSelect, p-multiselect, p-multi-select", inputs: ["id", "ariaLabel", "styleClass", "panelStyle", "panelStyleClass", "inputId", "readonly", "group", "filter", "filterPlaceHolder", "filterLocale", "overlayVisible", "tabindex", "dataKey", "ariaLabelledBy", "displaySelectedLabel", "maxSelectedLabels", "selectionLimit", "selectedItemsLabel", "showToggleAll", "emptyFilterMessage", "emptyMessage", "resetFilterOnHide", "dropdownIcon", "chipIcon", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "showHeader", "filterBy", "scrollHeight", "lazy", "virtualScroll", "loading", "virtualScrollItemSize", "loadingIcon", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "autofocusFilter", "display", "autocomplete", "showClear", "autofocus", "placeholder", "options", "filterValue", "selectAll", "focusOnHover", "filterFields", "selectOnFocus", "autoOptionFocus", "highlightOnSelect", "size", "variant", "fluid", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onClear", "onPanelShow", "onPanelHide", "onLazyLoad", "onRemove", "onSelectAllChange"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: IftaLabelModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: MultiSelectControlComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, imports: [MultiSelectModule, ReactiveFormsModule, IftaLabelModule], selector: "frm-multi-select-control", encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<p-multiSelect\n    [id]=\"config().key.toString()\"\n    [options]=\"selectOptions()\"\n    [formControl]=\"control()\"\n    [placeholder]=\"placeholder()\"\n    filterPlaceHolder=\"---\"\n    appendTo=\"body\"        \n    display=\"chip\"\n    [maxSelectedLabels]=\"options().maxSelectedLabels ?? 5\"\n    [filter]=\"options().areOptionsFilterable ?? true\"\n    [showToggleAll]=\"options().isSelectAllEnabled ?? true\"\n    [showClear]=\"showClear() && !isRequired()\"\n    (onChange)=\"emitInteractionEvent('valueChange')\"\n    (onClear)=\"emitInteractionEvent('clear')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onPanelShow)=\"emitInteractionEvent('panelOpen')\"\n    (onPanelHide)=\"emitInteractionEvent('panelClose')\"\n/>", styles: [".p-multiselect-chip{height:20px;line-height:20px}\n"] }]
        }] });

class PicklistControlComponent extends FormFieldBaseComponent {
    labels = inject(CRUD_LABELS);
    picklist = viewChild("picklist", ...(ngDevMode ? [{ debugName: "picklist" }] : /* istanbul ignore next */ []));
    allOptions = computed(() => this.config().options ?? [], ...(ngDevMode ? [{ debugName: "allOptions" }] : /* istanbul ignore next */ []));
    sources = signal([], ...(ngDevMode ? [{ debugName: "sources" }] : /* istanbul ignore next */ []));
    targets = signal([], ...(ngDevMode ? [{ debugName: "targets" }] : /* istanbul ignore next */ []));
    //This effect is here to manage and update the values and the options when input data is edited
    resetPicklistEffect = effect(() => {
        const allOptions = this.allOptions();
        const values = this.control()?.value ?? [];
        const picklist = this.picklist();
        const newSources = allOptions.filter((opt) => !values.includes(opt.value));
        const newTargets = allOptions.filter((opt) => values.includes(opt.value));
        //We prevent the ignals to be updated for no reason.
        //It mainly prevent the options to fast desapear and reapear when we edit the form
        if (!isEqual(newSources, this.sources())) {
            if (picklist) {
                picklist.resetFilter();
            }
            this.sources.set(newSources);
        }
        if (!isEqual(newTargets, this.targets())) {
            if (picklist) {
                picklist.resetFilter();
            }
            this.targets.set(newTargets);
        }
    }, ...(ngDevMode ? [{ debugName: "resetPicklistEffect" }] : /* istanbul ignore next */ []));
    /**
     * Update the form control with current target values
     */
    sync() {
        this.control().setValue(this.targets().map((opt) => opt.value));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: PicklistControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: PicklistControlComponent, isStandalone: true, selector: "frm-picklist-control", viewQueries: [{ propertyName: "picklist", first: true, predicate: ["picklist"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<p-pickList\n    #picklist\n    [source]=\"sources()\"\n    [target]=\"targets()\"\n    [responsive]=\"true\"\n    [sourceStyle]=\"{'height':'10rem'}\"\n    [targetStyle]=\"{'height':'10rem'}\"\n    filterBy=\"label\"\n    [showSourceControls]=\"false\"\n    [showTargetControls]=\"false\"\n    [targetHeader]=\"labels.picklist.targetHeader\"\n    [sourceHeader]=\"labels.picklist.sourceHeader\"\n    [disabled]=\"isDisabled()\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onChange)=\"emitInteractionEvent('valueChange')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onMoveToSource)=\"sync()\"\n    (onMoveToTarget)=\"sync()\"\n    (onMoveAllToSource)=\"sync()\"\n    (onMoveAllToTarget)=\"sync()\">\n    <ng-template let-option pTemplate=\"item\">\n            <div class=\"option-container\">\n                @if(option.icon){\n                    <i [class]=\"option.icon\"></i>\n                }\n                <div class=\"ml-2\">{{option.label}}</div>\n            </div>\n    </ng-template>\n</p-pickList>", styles: [".option-container{display:flex;align-items:center;gap:.5rem}\n"], dependencies: [{ kind: "ngmodule", type: PickListModule }, { kind: "component", type: i1$6.PickList, selector: "p-pickList, p-picklist, p-pick-list", inputs: ["hostName", "source", "target", "dataKey", "sourceHeader", "tabindex", "rightButtonAriaLabel", "leftButtonAriaLabel", "allRightButtonAriaLabel", "allLeftButtonAriaLabel", "upButtonAriaLabel", "downButtonAriaLabel", "topButtonAriaLabel", "bottomButtonAriaLabel", "sourceAriaLabel", "targetAriaLabel", "targetHeader", "responsive", "filterBy", "filterLocale", "trackBy", "sourceTrackBy", "targetTrackBy", "showSourceFilter", "showTargetFilter", "metaKeySelection", "dragdrop", "style", "styleClass", "sourceStyle", "targetStyle", "showSourceControls", "showTargetControls", "sourceFilterPlaceholder", "targetFilterPlaceholder", "disabled", "sourceOptionDisabled", "targetOptionDisabled", "ariaSourceFilterLabel", "ariaTargetFilterLabel", "filterMatchMode", "stripedRows", "keepSelection", "scrollHeight", "autoOptionFocus", "buttonProps", "moveUpButtonProps", "moveTopButtonProps", "moveDownButtonProps", "moveBottomButtonProps", "moveToTargetProps", "moveAllToTargetProps", "moveToSourceProps", "moveAllToSourceProps", "breakpoint"], outputs: ["sourceChange", "targetChange", "onMoveToSource", "onMoveAllToSource", "onMoveAllToTarget", "onMoveToTarget", "onSourceReorder", "onTargetReorder", "onSourceSelect", "onTargetSelect", "onSourceFilter", "onTargetFilter", "onFocus", "onBlur"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: PicklistControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-picklist-control", imports: [PickListModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<p-pickList\n    #picklist\n    [source]=\"sources()\"\n    [target]=\"targets()\"\n    [responsive]=\"true\"\n    [sourceStyle]=\"{'height':'10rem'}\"\n    [targetStyle]=\"{'height':'10rem'}\"\n    filterBy=\"label\"\n    [showSourceControls]=\"false\"\n    [showTargetControls]=\"false\"\n    [targetHeader]=\"labels.picklist.targetHeader\"\n    [sourceHeader]=\"labels.picklist.sourceHeader\"\n    [disabled]=\"isDisabled()\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onChange)=\"emitInteractionEvent('valueChange')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onMoveToSource)=\"sync()\"\n    (onMoveToTarget)=\"sync()\"\n    (onMoveAllToSource)=\"sync()\"\n    (onMoveAllToTarget)=\"sync()\">\n    <ng-template let-option pTemplate=\"item\">\n            <div class=\"option-container\">\n                @if(option.icon){\n                    <i [class]=\"option.icon\"></i>\n                }\n                <div class=\"ml-2\">{{option.label}}</div>\n            </div>\n    </ng-template>\n</p-pickList>", styles: [".option-container{display:flex;align-items:center;gap:.5rem}\n"] }]
        }], propDecorators: { picklist: [{ type: i0.ViewChild, args: ["picklist", { isSignal: true }] }] } });

class RadioGroupComponent extends FormFieldBaseComponent {
    value = null;
    onClick(event) {
        this.emitInteractionEvent("click");
        const haveValueChanged = event.value !== this.control().value;
        //We dont want to proced to change notification if we click multiple time at same button
        if (!haveValueChanged)
            return;
        this.touch(event.value);
    }
    unselect(event) {
        event.preventDefault();
        this.value = null;
        this.touch(null);
    }
    touch(value) {
        this.control().setValue(value);
        this.control().markAllAsDirty();
        this.emitInteractionEvent("valueChange");
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: RadioGroupComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: RadioGroupComponent, isStandalone: true, selector: "frm-radiogroup-control", usesInheritance: true, ngImport: i0, template: "<div class=\"radio-group p-inputtext\" \n    [class.p-disabled]=\"isDisabled()\"\n    [class.row-direction]=\"options().radioOptionsDirection === 'row'\">\n  @for (radio of config().options; track radio.label) {\n    <div class=\"radio-option\">\n      <p-radioButton \n        [inputId]=\"config().key\"\n        [name]=\"config().key\"\n        [value]=\"radio.value\"\n        [(ngModel)]=\"value\"\n        (onClick)=\"onClick($event)\"\n        [disabled]=\"isDisabled()\"\n        (onFocus)=\"emitInteractionEvent('focus')\"\n        (onBlur)=\"emitInteractionEvent('blur')\"\n      />\n      <label [for]=\"config().key\">\n          {{ radio.label }}\n          @if (showClear() && radio.value === value) {\n            <i class=\"pi pi-times delete-icon\" (click)=\"unselect($event)\"></i>\n          }\n      </label>\n    </div>    \n    }\n</div>", styles: [".radio-group{padding-block:6px}.radio-group.row-direction{display:flex;flex-direction:row;flex-wrap:wrap}.radio-group .radio-option{display:flex;align-items:center}.radio-group .radio-option label{position:unset!important;margin:0 .5rem;gap:.25rem;display:flex;align-items:center}.radio-group .radio-option label .delete-icon{color:var(--p-gray-400);cursor:pointer}\n"], dependencies: [{ kind: "ngmodule", type: RadioButtonModule }, { kind: "component", type: i1$7.RadioButton, selector: "p-radioButton, p-radiobutton, p-radio-button", inputs: ["value", "tabindex", "inputId", "ariaLabelledBy", "ariaLabel", "styleClass", "autofocus", "binary", "variant", "size"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: SharedModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: RadioGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-radiogroup-control", imports: [RadioButtonModule, FormsModule, SharedModule], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"radio-group p-inputtext\" \n    [class.p-disabled]=\"isDisabled()\"\n    [class.row-direction]=\"options().radioOptionsDirection === 'row'\">\n  @for (radio of config().options; track radio.label) {\n    <div class=\"radio-option\">\n      <p-radioButton \n        [inputId]=\"config().key\"\n        [name]=\"config().key\"\n        [value]=\"radio.value\"\n        [(ngModel)]=\"value\"\n        (onClick)=\"onClick($event)\"\n        [disabled]=\"isDisabled()\"\n        (onFocus)=\"emitInteractionEvent('focus')\"\n        (onBlur)=\"emitInteractionEvent('blur')\"\n      />\n      <label [for]=\"config().key\">\n          {{ radio.label }}\n          @if (showClear() && radio.value === value) {\n            <i class=\"pi pi-times delete-icon\" (click)=\"unselect($event)\"></i>\n          }\n      </label>\n    </div>    \n    }\n</div>", styles: [".radio-group{padding-block:6px}.radio-group.row-direction{display:flex;flex-direction:row;flex-wrap:wrap}.radio-group .radio-option{display:flex;align-items:center}.radio-group .radio-option label{position:unset!important;margin:0 .5rem;gap:.25rem;display:flex;align-items:center}.radio-group .radio-option label .delete-icon{color:var(--p-gray-400);cursor:pointer}\n"] }]
        }] });

class RichTextEditorComponent extends FormFieldBaseComponent {
    labels = inject(CRUD_LABELS);
    editorComponent;
    htmlEditor;
    modules = {
        // syntax: true // commented for now
        clipboard: {
            matchVisual: false, // strip out the unnecessarily-injected <p><br></p>
        },
    };
    htmlToggled = false;
    toggleHTML() {
        this.htmlToggled = !this.htmlToggled;
        const quill = this.editorComponent.quill;
        if (this.htmlToggled) {
            const HTML = this.editorComponent.el.nativeElement.querySelector(".ql-editor").innerHTML;
            this.htmlEditor.nativeElement.innerText = HTML;
        }
        else {
            const newHTML = this.htmlEditor.nativeElement.value;
            quill.pasteHTML(newHTML);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: RichTextEditorComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: RichTextEditorComponent, isStandalone: true, selector: "frm-rich-text-editor", viewQueries: [{ propertyName: "editorComponent", first: true, predicate: ["editorComponent"], descendants: true }, { propertyName: "htmlEditor", first: true, predicate: ["htmlEditor"], descendants: true }], usesInheritance: true, ngImport: i0, template: "  <p-editor\n    [formControl]=\"control()\"\n    [modules]=\"modules\"\n    class=\"editor-wysiwyg\"\n    [class.p-disabled]=\"isDisabled()\"\n    #editorComponent\n    [style]=\"{ height: options().textEditorHeight || '200px' }\">\n    <ng-template pTemplate=\"header\">\n      <ng-container\n        [ngTemplateOutlet]=\"toolbar\"\n        [ngTemplateOutletContext]=\"{ displayHtmlToggle: options().isHtmlToggleable}\">\n      </ng-container>\n    </ng-template>\n  </p-editor>\n  <textarea #htmlEditor class=\"html-editor\" [class.displayed]=\"htmlToggled\"></textarea>\n  @if (htmlToggled) {\n    <button pButton\n      pRipple\n      type=\"button\"\n      icon=\"pi pi-times\"\n      class=\"p-button-rounded p-button-info close-html\"\n      (click)=\"toggleHTML()\">\n    </button>\n  }\n\n<ng-template #toolbar let-displayHtmlToggle=\"displayHtmlToggle\">\n  <p-header>\n    <span class=\"ql-formats\" style=\"margin-right: 0\">\n      <select class=\"ql-size\"></select>\n    </span>\n    <span class=\"ql-formats\">\n      <button class=\"ql-bold\"></button>\n      <button class=\"ql-italic\"></button>\n      <button class=\"ql-underline\"></button>\n      <button class=\"ql-strike\"></button>\n    </span>\n    <span class=\"ql-formats\">\n      <select class=\"ql-color\"></select>\n      <select class=\"ql-background\"></select>\n    </span>\n    <!-- <span class=\"ql-formats\">\n    <button class=\"ql-script\" value=\"sub\"></button>\n    <button class=\"ql-script\" value=\"super\"></button>\n  </span>\n  <span class=\"ql-formats\">\n    <button class=\"ql-header\" value=\"1\"></button>\n    <button class=\"ql-header\" value=\"2\"></button>\n    <button class=\"ql-blockquote\"></button>\n    <button class=\"ql-code-block\"></button>\n  </span> -->\n  <span class=\"ql-formats\" style=\"margin-right: 0\">\n    <button class=\"ql-list\" value=\"ordered\"></button>\n    <button class=\"ql-list\" value=\"bullet\"></button>\n    <!-- <button class=\"ql-indent\" value=\"-1\"></button>\n    <button class=\"ql-indent\" value=\"+1\"></button> -->\n  </span>\n  <!-- <span class=\"ql-formats\">\n  <button class=\"ql-direction\" value=\"rtl\"></button>\n  <select class=\"ql-align\"></select>\n</span>\n<span class=\"ql-formats\">\n  <button class=\"ql-link\"></button>\n  <button class=\"ql-image\"></button>\n  <button class=\"ql-video\"></button>\n  <button class=\"ql-formula\"></button>\n</span> -->\n<span class=\"ql-formats\" style=\"margin-right: 0\">\n  <!-- <button class=\"ql-clean\"></button> -->\n  @if (displayHtmlToggle) {\n    <button pButton\n      pRipple\n      type=\"button\"\n      icon=\"pi pi-code\"\n      class=\"p-button-rounded p-button-text html-toggler\"\n      (click)=\"toggleHTML()\"\n      [title]=\"labels.richTextEditor.editHtml\">\n    </button>\n  }\n</span>\n</p-header>\n</ng-template>", styles: [":host{display:block;position:relative;height:100%;width:100%}:host .html-editor{position:absolute;top:0;min-height:100%;width:100%;z-index:1;display:none;overflow:auto;border:1px solid #ccc}:host .html-editor:focus-visible{outline:0}:host .html-editor.displayed{display:block}:host .close-html{position:absolute;top:5px;right:5px;z-index:1;width:20px;height:20px}:host .editor-wysiwyg{overflow:hidden;width:100%;display:block}:host .editor-wysiwyg ::ng-deep .p-editor-container{height:100%}:host .editor-wysiwyg ::ng-deep .p-editor-container .p-editor-toolbar,:host .editor-wysiwyg ::ng-deep .p-editor-container .ql-editor{background:var(--p-inputtext-background)}.html-toggler{padding:1px 5px!important;height:20px!important}\n"], dependencies: [{ kind: "ngmodule", type: EditorModule }, { kind: "component", type: i1$8.Editor, selector: "p-editor", inputs: ["style", "styleClass", "placeholder", "formats", "modules", "bounds", "scrollingContainer", "debug", "readonly"], outputs: ["onInit", "onTextChange", "onSelectionChange", "onEditorChange", "onFocus", "onBlur"] }, { kind: "component", type: i2.Header, selector: "p-header" }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: ButtonModule }, { kind: "directive", type: i1.ButtonDirective, selector: "[pButton]", inputs: ["ptButtonDirective", "pButtonPT", "pButtonUnstyled", "hostName", "text", "plain", "raised", "size", "outlined", "rounded", "iconPos", "loadingIcon", "fluid", "label", "icon", "loading", "buttonProps", "severity"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: RichTextEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-rich-text-editor", imports: [EditorModule, ReactiveFormsModule, NgTemplateOutlet, ButtonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "  <p-editor\n    [formControl]=\"control()\"\n    [modules]=\"modules\"\n    class=\"editor-wysiwyg\"\n    [class.p-disabled]=\"isDisabled()\"\n    #editorComponent\n    [style]=\"{ height: options().textEditorHeight || '200px' }\">\n    <ng-template pTemplate=\"header\">\n      <ng-container\n        [ngTemplateOutlet]=\"toolbar\"\n        [ngTemplateOutletContext]=\"{ displayHtmlToggle: options().isHtmlToggleable}\">\n      </ng-container>\n    </ng-template>\n  </p-editor>\n  <textarea #htmlEditor class=\"html-editor\" [class.displayed]=\"htmlToggled\"></textarea>\n  @if (htmlToggled) {\n    <button pButton\n      pRipple\n      type=\"button\"\n      icon=\"pi pi-times\"\n      class=\"p-button-rounded p-button-info close-html\"\n      (click)=\"toggleHTML()\">\n    </button>\n  }\n\n<ng-template #toolbar let-displayHtmlToggle=\"displayHtmlToggle\">\n  <p-header>\n    <span class=\"ql-formats\" style=\"margin-right: 0\">\n      <select class=\"ql-size\"></select>\n    </span>\n    <span class=\"ql-formats\">\n      <button class=\"ql-bold\"></button>\n      <button class=\"ql-italic\"></button>\n      <button class=\"ql-underline\"></button>\n      <button class=\"ql-strike\"></button>\n    </span>\n    <span class=\"ql-formats\">\n      <select class=\"ql-color\"></select>\n      <select class=\"ql-background\"></select>\n    </span>\n    <!-- <span class=\"ql-formats\">\n    <button class=\"ql-script\" value=\"sub\"></button>\n    <button class=\"ql-script\" value=\"super\"></button>\n  </span>\n  <span class=\"ql-formats\">\n    <button class=\"ql-header\" value=\"1\"></button>\n    <button class=\"ql-header\" value=\"2\"></button>\n    <button class=\"ql-blockquote\"></button>\n    <button class=\"ql-code-block\"></button>\n  </span> -->\n  <span class=\"ql-formats\" style=\"margin-right: 0\">\n    <button class=\"ql-list\" value=\"ordered\"></button>\n    <button class=\"ql-list\" value=\"bullet\"></button>\n    <!-- <button class=\"ql-indent\" value=\"-1\"></button>\n    <button class=\"ql-indent\" value=\"+1\"></button> -->\n  </span>\n  <!-- <span class=\"ql-formats\">\n  <button class=\"ql-direction\" value=\"rtl\"></button>\n  <select class=\"ql-align\"></select>\n</span>\n<span class=\"ql-formats\">\n  <button class=\"ql-link\"></button>\n  <button class=\"ql-image\"></button>\n  <button class=\"ql-video\"></button>\n  <button class=\"ql-formula\"></button>\n</span> -->\n<span class=\"ql-formats\" style=\"margin-right: 0\">\n  <!-- <button class=\"ql-clean\"></button> -->\n  @if (displayHtmlToggle) {\n    <button pButton\n      pRipple\n      type=\"button\"\n      icon=\"pi pi-code\"\n      class=\"p-button-rounded p-button-text html-toggler\"\n      (click)=\"toggleHTML()\"\n      [title]=\"labels.richTextEditor.editHtml\">\n    </button>\n  }\n</span>\n</p-header>\n</ng-template>", styles: [":host{display:block;position:relative;height:100%;width:100%}:host .html-editor{position:absolute;top:0;min-height:100%;width:100%;z-index:1;display:none;overflow:auto;border:1px solid #ccc}:host .html-editor:focus-visible{outline:0}:host .html-editor.displayed{display:block}:host .close-html{position:absolute;top:5px;right:5px;z-index:1;width:20px;height:20px}:host .editor-wysiwyg{overflow:hidden;width:100%;display:block}:host .editor-wysiwyg ::ng-deep .p-editor-container{height:100%}:host .editor-wysiwyg ::ng-deep .p-editor-container .p-editor-toolbar,:host .editor-wysiwyg ::ng-deep .p-editor-container .ql-editor{background:var(--p-inputtext-background)}.html-toggler{padding:1px 5px!important;height:20px!important}\n"] }]
        }], propDecorators: { editorComponent: [{
                type: ViewChild,
                args: ["editorComponent"]
            }], htmlEditor: [{
                type: ViewChild,
                args: ["htmlEditor"]
            }] } });

class SelectButtonControlComponent extends FormFieldBaseComponent {
    unselectable = computed(() => {
        const toggleable = this.options().isSelectButtonOptionToggleable;
        return !isNil(toggleable) ? !toggleable : true;
    }, ...(ngDevMode ? [{ debugName: "unselectable" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SelectButtonControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.7", type: SelectButtonControlComponent, isStandalone: true, selector: "frm-select-button-control", usesInheritance: true, ngImport: i0, template: "<p-selectButton\n    [id]=\"config().key\"\n    class=\"control\"\n    [options]=\"selectOptions()\"\n    [formControl]=\"control()\"\n    [multiple]=\"options().multipleSelectButton ?? false\"\n    [unselectable]=\"unselectable()\"\n    [class.p-disabled]=\"isDisabled()\"\n/>   ", styles: [".p-selectbutton{width:100%;border:1px solid var(--p-inputtext-border-color);background:var(--p-inputtext-background)}.p-selectbutton .p-togglebutton{padding:1px var(--p-togglebutton-padding);flex:1}.p-iftalabel .p-selectbutton{padding-top:20px}\n"], dependencies: [{ kind: "ngmodule", type: SelectButtonModule }, { kind: "component", type: i1$9.SelectButton, selector: "p-selectButton, p-selectbutton, p-select-button", inputs: ["options", "optionLabel", "optionValue", "optionDisabled", "unselectable", "tabindex", "multiple", "allowEmpty", "styleClass", "ariaLabelledBy", "dataKey", "autofocus", "size", "fluid"], outputs: ["onOptionClick", "onChange"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SelectButtonControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-select-button-control", imports: [SelectButtonModule, ReactiveFormsModule], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<p-selectButton\n    [id]=\"config().key\"\n    class=\"control\"\n    [options]=\"selectOptions()\"\n    [formControl]=\"control()\"\n    [multiple]=\"options().multipleSelectButton ?? false\"\n    [unselectable]=\"unselectable()\"\n    [class.p-disabled]=\"isDisabled()\"\n/>   ", styles: [".p-selectbutton{width:100%;border:1px solid var(--p-inputtext-border-color);background:var(--p-inputtext-background)}.p-selectbutton .p-togglebutton{padding:1px var(--p-togglebutton-padding);flex:1}.p-iftalabel .p-selectbutton{padding-top:20px}\n"] }]
        }] });

class SelectControlComponent extends FormFieldBaseComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SelectControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: SelectControlComponent, isStandalone: true, selector: "frm-select-control", usesInheritance: true, ngImport: i0, template: "<p-select [formControl]=\"control()\"\n    [options]=\"selectOptions()\"\n    [showClear]=\"showClear() && !isRequired()\"\n    [placeholder]=\"placeholder()\"\n    filterPlaceholder=\"---\"\n    [filter]=\"options().areOptionsFilterable ?? true\"\n    appendTo=\"body\"\n    (onChange)=\"emitInteractionEvent('valueChange')\"\n    (onClear)=\"emitInteractionEvent('clear')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onPanelShow)=\"emitInteractionEvent('panelOpen')\"\n    (onPanelHide)=\"emitInteractionEvent('panelClose')\">\n    <ng-template let-option pTemplate=\"selectedItem\">\n        @if (option?.icon) {\n            <i [class]=\"option?.icon\" class=\"icon\"></i>              \n        }\n        <span>{{option.label}}</span>\n    </ng-template>\n    <ng-template let-option pTemplate=\"item\">\n        @if (option?.icon) {\n            <i [class]=\"option?.icon\" class=\"icon\"></i>              \n        }\n        <span>{{option.label}}</span>\n    </ng-template>\n</p-select>", styles: [".icon{width:45px;display:inline-block}\n"], dependencies: [{ kind: "ngmodule", type: SelectModule }, { kind: "component", type: i1$a.Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "styleClass", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SelectControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-select-control", imports: [SelectModule, ReactiveFormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<p-select [formControl]=\"control()\"\n    [options]=\"selectOptions()\"\n    [showClear]=\"showClear() && !isRequired()\"\n    [placeholder]=\"placeholder()\"\n    filterPlaceholder=\"---\"\n    [filter]=\"options().areOptionsFilterable ?? true\"\n    appendTo=\"body\"\n    (onChange)=\"emitInteractionEvent('valueChange')\"\n    (onClear)=\"emitInteractionEvent('clear')\"\n    (onFocus)=\"emitInteractionEvent('focus')\"\n    (onBlur)=\"emitInteractionEvent('blur')\"\n    (onPanelShow)=\"emitInteractionEvent('panelOpen')\"\n    (onPanelHide)=\"emitInteractionEvent('panelClose')\">\n    <ng-template let-option pTemplate=\"selectedItem\">\n        @if (option?.icon) {\n            <i [class]=\"option?.icon\" class=\"icon\"></i>              \n        }\n        <span>{{option.label}}</span>\n    </ng-template>\n    <ng-template let-option pTemplate=\"item\">\n        @if (option?.icon) {\n            <i [class]=\"option?.icon\" class=\"icon\"></i>              \n        }\n        <span>{{option.label}}</span>\n    </ng-template>\n</p-select>", styles: [".icon{width:45px;display:inline-block}\n"] }]
        }] });

class CheckboxCellRendererComponent {
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CheckboxCellRendererComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: CheckboxCellRendererComponent, isStandalone: true, selector: "tbl-checkbox-cell-renderer", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    @if (cellValue()) {
        <i class="pi pi-check green"></i>
    } @else {
        <i class="pi pi-times red"></i>
    }
`, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CheckboxCellRendererComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "tbl-checkbox-cell-renderer",
                    template: `
    @if (cellValue()) {
        <i class="pi pi-check green"></i>
    } @else {
        <i class="pi pi-times red"></i>
    }
`,
                }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }] } });

class DateCellRendererComponent {
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    valueAsString = computed(() => {
        const cellValue = this.cellValue();
        if (cellValue instanceof Date) {
            return cellValue.toISOString();
        }
        return cellValue;
    }, ...(ngDevMode ? [{ debugName: "valueAsString" }] : /* istanbul ignore next */ []));
    dateFormat = DATE_FORMAT;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: DateCellRendererComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.7", type: DateCellRendererComponent, isStandalone: true, selector: "tbl-date-cell-renderer", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
        {{ valueAsString() | date: dateFormat }}
  `, isInline: true, dependencies: [{ kind: "pipe", type: DatePipe, name: "date" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: DateCellRendererComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "tbl-date-cell-renderer",
                    imports: [DatePipe],
                    template: `
        {{ valueAsString() | date: dateFormat }}
  `,
                }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }] } });

class FilesCellRendererComponent {
    apiPrefix = inject(APP_CONFIG).apiPrefix;
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    options = input.required(...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    isImg = computed(() => {
        const cellValue = this.cellValue();
        const { mediaType } = this.options().controlOptions ?? {};
        if (!cellValue)
            return false;
        return mediaType === "image";
    }, ...(ngDevMode ? [{ debugName: "isImg" }] : /* istanbul ignore next */ []));
    imgSrc = computed(() => {
        const cellValue = this.cellValue();
        if (!cellValue)
            return "";
        if (!this.isImg())
            return "";
        let portrait = cellValue;
        if (this.options().controlOptions?.multiple &&
            isArray(cellValue)) {
            const portraitImg = cellValue.find((val) => val.portrait);
            portrait = portraitImg?.name || cellValue[0]?.name;
        }
        if (!portrait) {
            return "";
        }
        return `${this.apiPrefix}${portrait}`;
    }, ...(ngDevMode ? [{ debugName: "imgSrc" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FilesCellRendererComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: FilesCellRendererComponent, isStandalone: true, selector: "tbl-files-cell-renderer", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    @if (isImg()) {
      <img [src]="imgSrc()" width="30" height="30" class="cell-image"/>
    } @else {
      <i class="pi pi-file"></i>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FilesCellRendererComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "tbl-files-cell-renderer",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (isImg()) {
      <img [src]="imgSrc()" width="30" height="30" class="cell-image"/>
    } @else {
      <i class="pi pi-file"></i>
    }
  `,
                }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }] } });

class GroupCellRendererComponent {
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    value = computed(() => this.groupCellRenderer(), ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    groupCellRenderer() {
        const cellValue = this.cellValue();
        if (!isObject(cellValue)) {
            return "";
        }
        const information = [];
        const entries = Object.entries(cellValue);
        for (const [, val] of entries) {
            if (!isNil(val)) {
                information.push(`${val}`);
            }
        }
        return information.join(", ");
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: GroupCellRendererComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: GroupCellRendererComponent, isStandalone: true, selector: "tbl-group-cell-renderer", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    <span class="single-line-text">
      {{ value() | slice:0:20 }}
      @if (value().length > 20) {
        <span>...</span>
      }
    </span>
  `, isInline: true, styles: [".single-line-text{display:flex;white-space:nowrap;align-items:center}\n"], dependencies: [{ kind: "pipe", type: SlicePipe, name: "slice" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: GroupCellRendererComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-group-cell-renderer", changeDetection: ChangeDetectionStrategy.OnPush, imports: [SlicePipe], template: `
    <span class="single-line-text">
      {{ value() | slice:0:20 }}
      @if (value().length > 20) {
        <span>...</span>
      }
    </span>
  `, styles: [".single-line-text{display:flex;white-space:nowrap;align-items:center}\n"] }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }] } });

class MultiselectCellRendererComponent {
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    options = input.required(...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    isChip = computed(() => this.options().columnOptions?.valueAsChip ?? true, ...(ngDevMode ? [{ debugName: "isChip" }] : /* istanbul ignore next */ []));
    selectOptions = computed(() => {
        const cellValue = this.cellValue();
        if (isArray(cellValue)) {
            return cellValue
                .map((val) => this.options().options?.find((opt) => opt.value === val))
                .filter((val) => !!val)
                .map((val) => ({
                ...val,
                styleClass: `${val.styleClass}${this.isChip() ? " p-chip" : ""}`,
            }));
        }
        return [];
    }, ...(ngDevMode ? [{ debugName: "selectOptions" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: MultiselectCellRendererComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: MultiselectCellRendererComponent, isStandalone: true, selector: "tbl-multiselect-cell-renderer", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, host: { styleAttribute: "display: flex; gap: 0.25rem;" }, ngImport: i0, template: `
    @for (option of selectOptions(); track option) {
        <span [class]="option.styleClass">
            {{option.label}}
        </span>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: MultiselectCellRendererComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "tbl-multiselect-cell-renderer",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @for (option of selectOptions(); track option) {
        <span [class]="option.styleClass">
            {{option.label}}
        </span>
    }
  `,
                    host: {
                        style: "display: flex; gap: 0.25rem;",
                    },
                }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }] } });

class SelectCellRendererComponent {
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    options = input.required(...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    isChip = computed(() => this.options().columnOptions?.valueAsChip ?? true, ...(ngDevMode ? [{ debugName: "isChip" }] : /* istanbul ignore next */ []));
    value = computed(() => {
        const cellValue = this.cellValue();
        const fullOption = this.options().options?.find((opt) => opt.value === cellValue);
        if (!fullOption)
            return null;
        return {
            ...fullOption,
            styleClass: `${fullOption.styleClass}${this.isChip() ? " p-chip" : ""}`,
        };
    }, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SelectCellRendererComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: SelectCellRendererComponent, isStandalone: true, selector: "tbl-select-cell-renderer", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    @let val = value();
    @if (val) {
        <span [class]="val.styleClass">
            {{val.label}}
        </span>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: SelectCellRendererComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "tbl-select-cell-renderer",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @let val = value();
    @if (val) {
        <span [class]="val.styleClass">
            {{val.label}}
        </span>
    }
  `,
                }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }] } });

class WysiwygCellRendererComponent {
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    value = computed(() => {
        const cellValue = this.cellValue();
        if (!isString(cellValue)) {
            return "";
        }
        return this.cleanWysiwygContent(cellValue);
    }, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    cleanWysiwygContent(value) {
        // Simple sanitization: remove script tags and potentially harmful attributes
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = value;
        // Remove script tags
        const scripts = tempDiv.getElementsByTagName("script");
        for (let i = scripts.length - 1; i >= 0; i--) {
            scripts[i].parentNode?.removeChild(scripts[i]);
        }
        // Return text content only
        return tempDiv.textContent || tempDiv.innerText || "";
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: WysiwygCellRendererComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: WysiwygCellRendererComponent, isStandalone: true, selector: "tbl-wysiwyg-cell-renderer", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    {{ value() | slice:0:20 }}
    @if (value().length > 20) {
      <span>...</span>
    }
  `, isInline: true, dependencies: [{ kind: "pipe", type: SlicePipe, name: "slice" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: WysiwygCellRendererComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "tbl-wysiwyg-cell-renderer",
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [SlicePipe],
                    template: `
    {{ value() | slice:0:20 }}
    @if (value().length > 20) {
      <span>...</span>
    }
  `,
                }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }] } });

class TableCellComponent {
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    options = input.required(...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    ControlTypes = CONTROL_TYPES;
    customCellRenderer = computed(() => this.options().columnOptions?.customCellRenderer, ...(ngDevMode ? [{ debugName: "customCellRenderer" }] : /* istanbul ignore next */ []));
    customRenderedValue = computed(() => {
        const renderer = this.customCellRenderer();
        if (!renderer)
            return null;
        return renderer(this.cellValue());
    }, ...(ngDevMode ? [{ debugName: "customRenderedValue" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableCellComponent, isStandalone: true, selector: "tbl-table-cell", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "@if (customCellRenderer()) {\n    <span [innerHTML]=\"customRenderedValue()\"></span>\n} @else {\n    @switch (options().controlType) {\n        @case (ControlTypes.CHECKBOX) {\n            <tbl-checkbox-cell-renderer [cellValue]=\"cellValue()\" />\n        }\n        @case (ControlTypes.DATE) {\n            <tbl-date-cell-renderer [cellValue]=\"cellValue()\" />\n        }\n        @case (ControlTypes.FILES) {\n            <tbl-files-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.MULTISELECT) {\n            <tbl-multiselect-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.PICKLIST) {\n            <tbl-multiselect-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.RADIO) {\n            <tbl-select-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.SELECT) {\n            <tbl-select-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.WYSIWYG) {\n            <tbl-wysiwyg-cell-renderer [cellValue]=\"cellValue()\" />\n        }\n        @case (ControlTypes.GROUP) {\n            <tbl-group-cell-renderer [cellValue]=\"cellValue()\" />\n        }\n        @case (ControlTypes.CUSTOM) {\n            @let component = options().columnOptions?.customComponent;\n            @if (component) {\n            <ng-container \n                *ngComponentOutlet=\"\n                    component;\n                    inputs: { \n                        cellValue: cellValue(),\n                        options: options() \n                    };\n                \"\n            />\n            } @else {\n            <i class=\"pi pi-exclamation-triangle orange\" \n                title=\"You must provide a custom component\">\n            </i>\n            }\n        }\n        @default {\n            <span>{{ cellValue() }}</span>\n        }\n    }\n}", dependencies: [{ kind: "component", type: DateCellRendererComponent, selector: "tbl-date-cell-renderer", inputs: ["cellValue"] }, { kind: "component", type: CheckboxCellRendererComponent, selector: "tbl-checkbox-cell-renderer", inputs: ["cellValue"] }, { kind: "component", type: FilesCellRendererComponent, selector: "tbl-files-cell-renderer", inputs: ["cellValue", "options"] }, { kind: "component", type: MultiselectCellRendererComponent, selector: "tbl-multiselect-cell-renderer", inputs: ["cellValue", "options"] }, { kind: "component", type: SelectCellRendererComponent, selector: "tbl-select-cell-renderer", inputs: ["cellValue", "options"] }, { kind: "component", type: WysiwygCellRendererComponent, selector: "tbl-wysiwyg-cell-renderer", inputs: ["cellValue"] }, { kind: "component", type: GroupCellRendererComponent, selector: "tbl-group-cell-renderer", inputs: ["cellValue"] }, { kind: "directive", type: NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletEnvironmentInjector", "ngComponentOutletContent", "ngComponentOutletNgModule"], exportAs: ["ngComponentOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableCellComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-table-cell", changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        DateCellRendererComponent,
                        CheckboxCellRendererComponent,
                        FilesCellRendererComponent,
                        MultiselectCellRendererComponent,
                        SelectCellRendererComponent,
                        WysiwygCellRendererComponent,
                        GroupCellRendererComponent,
                        NgComponentOutlet,
                    ], template: "@if (customCellRenderer()) {\n    <span [innerHTML]=\"customRenderedValue()\"></span>\n} @else {\n    @switch (options().controlType) {\n        @case (ControlTypes.CHECKBOX) {\n            <tbl-checkbox-cell-renderer [cellValue]=\"cellValue()\" />\n        }\n        @case (ControlTypes.DATE) {\n            <tbl-date-cell-renderer [cellValue]=\"cellValue()\" />\n        }\n        @case (ControlTypes.FILES) {\n            <tbl-files-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.MULTISELECT) {\n            <tbl-multiselect-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.PICKLIST) {\n            <tbl-multiselect-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.RADIO) {\n            <tbl-select-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.SELECT) {\n            <tbl-select-cell-renderer [cellValue]=\"cellValue()\" [options]=\"options()\" />\n        }\n        @case (ControlTypes.WYSIWYG) {\n            <tbl-wysiwyg-cell-renderer [cellValue]=\"cellValue()\" />\n        }\n        @case (ControlTypes.GROUP) {\n            <tbl-group-cell-renderer [cellValue]=\"cellValue()\" />\n        }\n        @case (ControlTypes.CUSTOM) {\n            @let component = options().columnOptions?.customComponent;\n            @if (component) {\n            <ng-container \n                *ngComponentOutlet=\"\n                    component;\n                    inputs: { \n                        cellValue: cellValue(),\n                        options: options() \n                    };\n                \"\n            />\n            } @else {\n            <i class=\"pi pi-exclamation-triangle orange\" \n                title=\"You must provide a custom component\">\n            </i>\n            }\n        }\n        @default {\n            <span>{{ cellValue() }}</span>\n        }\n    }\n}" }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }] } });

class TableFilterCellComponent {
    filterService = inject(FilterService);
    col = input.required(...(ngDevMode ? [{ debugName: "col" }] : /* istanbul ignore next */ []));
    dt = input.required(...(ngDevMode ? [{ debugName: "dt" }] : /* istanbul ignore next */ []));
    filterLevel = input.required(...(ngDevMode ? [{ debugName: "filterLevel" }] : /* istanbul ignore next */ []));
    ControlType = CONTROL_TYPES;
    dateRange = [];
    DATE_FORMAT = DATE_FORMAT_CALENDAR;
    numberRange = [0, 200];
    get options() {
        return this.col().options || [];
    }
    filterValue = linkedSignal(() => {
        const filterMeta = this.dt().filters?.[this.col().key];
        return isArray(filterMeta) ? filterMeta[0].value : filterMeta?.value;
    }, ...(ngDevMode ? [{ debugName: "filterValue" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        const col = this.col();
        const isDateControl = col.controlType === CONTROL_TYPES.DATE;
        if (isDateControl) {
            this.initDateRangeFilter();
        }
    }
    initDateRangeFilter() {
        this.filterService.register("dateRange", (cellValue, filterValue) => {
            return this.dateRangeFilter(cellValue, filterValue);
        });
    }
    /**
     * /!\ This method will be triggered when filtering the table without lazy-loading ONLY
     */
    dateRangeFilter(cellValue, filterValue) {
        if (!filterValue) {
            return true;
        }
        if (!cellValue) {
            return false;
        }
        const from = this.dateRange[0];
        const to = this.dateRange[1];
        const fromTimeStamp = getMidnightTimeStamp(from);
        const cellTimeStamp = getMidnightTimeStamp(cellValue);
        if (!to) {
            return cellTimeStamp >= fromTimeStamp;
        }
        const toTimeStamp = getMidnightTimeStamp(to);
        return fromTimeStamp <= cellTimeStamp && toTimeStamp >= cellTimeStamp;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableFilterCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableFilterCellComponent, isStandalone: true, selector: "crd-table-filter-cell", inputs: { col: { classPropertyName: "col", publicName: "col", isSignal: true, isRequired: true, transformFunction: null }, dt: { classPropertyName: "dt", publicName: "dt", isSignal: true, isRequired: true, transformFunction: null }, filterLevel: { classPropertyName: "filterLevel", publicName: "filterLevel", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "\n@switch (col().filterType) {\n  @case (ControlType.DATE) {\n    <ng-container [ngTemplateOutlet]=\"dateTemplate\"></ng-container>\n  }\n  @case (ControlType.CHECKBOX) {\n    <ng-container [ngTemplateOutlet]=\"checkboxTemplate\"></ng-container>\n  }\n  @case (ControlType.SELECT) {\n    <p-columnFilter [field]=\"col().key\" matchMode=\"equals\" [showMenu]=\"false\"\n      [showClearButton]=\"false\">\n      <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n        <p-select \n          [ngModel]=\"value\"\n          [options]=\"options\"\n          (onChange)=\"filter($event.value)\"\n          placeholder=\"---\"\n          filterPlaceholder=\"---\"\n          [showClear]=\"true\"\n          style=\"width: 100%;\">\n          <ng-template let-option pTemplate=\"item\">\n            <div class=\"select-option-container\">\n              @if (option.icon) {\n                <i class=\"pi {{option.icon}}\"></i>\n              }\n              <div>{{ option.label }}</div>\n            </div>\n          </ng-template>\n        </p-select>\n      </ng-template>\n    </p-columnFilter>\n  }\n  @case (ControlType.MULTISELECT) {\n    <p-columnFilter [field]=\"col().key\" matchMode=\"in\" [showMenu]=\"false\"\n      [showClearButton]=\"false\">\n      <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n        <p-multiSelect [ngModel]=\"value\"\n          [options]=\"options\"\n          (onChange)=\"filter($event.value)\"\n          placeholder=\"---\"\n          filterPlaceHolder=\"---\"\n          appendTo=\"body\">\n          <ng-template let-option pTemplate=\"item\">\n            <div class=\"select-option-container\">\n              @if (option.icon) {\n                <i class=\"pi {{option.icon}}\"></i>\n              }\n              <div>{{ option.label }}</div>\n            </div>\n          </ng-template>\n        </p-multiSelect>\n      </ng-template>\n    </p-columnFilter>\n  }\n  @case (ControlType.FILES) {\n    <!-- TODO -->\n  }\n  @case (ControlType.INPUT) {\n    @if (col().type === 'text' && filterLevel() === \"basic\") {\n      <ng-container [ngTemplateOutlet]=\"basicInputTemplate\"></ng-container>\n    }\n\n    @if (col().type === 'text' && filterLevel() === \"intermediate\") {\n      <ng-container [ngTemplateOutlet]=\"intermediateInputTemplate\"></ng-container>\n    }\n\n    @if (col().type === 'number') {\n      <p-columnFilter type=\"numeric\" [field]=\"col().key\" display=\"menu\" \n        [showMatchModes]=\"false\"\n        [showOperator]=\"false\"\n        [showAddButton]=\"false\"\n        [showClearButton]=\"false\"\n        [showApplyButton]=\"false\"\n      />\n    }\n  }\n  @default {\n    <ng-container [ngTemplateOutlet]=\"basicInputTemplate\"></ng-container>\n  }\n}\n\n<ng-template #basicInputTemplate>\n  <p-columnFilter type=\"text\" \n    [field]=\"col().key\" \n    matchMode=\"contains\" \n    [showClearButton]=\"false\" \n    [showMenu]=\"false\">\n    <ng-template pTemplate=\"filter\" let-filter=\"filterCallback\">\n      <input type=\"text\" \n        pInputText\n        (keyup)=\"filter($any($event.target).value)\" \n      />\n    </ng-template>\n  </p-columnFilter>\n</ng-template>\n\n<ng-template #intermediateInputTemplate>\n  <p-columnFilter type=\"text\" [field]=\"col().key\">\n    <ng-template pTemplate=\"filter\" let-filter=\"filterCallback\">\n      <input type=\"text\" \n        pInputText \n        (keyup)=\"filter($any($event.target).value)\" \n      />\n    </ng-template>\n  </p-columnFilter>\n</ng-template>\n\n<ng-template #checkboxTemplate>\n  <p-columnFilter\n    type=\"boolean\"\n    matchMode=\"equals\"\n    [field]=\"col().key\"\n    [showMenu]=\"false\">\n  </p-columnFilter>\n</ng-template>\n\n<ng-template #dateTemplate>\n  <p-columnFilter matchMode=\"dateRange\" [field]=\"col().key\" [showMenu]=\"false\">\n    <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n      <p-datepicker\n        [(ngModel)]=\"dateRange\"\n        selectionMode=\"range\"\n        [readonlyInput]=\"true\"\n        [showButtonBar]=\"true\"\n        [dateFormat]=\"DATE_FORMAT\"\n        appendTo=\"body\"\n        (onSelect)=\"filter(dateRange)\"\n        (onClearClick)=\"filter('', col(), 'equals')\"\n      />\n    </ng-template>\n  </p-columnFilter>\n</ng-template>", styles: [":host{display:block;padding:2px}::ng-deep p-columnfilter p-datepicker .p-datepicker .p-inputtext,::ng-deep p-columnfilter p-columnfilterformelement,::ng-deep p-columnfilter .p-inputtext,::ng-deep p-columnfilter .p-multiselect{width:100%!important}.select-option-container{display:flex;align-items:center}.select-option-container i{margin-right:5px}p-slider{margin-top:1rem;display:block}.flex-space{margin-top:1rem;display:flex;justify-content:space-between}\n"], dependencies: [{ kind: "ngmodule", type: TableModule }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "component", type: i1$b.ColumnFilter, selector: "p-columnFilter, p-column-filter, p-columnfilter", inputs: ["field", "type", "display", "showMenu", "matchMode", "operator", "showOperator", "showClearButton", "showApplyButton", "showMatchModes", "showAddButton", "hideOnClear", "placeholder", "matchModeOptions", "maxConstraints", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "locale", "localeMatcher", "currency", "currencyDisplay", "filterOn", "useGrouping", "showButtons", "ariaLabel", "filterButtonProps", "motionOptions"], outputs: ["onShow", "onHide"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: DatePickerModule }, { kind: "component", type: i1$2.DatePicker, selector: "p-datePicker, p-datepicker, p-date-picker", inputs: ["iconDisplay", "styleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "ariaLabelledBy", "ariaLabel", "iconAriaLabel", "dateFormat", "multipleSeparator", "rangeSeparator", "inline", "showOtherMonths", "selectOtherMonths", "showIcon", "icon", "readonlyInput", "shortYearCutoff", "hourFormat", "timeOnly", "stepHour", "stepMinute", "stepSecond", "showSeconds", "showOnFocus", "showWeek", "startWeekFromFirstDayOfYear", "showClear", "dataType", "selectionMode", "maxDateCount", "showButtonBar", "todayButtonStyleClass", "clearButtonStyleClass", "autofocus", "autoZIndex", "baseZIndex", "panelStyleClass", "panelStyle", "keepInvalid", "hideOnDateTimeSelect", "touchUI", "timeSeparator", "focusTrap", "showTransitionOptions", "hideTransitionOptions", "tabindex", "minDate", "maxDate", "disabledDates", "disabledDays", "showTime", "responsiveOptions", "numberOfMonths", "firstDayOfWeek", "view", "defaultDate", "appendTo", "motionOptions"], outputs: ["onFocus", "onBlur", "onClose", "onSelect", "onClear", "onInput", "onTodayClick", "onClearClick", "onMonthChange", "onYearChange", "onClickOutside", "onShow"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: SelectModule }, { kind: "component", type: i1$a.Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "styleClass", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "ngmodule", type: MultiSelectModule }, { kind: "component", type: i1$5.MultiSelect, selector: "p-multiSelect, p-multiselect, p-multi-select", inputs: ["id", "ariaLabel", "styleClass", "panelStyle", "panelStyleClass", "inputId", "readonly", "group", "filter", "filterPlaceHolder", "filterLocale", "overlayVisible", "tabindex", "dataKey", "ariaLabelledBy", "displaySelectedLabel", "maxSelectedLabels", "selectionLimit", "selectedItemsLabel", "showToggleAll", "emptyFilterMessage", "emptyMessage", "resetFilterOnHide", "dropdownIcon", "chipIcon", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "showHeader", "filterBy", "scrollHeight", "lazy", "virtualScroll", "loading", "virtualScrollItemSize", "loadingIcon", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "autofocusFilter", "display", "autocomplete", "showClear", "autofocus", "placeholder", "options", "filterValue", "selectAll", "focusOnHover", "filterFields", "selectOnFocus", "autoOptionFocus", "highlightOnSelect", "size", "variant", "fluid", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onClear", "onPanelShow", "onPanelHide", "onLazyLoad", "onRemove", "onSelectAllChange"] }, { kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i1$4.InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "ngmodule", type: SliderModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableFilterCellComponent, decorators: [{
            type: Component,
            args: [{ selector: "crd-table-filter-cell", imports: [
                        TableModule,
                        SharedModule,
                        DatePickerModule,
                        FormsModule,
                        NgTemplateOutlet,
                        SelectModule,
                        MultiSelectModule,
                        InputTextModule,
                        SliderModule,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "\n@switch (col().filterType) {\n  @case (ControlType.DATE) {\n    <ng-container [ngTemplateOutlet]=\"dateTemplate\"></ng-container>\n  }\n  @case (ControlType.CHECKBOX) {\n    <ng-container [ngTemplateOutlet]=\"checkboxTemplate\"></ng-container>\n  }\n  @case (ControlType.SELECT) {\n    <p-columnFilter [field]=\"col().key\" matchMode=\"equals\" [showMenu]=\"false\"\n      [showClearButton]=\"false\">\n      <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n        <p-select \n          [ngModel]=\"value\"\n          [options]=\"options\"\n          (onChange)=\"filter($event.value)\"\n          placeholder=\"---\"\n          filterPlaceholder=\"---\"\n          [showClear]=\"true\"\n          style=\"width: 100%;\">\n          <ng-template let-option pTemplate=\"item\">\n            <div class=\"select-option-container\">\n              @if (option.icon) {\n                <i class=\"pi {{option.icon}}\"></i>\n              }\n              <div>{{ option.label }}</div>\n            </div>\n          </ng-template>\n        </p-select>\n      </ng-template>\n    </p-columnFilter>\n  }\n  @case (ControlType.MULTISELECT) {\n    <p-columnFilter [field]=\"col().key\" matchMode=\"in\" [showMenu]=\"false\"\n      [showClearButton]=\"false\">\n      <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n        <p-multiSelect [ngModel]=\"value\"\n          [options]=\"options\"\n          (onChange)=\"filter($event.value)\"\n          placeholder=\"---\"\n          filterPlaceHolder=\"---\"\n          appendTo=\"body\">\n          <ng-template let-option pTemplate=\"item\">\n            <div class=\"select-option-container\">\n              @if (option.icon) {\n                <i class=\"pi {{option.icon}}\"></i>\n              }\n              <div>{{ option.label }}</div>\n            </div>\n          </ng-template>\n        </p-multiSelect>\n      </ng-template>\n    </p-columnFilter>\n  }\n  @case (ControlType.FILES) {\n    <!-- TODO -->\n  }\n  @case (ControlType.INPUT) {\n    @if (col().type === 'text' && filterLevel() === \"basic\") {\n      <ng-container [ngTemplateOutlet]=\"basicInputTemplate\"></ng-container>\n    }\n\n    @if (col().type === 'text' && filterLevel() === \"intermediate\") {\n      <ng-container [ngTemplateOutlet]=\"intermediateInputTemplate\"></ng-container>\n    }\n\n    @if (col().type === 'number') {\n      <p-columnFilter type=\"numeric\" [field]=\"col().key\" display=\"menu\" \n        [showMatchModes]=\"false\"\n        [showOperator]=\"false\"\n        [showAddButton]=\"false\"\n        [showClearButton]=\"false\"\n        [showApplyButton]=\"false\"\n      />\n    }\n  }\n  @default {\n    <ng-container [ngTemplateOutlet]=\"basicInputTemplate\"></ng-container>\n  }\n}\n\n<ng-template #basicInputTemplate>\n  <p-columnFilter type=\"text\" \n    [field]=\"col().key\" \n    matchMode=\"contains\" \n    [showClearButton]=\"false\" \n    [showMenu]=\"false\">\n    <ng-template pTemplate=\"filter\" let-filter=\"filterCallback\">\n      <input type=\"text\" \n        pInputText\n        (keyup)=\"filter($any($event.target).value)\" \n      />\n    </ng-template>\n  </p-columnFilter>\n</ng-template>\n\n<ng-template #intermediateInputTemplate>\n  <p-columnFilter type=\"text\" [field]=\"col().key\">\n    <ng-template pTemplate=\"filter\" let-filter=\"filterCallback\">\n      <input type=\"text\" \n        pInputText \n        (keyup)=\"filter($any($event.target).value)\" \n      />\n    </ng-template>\n  </p-columnFilter>\n</ng-template>\n\n<ng-template #checkboxTemplate>\n  <p-columnFilter\n    type=\"boolean\"\n    matchMode=\"equals\"\n    [field]=\"col().key\"\n    [showMenu]=\"false\">\n  </p-columnFilter>\n</ng-template>\n\n<ng-template #dateTemplate>\n  <p-columnFilter matchMode=\"dateRange\" [field]=\"col().key\" [showMenu]=\"false\">\n    <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n      <p-datepicker\n        [(ngModel)]=\"dateRange\"\n        selectionMode=\"range\"\n        [readonlyInput]=\"true\"\n        [showButtonBar]=\"true\"\n        [dateFormat]=\"DATE_FORMAT\"\n        appendTo=\"body\"\n        (onSelect)=\"filter(dateRange)\"\n        (onClearClick)=\"filter('', col(), 'equals')\"\n      />\n    </ng-template>\n  </p-columnFilter>\n</ng-template>", styles: [":host{display:block;padding:2px}::ng-deep p-columnfilter p-datepicker .p-datepicker .p-inputtext,::ng-deep p-columnfilter p-columnfilterformelement,::ng-deep p-columnfilter .p-inputtext,::ng-deep p-columnfilter .p-multiselect{width:100%!important}.select-option-container{display:flex;align-items:center}.select-option-container i{margin-right:5px}p-slider{margin-top:1rem;display:block}.flex-space{margin-top:1rem;display:flex;justify-content:space-between}\n"] }]
        }], propDecorators: { col: [{ type: i0.Input, args: [{ isSignal: true, alias: "col", required: true }] }], dt: [{ type: i0.Input, args: [{ isSignal: true, alias: "dt", required: true }] }], filterLevel: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLevel", required: true }] }] } });

/**
 * Converts a CRUD item configuration into a table column configuration.
 *
 * @param item - The CRUD item options containing field configuration and display settings
 * @param storedConfig - Optional array of stored column configurations with visibility settings.
 *                       Defaults to an empty array if not provided.
 *
 * @returns A TableColumn object with merged configuration including:
 *          - Column visibility based on stored config or hidden flags
 *          - Cell renderer for displaying values
 *          - Tooltip configuration
 *          - Filter and sort settings
 *          - All original item and column options
 *
 * @remarks
 * - Visibility priority: stored config > soft/hard hidden flags
 * - Uses CellRenderer to format cell values and tooltips
 * - Filterable and sortable are enabled by default unless explicitly disabled
 * - Filter type defaults to the item's control type if not specified
 */
function crudItemToColumn(item, storedConfig = []) {
    const columnOptions = item.columnOptions || {};
    const isHidden = columnOptions.isSoftHidden || columnOptions.isHardHidden;
    const isVisible = 
    // biome-ignore lint/suspicious/noDoubleEquals: key may be number or string
    storedConfig.find((col) => col.key == item.key)?.isVisible ?? !isHidden;
    return {
        ...item,
        ...columnOptions,
        key: item.key.toString(),
        isVisible,
        filterable: columnOptions.filterable !== false,
        sortable: columnOptions.sortable !== false,
        filterType: columnOptions.filterType ?? item.controlType,
    };
}

/**
 * Map of validator names to their corresponding ValidatorFn
 * Used to check for the presence of specific validators in a column's validator array
 * Currently supports 'required' validator
 */
const validatorMap = {
    required: required,
};
class HasValidatorPipe {
    transform(colValidators, validatorToCheck /**| "minLength" | "maxLength" | "min" | "max"*/) {
        const validatorFn = validatorMap[validatorToCheck];
        return colValidators.includes(validatorFn);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: HasValidatorPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.7", ngImport: i0, type: HasValidatorPipe, isStandalone: true, name: "hasValidator" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: HasValidatorPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "hasValidator",
                }]
        }] });

class TableControlComponent extends FormFieldBaseComponent {
    labels = inject(CRUD_LABELS);
    value = linkedSignal(() => {
        const controlValue = this.control().value;
        if (!isArray(controlValue)) {
            return [];
        }
        return controlValue.map((item) => ({
            ...item,
            internal_id: this.getUniqueRowKey(),
        }));
    }, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    tableCtrlConfig = computed(() => {
        return this.options().tableCtrlConfig ?? {};
    }, ...(ngDevMode ? [{ debugName: "tableCtrlConfig" }] : /* istanbul ignore next */ []));
    isHeaderHidden = computed(() => {
        return this.tableCtrlConfig().isHeaderHidden ?? false;
    }, ...(ngDevMode ? [{ debugName: "isHeaderHidden" }] : /* istanbul ignore next */ []));
    isSelectable = computed(() => {
        return (this.tableCtrlConfig().selectable ||
            this.tableCtrlConfig().isDeletionEnabled);
    }, ...(ngDevMode ? [{ debugName: "isSelectable" }] : /* istanbul ignore next */ []));
    ControlType = CONTROL_TYPES;
    selectedRows = signal([], ...(ngDevMode ? [{ debugName: "selectedRows" }] : /* istanbul ignore next */ []));
    columns = computed(() => {
        const cols = this.options().tableCtrlColumns ?? [];
        const config = this.options().tableCtrlConfig ?? {};
        const sortedColKeys = config.sortedColumnKeys ?? [];
        const sortedColumns = sortedColKeys.length
            ? sortedColKeys
                .map((key) => cols.find((item) => item.key === key))
                .filter((item) => !!item)
            : cols;
        return sortedColumns
            .map((col) => crudItemToColumn(col))
            .filter((col) => col.isVisible);
    }, ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    editionMode = computed(() => {
        return this.options().tableCtrlConfig?.editionMode ?? "cell";
    }, ...(ngDevMode ? [{ debugName: "editionMode" }] : /* istanbul ignore next */ []));
    /** Saved original row in case of cancel (used in **row** edition mode) */
    clonedRow = null;
    /** This property holds the index of the row with unsaved changes.
     * Used in **row** edition mode
     * Only for **multiselect** because we can go out of the cell without saving changes
     */
    rowIndexWithUnsavedChanges = signal(null, ...(ngDevMode ? [{ debugName: "rowIndexWithUnsavedChanges" }] : /* istanbul ignore next */ []));
    onDeleteRows() {
        const selectedIndexes = this.selectedRows().map((row) => this.value().indexOf(row));
        const newRows = this.value().filter((_, index) => !selectedIndexes.includes(index));
        this.control().setValue(newRows);
        this.value.set(newRows);
        this.selectedRows.set([]);
    }
    onAddNewRow() {
        const newRow = this.columns().reduce((acc, col) => {
            acc[col.key] = null;
            return acc;
        }, {});
        const newRows = [
            ...this.value(),
            { ...newRow, internal_id: this.getUniqueRowKey() },
        ];
        this.control().setValue(newRows);
        this.value.set(newRows);
    }
    onCellClicked(item, index) {
        if (this.isDisabled())
            return;
        this.emitInteractionEvent("cellClicked", {
            row: item,
            index: index,
        });
    }
    onMultiselectChange(rowIndex) {
        if (this.editionMode() === "row") {
            this.rowIndexWithUnsavedChanges.set(rowIndex);
        }
    }
    // Multiselect is kinda special because we can't use double data-binding
    // So we must update manually the value in row edition mode, but the value will be saved
    // only when user clicks on save button
    saveMultiselectValue(newValue, colKey, rowIndex) {
        if (this.editionMode() === "row") {
            this.rowIndexWithUnsavedChanges.set(null);
            this.value.update((rows) => {
                rows[rowIndex] = {
                    ...rows[rowIndex],
                    [colKey]: newValue,
                };
                return rows;
            });
        }
        else if (this.editionMode() === "cell") {
            this.saveCellValue(newValue, colKey, rowIndex);
        }
    }
    saveCellValue(value, colKey, rowIndex) {
        if (this.editionMode() !== "cell")
            return;
        const newRows = this.value().map((r, index) => {
            if (index === rowIndex) {
                return {
                    ...r,
                    [colKey]: value,
                };
            }
            return r;
        });
        this.control().setValue(newRows);
        this.value.set(newRows);
        this.emitInteractionEvent("cellEditComplete", {
            rowIndex,
            colKey,
            value,
        });
    }
    onRowEditCancel(rowIndex) {
        if (this.clonedRow) {
            const newRows = this.value().map((r, index) => {
                return index === rowIndex ? this.clonedRow : r;
            });
            this.control().setValue(newRows);
            this.value.set(newRows);
            this.clonedRow = null;
            this.emitInteractionEvent("rowEditCancel", {
                value: newRows,
                clonedRow: this.clonedRow,
            });
        }
    }
    onRowEditSave() {
        this.clonedRow = null;
        this.control().setValue(this.value());
        this.emitInteractionEvent("rowEditComplete", {
            value: this.value(),
        });
    }
    onRowEditInit(row) {
        this.clonedRow = { ...row };
        this.emitInteractionEvent("rowEditInit", {
            row,
        });
    }
    onSelectionChanged() {
        this.emitInteractionEvent("rowsSelectionChange", {
            selectedRows: this.selectedRows(),
        });
    }
    getUniqueRowKey() {
        return Date.now() + Math.random();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableControlComponent, isStandalone: true, selector: "frm-table-control", host: { properties: { "class.p-disabled": "isDisabled()" } }, usesInheritance: true, ngImport: i0, template: "@let defaultWidth = \"120px\";\n\n<p-table\n    class=\"table-control\"\n    #dataTable\n    [value]=\"value()\"\n    dataKey=\"internal_id\"\n    [(selection)]=\"selectedRows\"\n    (selectionChange)=\"onSelectionChanged()\"\n    [editMode]=\"editionMode() === 'row' ? 'row' : 'cell'\"\n    showGridlines \n    [scrollable]=\"true\"\n    scrollHeight=\"400px\">\n\n    <ng-template #caption>\n        @if (tableCtrlConfig().isCreationEnabled) {\n            <p-button \n                icon=\"pi pi-plus\" \n                [label]=\"labels.tableControl.add\" \n                (onClick)=\"onAddNewRow()\" \n            />\n        }\n        @if (tableCtrlConfig().isDeletionEnabled) {\n            <p-button [outlined]=\"true\" \n                severity=\"danger\" \n                icon=\"pi pi-trash\" \n                [label]=\"labels.tableControl.delete\" \n                [disabled]=\"!selectedRows().length\"\n                (onClick)=\"onDeleteRows()\"\n            />\n        }\n    </ng-template>\n\n    <ng-template pTemplate=\"emptymessage\">\n        <tr>\n            <td [attr.colspan]=\"columns().length\"\n                >{{ labels.tableControl.noData }}\n            </td>\n        </tr>\n    </ng-template>\n    <ng-template pTemplate=\"header\">\n        @if (!isHeaderHidden()) {\n            <tr>\n                @if (isSelectable()) {\n                    <th class=\"w-3rem\" scope=\"col\" pFrozenColumn [frozen]=\"true\">\n                        <p-tableHeaderCheckbox />\n                    </th>\n                }\n                @for (col of columns(); track col.key) {\n                    @let sortable = tableCtrlConfig().sortable && col.sortable;                \n                    <th scope=\"col\" \n                        [pSortableColumnDisabled]=\"!sortable\"\n                        [pSortableColumn]=\"col.key\"\n                        pFrozenColumn\n                        [style.minWidth]=\"defaultWidth\"\n                        [style.maxWidth]=\"defaultWidth\">\n                        {{ col.label }}\n                        @if (sortable) {\n                            <p-sortIcon [field]=\"col.key\"></p-sortIcon>\n                        }\n                    </th>\n                }\n                @if (editionMode() === \"row\") {\n                    <th scope=\"col\">\n                        {{ labels.tableControl.actionsColumnHeader }}\n                    </th>\n                }\n            </tr>\n            @if (tableCtrlConfig().filterable) {\n                <tr>\n                    @if (isSelectable()) {\n                        <th scope=\"col\" pFrozenColumn [frozen]=\"true\"></th>\n                    }\n                    @for (col of columns(); track col.key) {       \n                        <th\n                            class=\"filter-row-th\"\n                            pFrozenColumn\n                            scope=\"th\"\n                            [style.minWidth]=\"defaultWidth\"\n                            [style.maxWidth]=\"defaultWidth\">\n                            @if (col.filterable) {\n                                <crd-table-filter-cell \n                                    [col]=\"col\"\n                                    [dt]=\"dataTable\"\n                                    filterLevel=\"basic\"\n                                />\n                            }\n                        </th>                \n                    }\n                    @if (editionMode() === \"row\") {\n                        <th scope=\"col\"></th>\n                    }\n                </tr>\n            }\n        }\n    </ng-template>\n    <ng-template pTemplate=\"body\" \n        let-item \n        let-editing=\"editing\" \n        let-index=\"rowIndex\">\n        <tr [pEditableRow]=\"item\" \n            [pEditableRowDisabled]=\"editionMode() !== 'row'\"\n            (click)=\"onCellClicked(item, index)\">\n            @if (isSelectable()) {\n                <td pFrozenColumn [frozen]=\"true\">\n                    <p-tableCheckbox [value]=\"item\" />\n                </td>\n            }\n            @for (col of columns(); track col.key) {\n                @let isCellEditionDisabled = col.isCellEditionDisabled ?? false;\n                @let isEditableInCellMode = !isCellEditionDisabled && !isDisabled() && editionMode() === \"cell\";\n                @let colValidators = col.controlOptions?.validators ?? [];\n                <td  \n                    [style.minWidth]=\"defaultWidth\"\n                    [style.maxWidth]=\"defaultWidth\"\n                    [class.pointer]=\"isEditableInCellMode\"\n                    pFrozenColumn\n                    [pEditableColumnDisabled]=\"!isEditableInCellMode\"\n                    [pEditableColumn]=\"item[col.key]\"\n                    [pEditableColumnField]=\"col.key\">       \n                    @switch (col.controlType) {\n                        @case (ControlType.SELECT) {\n                            <p-cellEditor>                                    \n                                <ng-template pTemplate=\"input\">\n                                    <p-select\n                                        [options]=\"col.options\"\n                                        appendTo=\"body\"\n                                        [(ngModel)]=\"item[col.key]\"\n                                        [disabled]=\"isCellEditionDisabled\"\n                                        [required]=\"colValidators | hasValidator:'required'\"\n                                        (onFocus)=\"emitInteractionEvent('cellEditInit')\"\n                                        (onChange)=\"saveCellValue($event.value, col.key, index)\"\n                                    />\n                                </ng-template>\n                                <ng-template pTemplate=\"output\">\n                                    <ng-container [ngTemplateOutlet]=\"cellTemplate\"/>\n                                </ng-template>\n                            </p-cellEditor>                                \n                        }\n                        @case (ControlType.MULTISELECT) {        \n                            <p-cellEditor>                                    \n                                <ng-template pTemplate=\"input\">\n                                    <p-multiselect #multiselect\n                                        [options]=\"col.options\"\n                                        appendTo=\"body\"\n                                        [ngModel]=\"item[col.key]\"\n                                        [disabled]=\"isCellEditionDisabled\"\n                                        [required]=\"colValidators | hasValidator:'required'\"\n                                        (onFocus)=\"emitInteractionEvent('cellEditInit')\"\n                                        (onChange)=\"onMultiselectChange(index)\">\n                                        <ng-template #footer>\n                                            <div class=\"multiselect-footer\">\n                                                <p-button \n                                                    [label]=\"labels.tableControl.multiselectValidate\"\n                                                    icon=\"pi pi-check\"\n                                                    (onClick)=\"saveMultiselectValue(multiselect.value, col.key, index)\"\n                                                />\n                                            </div>\n                                        </ng-template>                                        \n                                        <ng-template #dropdownicon>\n                                            @if (rowIndexWithUnsavedChanges() === index) {\n                                                <i class=\"pi pi-info-circle\"\n                                                    [pTooltip]=\"labels.tableControl.multiselectUnsavedChanges\">\n                                                </i>\n                                            }\n                                        </ng-template>\n                                    </p-multiselect>\n                                </ng-template>\n                                <ng-template pTemplate=\"output\">\n                                    <ng-container [ngTemplateOutlet]=\"cellTemplate\"/>\n                                </ng-template>\n                            </p-cellEditor>                                \n                        }\n                        @default {\n                            <p-cellEditor>                       \n                                <ng-template pTemplate=\"input\">\n                                    @if (col.type === \"number\") {\n                                        <p-inputNumber #inputNumber\n                                            [id]=\"col.key\"\n                                            locale=\"fr-FR\"\n                                            [(ngModel)]=\"item[col.key]\"\n                                            [disabled]=\"isCellEditionDisabled\"\n                                            [required]=\"colValidators | hasValidator:'required'\"\n                                            (onFocus)=\"emitInteractionEvent('cellEditInit')\"\n                                            (keydown.enter)=\"saveCellValue(inputNumber.value, col.key, index)\"\n                                            (onBlur)=\"saveCellValue(inputNumber.value, col.key, index)\"\n                                            required\n                                        />\n                                    } @else {\n                                        <input #inputText\n                                            pInputText\n                                            [(ngModel)]=\"item[col.key]\"\n                                            type=\"text\" \n                                            [disabled]=\"isCellEditionDisabled\"                                                \n                                            [required]=\"colValidators | hasValidator:'required'\"\n                                            (onFocus)=\"emitInteractionEvent('cellEditInit')\"\n                                            (keydown.enter)=\"saveCellValue(inputText.value, col.key, index)\"\n                                            (onBlur)=\"saveCellValue(inputText.value, col.key, index)\"\n                                        />\n                                    }\n                                </ng-template>\n                                <ng-template pTemplate=\"output\">\n                                    <ng-container [ngTemplateOutlet]=\"cellTemplate\"/>\n                                </ng-template>\n                            </p-cellEditor>\n                        }\n                    }\n                    <ng-template #cellTemplate>\n                        <tbl-table-cell [cellValue]=\"item[col.key]\" [options]=\"col\" />\n                    </ng-template>\n                </td>\n            }\n            @if (editionMode() === \"row\") {\n                <td>\n                    <div class=\"edit-buttons-container\">\n                        @if (!editing) {\n                            <p-button\n                                pInitEditableRow\n                                icon=\"pi pi-pencil\"\n                                text\n                                rounded\n                                severity=\"secondary\"\n                                (click)=\"onRowEditInit(item)\"\n                            />\n                        } @else {\n                            <p-button\n                                pSaveEditableRow\n                                icon=\"pi pi-check\"\n                                text\n                                rounded\n                                severity=\"secondary\"\n                                (click)=\"onRowEditSave()\"\n                            />\n                            <p-button\n                                pCancelEditableRow\n                                icon=\"pi pi-times\"\n                                text\n                                rounded\n                                severity=\"secondary\"\n                                (click)=\"onRowEditCancel(index)\"\n                            />\n                        }\n                    </div>\n                </td>\n            }\n        </tr>\n    </ng-template>\n</p-table>\n", styles: [".table-control .p-datatable-header{display:flex;justify-content:flex-end;gap:.5rem;padding:.5rem}.table-control th,.table-control td{text-align:center}.table-control th.pointer,.table-control td.pointer{cursor:pointer}.table-control tr{height:40px}.table-control .p-dropdown-label,.table-control .p-inputtext{padding:.5rem}.table-control .multiselect-footer{text-align:right;margin:.5rem}.table-control .edit-buttons-container{display:flex;justify-content:center;gap:.5rem;width:100px}\n"], dependencies: [{ kind: "ngmodule", type: TableModule }, { kind: "component", type: i1$b.Table, selector: "p-table", inputs: ["frozenColumns", "frozenValue", "styleClass", "tableStyle", "tableStyleClass", "paginator", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorStyleClass", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "selectionMode", "selectionPageOnly", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "rowSelectable", "rowTrackBy", "lazy", "lazyLoadOnInit", "compareSelectionBy", "csvSeparator", "exportFilename", "filters", "globalFilterFields", "filterDelay", "filterLocale", "expandedRowKeys", "editingRowKeys", "rowExpandMode", "scrollable", "rowGroupMode", "scrollHeight", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "virtualScrollDelay", "frozenWidth", "contextMenu", "resizableColumns", "columnResizeMode", "reorderableColumns", "loading", "loadingIcon", "showLoader", "rowHover", "customSort", "showInitialSortBadge", "exportFunction", "exportHeader", "stateKey", "stateStorage", "editMode", "groupRowsBy", "size", "showGridlines", "stripedRows", "groupRowsByOrder", "responsiveLayout", "breakpoint", "paginatorLocale", "value", "columns", "first", "rows", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection", "selectAll"], outputs: ["contextMenuSelectionChange", "selectAllChange", "selectionChange", "onRowSelect", "onRowUnselect", "onPage", "onSort", "onFilter", "onLazyLoad", "onRowExpand", "onRowCollapse", "onContextMenuSelect", "onColResize", "onColReorder", "onRowReorder", "onEditInit", "onEditComplete", "onEditCancel", "onHeaderCheckboxToggle", "sortFunction", "firstChange", "rowsChange", "onStateSave", "onStateRestore"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: i1$b.SortableColumn, selector: "[pSortableColumn]", inputs: ["pSortableColumn", "pSortableColumnDisabled"] }, { kind: "directive", type: i1$b.FrozenColumn, selector: "[pFrozenColumn]", inputs: ["frozen", "alignFrozen"] }, { kind: "directive", type: i1$b.EditableColumn, selector: "[pEditableColumn]", inputs: ["pEditableColumn", "pEditableColumnField", "pEditableColumnRowIndex", "pEditableColumnDisabled", "pFocusCellSelector"] }, { kind: "component", type: i1$b.CellEditor, selector: "p-cellEditor" }, { kind: "component", type: i1$b.SortIcon, selector: "p-sortIcon", inputs: ["field"] }, { kind: "component", type: i1$b.TableCheckbox, selector: "p-tableCheckbox", inputs: ["value", "disabled", "required", "index", "inputId", "name", "ariaLabel"] }, { kind: "component", type: i1$b.TableHeaderCheckbox, selector: "p-tableHeaderCheckbox", inputs: ["disabled", "inputId", "name", "ariaLabel"] }, { kind: "directive", type: i1$b.EditableRow, selector: "[pEditableRow]", inputs: ["pEditableRow", "pEditableRowDisabled"] }, { kind: "directive", type: i1$b.InitEditableRow, selector: "[pInitEditableRow]" }, { kind: "directive", type: i1$b.SaveEditableRow, selector: "[pSaveEditableRow]" }, { kind: "directive", type: i1$b.CancelEditableRow, selector: "[pCancelEditableRow]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i1$4.InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "ngmodule", type: InputNumberModule }, { kind: "component", type: i1$3.InputNumber, selector: "p-inputNumber, p-inputnumber, p-input-number", inputs: ["showButtons", "format", "buttonLayout", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabelledBy", "ariaDescribedBy", "ariaLabel", "ariaRequired", "autocomplete", "incrementButtonClass", "decrementButtonClass", "incrementButtonIcon", "decrementButtonIcon", "readonly", "allowEmpty", "locale", "localeMatcher", "mode", "currency", "currencyDisplay", "useGrouping", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "inputStyle", "inputStyleClass", "showClear", "autofocus"], outputs: ["onInput", "onFocus", "onBlur", "onKeyDown", "onClear"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i1.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: TableFilterCellComponent, selector: "crd-table-filter-cell", inputs: ["col", "dt", "filterLevel"] }, { kind: "ngmodule", type: SelectModule }, { kind: "component", type: i1$a.Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "styleClass", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "component", type: TableCellComponent, selector: "tbl-table-cell", inputs: ["cellValue", "options"] }, { kind: "component", type: MultiSelect, selector: "p-multiSelect, p-multiselect, p-multi-select", inputs: ["id", "ariaLabel", "styleClass", "panelStyle", "panelStyleClass", "inputId", "readonly", "group", "filter", "filterPlaceHolder", "filterLocale", "overlayVisible", "tabindex", "dataKey", "ariaLabelledBy", "displaySelectedLabel", "maxSelectedLabels", "selectionLimit", "selectedItemsLabel", "showToggleAll", "emptyFilterMessage", "emptyMessage", "resetFilterOnHide", "dropdownIcon", "chipIcon", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "showHeader", "filterBy", "scrollHeight", "lazy", "virtualScroll", "loading", "virtualScrollItemSize", "loadingIcon", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "autofocusFilter", "display", "autocomplete", "showClear", "autofocus", "placeholder", "options", "filterValue", "selectAll", "focusOnHover", "filterFields", "selectOnFocus", "autoOptionFocus", "highlightOnSelect", "size", "variant", "fluid", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onClear", "onPanelShow", "onPanelHide", "onLazyLoad", "onRemove", "onSelectAllChange"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i2$3.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "pipe", type: HasValidatorPipe, name: "hasValidator" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-table-control", imports: [
                        TableModule,
                        FormsModule,
                        InputTextModule,
                        InputNumberModule,
                        ReactiveFormsModule,
                        ButtonModule,
                        HasValidatorPipe,
                        NgTemplateOutlet,
                        TableFilterCellComponent,
                        SelectModule,
                        TableCellComponent,
                        MultiSelect,
                        TooltipModule,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        "[class.p-disabled]": "isDisabled()",
                    }, template: "@let defaultWidth = \"120px\";\n\n<p-table\n    class=\"table-control\"\n    #dataTable\n    [value]=\"value()\"\n    dataKey=\"internal_id\"\n    [(selection)]=\"selectedRows\"\n    (selectionChange)=\"onSelectionChanged()\"\n    [editMode]=\"editionMode() === 'row' ? 'row' : 'cell'\"\n    showGridlines \n    [scrollable]=\"true\"\n    scrollHeight=\"400px\">\n\n    <ng-template #caption>\n        @if (tableCtrlConfig().isCreationEnabled) {\n            <p-button \n                icon=\"pi pi-plus\" \n                [label]=\"labels.tableControl.add\" \n                (onClick)=\"onAddNewRow()\" \n            />\n        }\n        @if (tableCtrlConfig().isDeletionEnabled) {\n            <p-button [outlined]=\"true\" \n                severity=\"danger\" \n                icon=\"pi pi-trash\" \n                [label]=\"labels.tableControl.delete\" \n                [disabled]=\"!selectedRows().length\"\n                (onClick)=\"onDeleteRows()\"\n            />\n        }\n    </ng-template>\n\n    <ng-template pTemplate=\"emptymessage\">\n        <tr>\n            <td [attr.colspan]=\"columns().length\"\n                >{{ labels.tableControl.noData }}\n            </td>\n        </tr>\n    </ng-template>\n    <ng-template pTemplate=\"header\">\n        @if (!isHeaderHidden()) {\n            <tr>\n                @if (isSelectable()) {\n                    <th class=\"w-3rem\" scope=\"col\" pFrozenColumn [frozen]=\"true\">\n                        <p-tableHeaderCheckbox />\n                    </th>\n                }\n                @for (col of columns(); track col.key) {\n                    @let sortable = tableCtrlConfig().sortable && col.sortable;                \n                    <th scope=\"col\" \n                        [pSortableColumnDisabled]=\"!sortable\"\n                        [pSortableColumn]=\"col.key\"\n                        pFrozenColumn\n                        [style.minWidth]=\"defaultWidth\"\n                        [style.maxWidth]=\"defaultWidth\">\n                        {{ col.label }}\n                        @if (sortable) {\n                            <p-sortIcon [field]=\"col.key\"></p-sortIcon>\n                        }\n                    </th>\n                }\n                @if (editionMode() === \"row\") {\n                    <th scope=\"col\">\n                        {{ labels.tableControl.actionsColumnHeader }}\n                    </th>\n                }\n            </tr>\n            @if (tableCtrlConfig().filterable) {\n                <tr>\n                    @if (isSelectable()) {\n                        <th scope=\"col\" pFrozenColumn [frozen]=\"true\"></th>\n                    }\n                    @for (col of columns(); track col.key) {       \n                        <th\n                            class=\"filter-row-th\"\n                            pFrozenColumn\n                            scope=\"th\"\n                            [style.minWidth]=\"defaultWidth\"\n                            [style.maxWidth]=\"defaultWidth\">\n                            @if (col.filterable) {\n                                <crd-table-filter-cell \n                                    [col]=\"col\"\n                                    [dt]=\"dataTable\"\n                                    filterLevel=\"basic\"\n                                />\n                            }\n                        </th>                \n                    }\n                    @if (editionMode() === \"row\") {\n                        <th scope=\"col\"></th>\n                    }\n                </tr>\n            }\n        }\n    </ng-template>\n    <ng-template pTemplate=\"body\" \n        let-item \n        let-editing=\"editing\" \n        let-index=\"rowIndex\">\n        <tr [pEditableRow]=\"item\" \n            [pEditableRowDisabled]=\"editionMode() !== 'row'\"\n            (click)=\"onCellClicked(item, index)\">\n            @if (isSelectable()) {\n                <td pFrozenColumn [frozen]=\"true\">\n                    <p-tableCheckbox [value]=\"item\" />\n                </td>\n            }\n            @for (col of columns(); track col.key) {\n                @let isCellEditionDisabled = col.isCellEditionDisabled ?? false;\n                @let isEditableInCellMode = !isCellEditionDisabled && !isDisabled() && editionMode() === \"cell\";\n                @let colValidators = col.controlOptions?.validators ?? [];\n                <td  \n                    [style.minWidth]=\"defaultWidth\"\n                    [style.maxWidth]=\"defaultWidth\"\n                    [class.pointer]=\"isEditableInCellMode\"\n                    pFrozenColumn\n                    [pEditableColumnDisabled]=\"!isEditableInCellMode\"\n                    [pEditableColumn]=\"item[col.key]\"\n                    [pEditableColumnField]=\"col.key\">       \n                    @switch (col.controlType) {\n                        @case (ControlType.SELECT) {\n                            <p-cellEditor>                                    \n                                <ng-template pTemplate=\"input\">\n                                    <p-select\n                                        [options]=\"col.options\"\n                                        appendTo=\"body\"\n                                        [(ngModel)]=\"item[col.key]\"\n                                        [disabled]=\"isCellEditionDisabled\"\n                                        [required]=\"colValidators | hasValidator:'required'\"\n                                        (onFocus)=\"emitInteractionEvent('cellEditInit')\"\n                                        (onChange)=\"saveCellValue($event.value, col.key, index)\"\n                                    />\n                                </ng-template>\n                                <ng-template pTemplate=\"output\">\n                                    <ng-container [ngTemplateOutlet]=\"cellTemplate\"/>\n                                </ng-template>\n                            </p-cellEditor>                                \n                        }\n                        @case (ControlType.MULTISELECT) {        \n                            <p-cellEditor>                                    \n                                <ng-template pTemplate=\"input\">\n                                    <p-multiselect #multiselect\n                                        [options]=\"col.options\"\n                                        appendTo=\"body\"\n                                        [ngModel]=\"item[col.key]\"\n                                        [disabled]=\"isCellEditionDisabled\"\n                                        [required]=\"colValidators | hasValidator:'required'\"\n                                        (onFocus)=\"emitInteractionEvent('cellEditInit')\"\n                                        (onChange)=\"onMultiselectChange(index)\">\n                                        <ng-template #footer>\n                                            <div class=\"multiselect-footer\">\n                                                <p-button \n                                                    [label]=\"labels.tableControl.multiselectValidate\"\n                                                    icon=\"pi pi-check\"\n                                                    (onClick)=\"saveMultiselectValue(multiselect.value, col.key, index)\"\n                                                />\n                                            </div>\n                                        </ng-template>                                        \n                                        <ng-template #dropdownicon>\n                                            @if (rowIndexWithUnsavedChanges() === index) {\n                                                <i class=\"pi pi-info-circle\"\n                                                    [pTooltip]=\"labels.tableControl.multiselectUnsavedChanges\">\n                                                </i>\n                                            }\n                                        </ng-template>\n                                    </p-multiselect>\n                                </ng-template>\n                                <ng-template pTemplate=\"output\">\n                                    <ng-container [ngTemplateOutlet]=\"cellTemplate\"/>\n                                </ng-template>\n                            </p-cellEditor>                                \n                        }\n                        @default {\n                            <p-cellEditor>                       \n                                <ng-template pTemplate=\"input\">\n                                    @if (col.type === \"number\") {\n                                        <p-inputNumber #inputNumber\n                                            [id]=\"col.key\"\n                                            locale=\"fr-FR\"\n                                            [(ngModel)]=\"item[col.key]\"\n                                            [disabled]=\"isCellEditionDisabled\"\n                                            [required]=\"colValidators | hasValidator:'required'\"\n                                            (onFocus)=\"emitInteractionEvent('cellEditInit')\"\n                                            (keydown.enter)=\"saveCellValue(inputNumber.value, col.key, index)\"\n                                            (onBlur)=\"saveCellValue(inputNumber.value, col.key, index)\"\n                                            required\n                                        />\n                                    } @else {\n                                        <input #inputText\n                                            pInputText\n                                            [(ngModel)]=\"item[col.key]\"\n                                            type=\"text\" \n                                            [disabled]=\"isCellEditionDisabled\"                                                \n                                            [required]=\"colValidators | hasValidator:'required'\"\n                                            (onFocus)=\"emitInteractionEvent('cellEditInit')\"\n                                            (keydown.enter)=\"saveCellValue(inputText.value, col.key, index)\"\n                                            (onBlur)=\"saveCellValue(inputText.value, col.key, index)\"\n                                        />\n                                    }\n                                </ng-template>\n                                <ng-template pTemplate=\"output\">\n                                    <ng-container [ngTemplateOutlet]=\"cellTemplate\"/>\n                                </ng-template>\n                            </p-cellEditor>\n                        }\n                    }\n                    <ng-template #cellTemplate>\n                        <tbl-table-cell [cellValue]=\"item[col.key]\" [options]=\"col\" />\n                    </ng-template>\n                </td>\n            }\n            @if (editionMode() === \"row\") {\n                <td>\n                    <div class=\"edit-buttons-container\">\n                        @if (!editing) {\n                            <p-button\n                                pInitEditableRow\n                                icon=\"pi pi-pencil\"\n                                text\n                                rounded\n                                severity=\"secondary\"\n                                (click)=\"onRowEditInit(item)\"\n                            />\n                        } @else {\n                            <p-button\n                                pSaveEditableRow\n                                icon=\"pi pi-check\"\n                                text\n                                rounded\n                                severity=\"secondary\"\n                                (click)=\"onRowEditSave()\"\n                            />\n                            <p-button\n                                pCancelEditableRow\n                                icon=\"pi pi-times\"\n                                text\n                                rounded\n                                severity=\"secondary\"\n                                (click)=\"onRowEditCancel(index)\"\n                            />\n                        }\n                    </div>\n                </td>\n            }\n        </tr>\n    </ng-template>\n</p-table>\n", styles: [".table-control .p-datatable-header{display:flex;justify-content:flex-end;gap:.5rem;padding:.5rem}.table-control th,.table-control td{text-align:center}.table-control th.pointer,.table-control td.pointer{cursor:pointer}.table-control tr{height:40px}.table-control .p-dropdown-label,.table-control .p-inputtext{padding:.5rem}.table-control .multiselect-footer{text-align:right;margin:.5rem}.table-control .edit-buttons-container{display:flex;justify-content:center;gap:.5rem;width:100px}\n"] }]
        }] });

class TextareaControlComponent extends FormFieldBaseComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TextareaControlComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.7", type: TextareaControlComponent, isStandalone: true, selector: "frm-textarea-control", usesInheritance: true, ngImport: i0, template: "<textarea pTextarea \n    [formControl]=\"control()\"\n    [placeholder]=\"placeholder()\"\n    rows=\"5\"\n    cols=\"30\"\n    class=\"textarea-input\"\n    (focus)=\"emitInteractionEvent('focus')\"\n    (blur)=\"emitInteractionEvent('blur')\"\n    (input)=\"emitInteractionEvent('keyup')\"\n></textarea>", dependencies: [{ kind: "ngmodule", type: TextareaModule }, { kind: "directive", type: i1$c.Textarea, selector: "[pTextarea], [pInputTextarea]", inputs: ["pTextareaPT", "pTextareaUnstyled", "autoResize", "pSize", "variant", "fluid", "invalid"], outputs: ["onResize"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TextareaControlComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-textarea-control", imports: [TextareaModule, ReactiveFormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<textarea pTextarea \n    [formControl]=\"control()\"\n    [placeholder]=\"placeholder()\"\n    rows=\"5\"\n    cols=\"30\"\n    class=\"textarea-input\"\n    (focus)=\"emitInteractionEvent('focus')\"\n    (blur)=\"emitInteractionEvent('blur')\"\n    (input)=\"emitInteractionEvent('keyup')\"\n></textarea>" }]
        }] });

class FormFieldRenderer {
    /** Field configuration object */
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /** Form control instance */
    control = input.required(...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    /** Readonly state of the form */
    isFormReadonly = input.required(...(ngDevMode ? [{ debugName: "isFormReadonly" }] : /* istanbul ignore next */ []));
    /** Incremental value to trigger change detection on the form field */
    syncValueInc = input.required(...(ngDevMode ? [{ debugName: "syncValueInc" }] : /* istanbul ignore next */ []));
    /** Emits when the field is interacted with */
    fieldInteraction = output();
    /** ControlType enum for template use */
    ControlType = CONTROL_TYPES;
    /**
     * CUSTOM CONTROL INTERACTION EVENTS HANDLER
     */
    // Query the custom component instance
    customComponent = viewChild(NgComponentOutlet, ...(ngDevMode ? [{ debugName: "customComponent" }] : /* istanbul ignore next */ []));
    sub = new Subscription();
    // Subscribe to interaction events from the custom component
    ngAfterViewInit() {
        const customComponent = this.customComponent();
        if (this.config().controlType === CONTROL_TYPES.CUSTOM && customComponent) {
            const interaction = customComponent.componentInstance.fieldInteraction;
            this.sub.add(interaction.subscribe((event) => {
                this.fieldInteraction.emit(event);
            }));
        }
    }
    // Unsubscribe on destroy
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormFieldRenderer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: FormFieldRenderer, isStandalone: true, selector: "frm-field-renderer", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, isFormReadonly: { classPropertyName: "isFormReadonly", publicName: "isFormReadonly", isSignal: true, isRequired: true, transformFunction: null }, syncValueInc: { classPropertyName: "syncValueInc", publicName: "syncValueInc", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { fieldInteraction: "fieldInteraction" }, viewQueries: [{ propertyName: "customComponent", first: true, predicate: NgComponentOutlet, descendants: true, isSignal: true }], ngImport: i0, template: "@switch (config().controlType) {\n  @case (ControlType.AUTOCOMPLETE) {\n    <frm-autocomplete-control \n      [config]=\"config()\" \n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.CHECKBOX) {\n    <frm-checkbox-control\n      [config]=\"config()\"\n      [control]=\"control()\"     \n      [isFormReadonly]=\"isFormReadonly()\" \n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.CUSTOM) {\n    @let component = config().controlOptions?.customComponent;\n    @if (component) {\n      <ng-container *ngComponentOutlet=\"\n        component;\n        inputs: { \n          config: config(), \n          control: control(), \n          isFormReadonly: isFormReadonly(),\n        };\n      \"\n      />\n    } @else {\n      <i class=\"pi pi-exclamation-triangle orange\" \n        title=\"You must provide a custom component\">\n      </i>\n    }\n  }\n  @case (ControlType.DATE) {\n    <frm-date-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      [syncValueInc]=\"syncValueInc()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.FILES) {\n    <frm-file-upload-input\n      [control]=\"control()\"\n      [config]=\"config()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.INPUT) {\n    @if (config().type === 'number') {\n      <frm-inputnumber-control \n        [config]=\"config()\"\n        [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n        (fieldInteraction)=\"fieldInteraction.emit($event)\"\n      />\n    } @else {\n      <frm-inputtext-control \n        [config]=\"config()\"\n        [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n        (fieldInteraction)=\"fieldInteraction.emit($event)\"\n      />\n    }\n  }\n  @case (ControlType.MULTISELECT) {\n    <frm-multi-select-control \n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.PICKLIST) {\n    <frm-picklist-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.RADIO) {\n    <frm-radiogroup-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.SELECT) {\n    <frm-select-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.SELECT_BUTTON) {\n    <frm-select-button-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.TABLE) {\n    <frm-table-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.TEXTAREA) {\n    <frm-textarea-control \n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.WYSIWYG) {\n    <frm-rich-text-editor\n      [control]=\"control()\"\n      [config]=\"config()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n}\n", dependencies: [{ kind: "component", type: AutocompleteControlComponent, selector: "frm-autocomplete-control" }, { kind: "component", type: CheckboxControlComponent, selector: "frm-checkbox-control" }, { kind: "component", type: DateControlComponent, selector: "frm-date-control" }, { kind: "component", type: InputNumberControlComponent, selector: "frm-inputnumber-control" }, { kind: "component", type: InputTextControlComponent, selector: "frm-inputtext-control" }, { kind: "component", type: MultiSelectControlComponent, selector: "frm-multi-select-control" }, { kind: "component", type: SelectControlComponent, selector: "frm-select-control" }, { kind: "component", type: TextareaControlComponent, selector: "frm-textarea-control" }, { kind: "component", type: FileUploadInputComponent, selector: "frm-file-upload-input" }, { kind: "component", type: RichTextEditorComponent, selector: "frm-rich-text-editor" }, { kind: "component", type: TableControlComponent, selector: "frm-table-control" }, { kind: "component", type: RadioGroupComponent, selector: "frm-radiogroup-control" }, { kind: "component", type: PicklistControlComponent, selector: "frm-picklist-control" }, { kind: "component", type: SelectButtonControlComponent, selector: "frm-select-button-control" }, { kind: "directive", type: NgComponentOutlet, selector: "[ngComponentOutlet]", inputs: ["ngComponentOutlet", "ngComponentOutletInputs", "ngComponentOutletInjector", "ngComponentOutletEnvironmentInjector", "ngComponentOutletContent", "ngComponentOutletNgModule"], exportAs: ["ngComponentOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormFieldRenderer, decorators: [{
            type: Component,
            args: [{ selector: "frm-field-renderer", changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        AutocompleteControlComponent,
                        CheckboxControlComponent,
                        DateControlComponent,
                        InputNumberControlComponent,
                        InputTextControlComponent,
                        MultiSelectControlComponent,
                        SelectControlComponent,
                        TextareaControlComponent,
                        FileUploadInputComponent,
                        RichTextEditorComponent,
                        TableControlComponent,
                        RadioGroupComponent,
                        PicklistControlComponent,
                        SelectButtonControlComponent,
                        NgComponentOutlet,
                    ], template: "@switch (config().controlType) {\n  @case (ControlType.AUTOCOMPLETE) {\n    <frm-autocomplete-control \n      [config]=\"config()\" \n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.CHECKBOX) {\n    <frm-checkbox-control\n      [config]=\"config()\"\n      [control]=\"control()\"     \n      [isFormReadonly]=\"isFormReadonly()\" \n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.CUSTOM) {\n    @let component = config().controlOptions?.customComponent;\n    @if (component) {\n      <ng-container *ngComponentOutlet=\"\n        component;\n        inputs: { \n          config: config(), \n          control: control(), \n          isFormReadonly: isFormReadonly(),\n        };\n      \"\n      />\n    } @else {\n      <i class=\"pi pi-exclamation-triangle orange\" \n        title=\"You must provide a custom component\">\n      </i>\n    }\n  }\n  @case (ControlType.DATE) {\n    <frm-date-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      [syncValueInc]=\"syncValueInc()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.FILES) {\n    <frm-file-upload-input\n      [control]=\"control()\"\n      [config]=\"config()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.INPUT) {\n    @if (config().type === 'number') {\n      <frm-inputnumber-control \n        [config]=\"config()\"\n        [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n        (fieldInteraction)=\"fieldInteraction.emit($event)\"\n      />\n    } @else {\n      <frm-inputtext-control \n        [config]=\"config()\"\n        [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n        (fieldInteraction)=\"fieldInteraction.emit($event)\"\n      />\n    }\n  }\n  @case (ControlType.MULTISELECT) {\n    <frm-multi-select-control \n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.PICKLIST) {\n    <frm-picklist-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.RADIO) {\n    <frm-radiogroup-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.SELECT) {\n    <frm-select-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.SELECT_BUTTON) {\n    <frm-select-button-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.TABLE) {\n    <frm-table-control\n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.TEXTAREA) {\n    <frm-textarea-control \n      [config]=\"config()\"\n      [control]=\"control()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n  @case (ControlType.WYSIWYG) {\n    <frm-rich-text-editor\n      [control]=\"control()\"\n      [config]=\"config()\"\n      [isFormReadonly]=\"isFormReadonly()\"\n      (fieldInteraction)=\"fieldInteraction.emit($event)\"\n    />\n  }\n}\n" }]
        }], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], control: [{ type: i0.Input, args: [{ isSignal: true, alias: "control", required: true }] }], isFormReadonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "isFormReadonly", required: true }] }], syncValueInc: [{ type: i0.Input, args: [{ isSignal: true, alias: "syncValueInc", required: true }] }], fieldInteraction: [{ type: i0.Output, args: ["fieldInteraction"] }], customComponent: [{ type: i0.ViewChild, args: [i0.forwardRef(() => NgComponentOutlet), { isSignal: true }] }] } });

class FormArrayElement {
    formService = inject(FormBuilderService);
    labels = inject(CRUD_LABELS);
    get classes() {
        return this.parentControlOptions().hidden ? "display-none" : "";
    }
    get style() {
        const { width, minWidth, maxWidth } = this.parentControlOptions();
        return `
      min-width: ${width ?? minWidth ?? this.defaultControlWidth()};
      max-width: ${width ?? maxWidth ?? this.defaultControlWidth()};
    `;
    }
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    formGroup = input.required(...(ngDevMode ? [{ debugName: "formGroup" }] : /* istanbul ignore next */ []));
    isFormReadonly = input.required(...(ngDevMode ? [{ debugName: "isFormReadonly" }] : /* istanbul ignore next */ []));
    defaultControlWidth = input.required(...(ngDevMode ? [{ debugName: "defaultControlWidth" }] : /* istanbul ignore next */ []));
    syncValueInc = input.required(...(ngDevMode ? [{ debugName: "syncValueInc" }] : /* istanbul ignore next */ []));
    formArray = computed(() => {
        return this.formGroup().get(this.config().key);
    }, ...(ngDevMode ? [{ debugName: "formArray" }] : /* istanbul ignore next */ []));
    parentControlOptions = computed(() => {
        return this.config().controlOptions ?? {};
    }, ...(ngDevMode ? [{ debugName: "parentControlOptions" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => this.isFormReadonly() || this.parentControlOptions().disabled === true, ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    controls = computed(() => this.formArray().controls, ...(ngDevMode ? [{ debugName: "controls" }] : /* istanbul ignore next */ []));
    arrayControlOptions = computed(() => this.parentControlOptions().controlArrayConfig ?? {}, ...(ngDevMode ? [{ debugName: "arrayControlOptions" }] : /* istanbul ignore next */ []));
    /** Cannot delete and add are stored as writable signals because `controls()`
     * do not trigger computed()
     */
    cannotDelete = linkedSignal(() => {
        return this.isMinReached();
    }, ...(ngDevMode ? [{ debugName: "cannotDelete" }] : /* istanbul ignore next */ []));
    cannotAdd = linkedSignal(() => {
        return this.isMaxReached();
    }, ...(ngDevMode ? [{ debugName: "cannotAdd" }] : /* istanbul ignore next */ []));
    addControl() {
        const control = this.formService.toFormControl(this.config(), "", // For now, we use an empty string as the initial value. But could (and should) do more.
        this.isFormReadonly() ?? false);
        this.formArray().push(control);
        this.updateAddAndDeleteButtonState();
    }
    removeControl(index) {
        this.formArray().removeAt(index);
        this.updateAddAndDeleteButtonState();
    }
    updateAddAndDeleteButtonState() {
        this.cannotAdd.set(this.isMaxReached());
        this.cannotDelete.set(this.isMinReached());
    }
    isMaxReached() {
        return (this.controls().length >=
            (this.arrayControlOptions().maxItems ?? Number.POSITIVE_INFINITY));
    }
    isMinReached() {
        return this.controls().length <= (this.arrayControlOptions().minItems ?? 0);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormArrayElement, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: FormArrayElement, isStandalone: true, selector: "frm-array-element", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, formGroup: { classPropertyName: "formGroup", publicName: "formGroup", isSignal: true, isRequired: true, transformFunction: null }, isFormReadonly: { classPropertyName: "isFormReadonly", publicName: "isFormReadonly", isSignal: true, isRequired: true, transformFunction: null }, defaultControlWidth: { classPropertyName: "defaultControlWidth", publicName: "defaultControlWidth", isSignal: true, isRequired: true, transformFunction: null }, syncValueInc: { classPropertyName: "syncValueInc", publicName: "syncValueInc", isSignal: true, isRequired: true, transformFunction: null } }, host: { properties: { "class": "this.classes", "style": "this.style" } }, ngImport: i0, template: "<div class=\"array-group\" [class.p-disabled]=\"isDisabled()\">\n    <div class=\"array-group-label\">\n      <span>{{config().label}}</span>\n      <p-button \n        type=\"button\" \n        outlined\n        [label]=\"arrayControlOptions().addButtonLabel\" \n        icon=\"pi pi-plus\" \n        [disabled]=\"cannotAdd()\"\n        (click)=\"addControl()\"\n      />\n    </div>\n    @for (control of controls(); track control) {   \n      <div class=\"array-control-container\">\n        <frm-field-renderer\n          #formFieldControl\n          class=\"array-control\"\n          [config]=\"config()\"\n          [control]=\"control\"\n          [isFormReadonly]=\"isFormReadonly()\"\n          [syncValueInc]=\"syncValueInc()\"\n        />\n        @if (formFieldControl.control().invalid) {\n          <frm-error-message\n            class=\"error-message\"\n            [controlErrors]=\"control.errors\" \n          />\n        }\n        <p-button \n          type=\"button\" \n          text\n          icon=\"pi pi-trash\"\n          [title]=\"labels.arrayElement.delete\"\n          [disabled]=\"cannotDelete()\"\n          (click)=\"removeControl($index)\"\n        />\n      </div>       \n    }\n</div>", styles: [".array-group .array-group-label{margin-bottom:1rem}.array-group .array-group-label span{margin-right:1rem;font-weight:700}.array-group .array-control-container{position:relative;margin-bottom:1.5rem;display:flex;align-items:center;gap:1rem}.array-group .array-control-container .array-control{flex:1}.array-group .array-control-container .error-message{position:absolute;bottom:-1.1rem;left:.25rem;color:var(--p-red-400)}\n"], dependencies: [{ kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i1.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: FormFieldRenderer, selector: "frm-field-renderer", inputs: ["config", "control", "isFormReadonly", "syncValueInc"], outputs: ["fieldInteraction"] }, { kind: "component", type: FormErrorMessage, selector: "frm-error-message", inputs: ["controlErrors"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormArrayElement, decorators: [{
            type: Component,
            args: [{ selector: "frm-array-element", imports: [
                        ButtonModule,
                        ReactiveFormsModule,
                        FormFieldRenderer,
                        FormErrorMessage,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"array-group\" [class.p-disabled]=\"isDisabled()\">\n    <div class=\"array-group-label\">\n      <span>{{config().label}}</span>\n      <p-button \n        type=\"button\" \n        outlined\n        [label]=\"arrayControlOptions().addButtonLabel\" \n        icon=\"pi pi-plus\" \n        [disabled]=\"cannotAdd()\"\n        (click)=\"addControl()\"\n      />\n    </div>\n    @for (control of controls(); track control) {   \n      <div class=\"array-control-container\">\n        <frm-field-renderer\n          #formFieldControl\n          class=\"array-control\"\n          [config]=\"config()\"\n          [control]=\"control\"\n          [isFormReadonly]=\"isFormReadonly()\"\n          [syncValueInc]=\"syncValueInc()\"\n        />\n        @if (formFieldControl.control().invalid) {\n          <frm-error-message\n            class=\"error-message\"\n            [controlErrors]=\"control.errors\" \n          />\n        }\n        <p-button \n          type=\"button\" \n          text\n          icon=\"pi pi-trash\"\n          [title]=\"labels.arrayElement.delete\"\n          [disabled]=\"cannotDelete()\"\n          (click)=\"removeControl($index)\"\n        />\n      </div>       \n    }\n</div>", styles: [".array-group .array-group-label{margin-bottom:1rem}.array-group .array-group-label span{margin-right:1rem;font-weight:700}.array-group .array-control-container{position:relative;margin-bottom:1.5rem;display:flex;align-items:center;gap:1rem}.array-group .array-control-container .array-control{flex:1}.array-group .array-control-container .error-message{position:absolute;bottom:-1.1rem;left:.25rem;color:var(--p-red-400)}\n"] }]
        }], propDecorators: { classes: [{
                type: HostBinding,
                args: ["class"]
            }], style: [{
                type: HostBinding,
                args: ["style"]
            }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], formGroup: [{ type: i0.Input, args: [{ isSignal: true, alias: "formGroup", required: true }] }], isFormReadonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "isFormReadonly", required: true }] }], defaultControlWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultControlWidth", required: true }] }], syncValueInc: [{ type: i0.Input, args: [{ isSignal: true, alias: "syncValueInc", required: true }] }] } });

class FormFieldTooltip {
    value = input.required(...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormFieldTooltip, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.7", type: FormFieldTooltip, isStandalone: true, selector: "frm-field-tooltip", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<i class=\"pi pi-info-circle\" [pTooltip]=\"tooltipContent\"></i>\n<ng-template #tooltipContent>\n<div class=\"flex align-items-center\">\n    <span [innerHTML]=\"value()\"></span>\n</div>\n</ng-template>", dependencies: [{ kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i2$3.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormFieldTooltip, decorators: [{
            type: Component,
            args: [{ selector: "frm-field-tooltip", imports: [TooltipModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<i class=\"pi pi-info-circle\" [pTooltip]=\"tooltipContent\"></i>\n<ng-template #tooltipContent>\n<div class=\"flex align-items-center\">\n    <span [innerHTML]=\"value()\"></span>\n</div>\n</ng-template>" }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }] } });

class LabelWrapperComponent {
    labelStrategy = input.required(...(ngDevMode ? [{ debugName: "labelStrategy" }] : /* istanbul ignore next */ []));
    labelVariant = input.required(...(ngDevMode ? [{ debugName: "labelVariant" }] : /* istanbul ignore next */ []));
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    control = input.required(...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    isRequired = computed(() => {
        return (!!this.config().key &&
            (this.control().hasValidator(required) ||
                this.control().hasValidator(requiredTrue)));
    }, ...(ngDevMode ? [{ debugName: "isRequired" }] : /* istanbul ignore next */ []));
    options = computed(() => {
        return this.config().controlOptions ?? {};
    }, ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    label = computed(() => {
        return this.options().label ?? this.config().label ?? "";
    }, ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    inputIcon = computed(() => {
        return this.options().inputIcon ?? null;
    }, ...(ngDevMode ? [{ debugName: "inputIcon" }] : /* istanbul ignore next */ []));
    isForcedNormalLabel = computed(() => {
        const normalLabelControls = [
            // CONTROL_TYPES.CHECKBOX,
            CONTROL_TYPES.FILES,
            CONTROL_TYPES.PICKLIST,
            CONTROL_TYPES.TABLE,
            CONTROL_TYPES.WYSIWYG,
            CONTROL_TYPES.CUSTOM,
        ];
        return normalLabelControls.includes(this.config().controlType);
    }, ...(ngDevMode ? [{ debugName: "isForcedNormalLabel" }] : /* istanbul ignore next */ []));
    fieldLabelStrategy = computed(() => {
        const defaultStrategy = this.labelStrategy();
        if (this.isForcedNormalLabel()) {
            return "normal";
        }
        if (defaultStrategy === "float" &&
            (this.config().controlType === CONTROL_TYPES.RADIO ||
                this.config().controlType === CONTROL_TYPES.SELECT_BUTTON)) {
            return "normal";
        }
        return defaultStrategy;
    }, ...(ngDevMode ? [{ debugName: "fieldLabelStrategy" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LabelWrapperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: LabelWrapperComponent, isStandalone: true, selector: "frm-label-wrapper", inputs: { labelStrategy: { classPropertyName: "labelStrategy", publicName: "labelStrategy", isSignal: true, isRequired: true, transformFunction: null }, labelVariant: { classPropertyName: "labelVariant", publicName: "labelVariant", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "@switch (fieldLabelStrategy()) {\n    @case (\"float\") {\n        <p-floatLabel [variant]=\"labelVariant() ?? 'on'\">\n            <ng-container *ngTemplateOutlet=\"labelContentTemplate\" />\n        </p-floatLabel>\n    }\n    @case (\"ifta\") {\n        <p-iftalabel>\n            <ng-container *ngTemplateOutlet=\"labelContentTemplate\" />\n        </p-iftalabel>\n    }\n    @default {\n        <ng-container *ngTemplateOutlet=\"labelContentTemplate\" />\n    }\n}\n<ng-template #labelContentTemplate>\n    @let isCheckbox = config().controlType === 'checkbox';\n    <!-- Empty element to align correctly checkboxes -->\n    @if (isCheckbox && labelStrategy() === 'normal' ) {\n        <span>&nbsp;</span>\n    }\n    <!-- Label -->\n    <label [for]=\"config().key\" \n        [class.mandatory-control]=\"isRequired()\"\n        [class.checkbox-label]=\"isCheckbox\">\n        {{ label() }}                  \n        @if (options().tooltipLabel) {\n            <frm-field-tooltip\n                [value]=\"options().tooltipLabel\"\n                class=\"floating-tooltip\"\n                [class.normal-tooltip]=\"fieldLabelStrategy() === 'normal'\"\n            />\n        }\n    </label>\n    <p-iconfield [class.has-icon]=\"!!inputIcon()\">\n        <p-inputicon [class]=\"inputIcon()\" />\n        <ng-content />\n    </p-iconfield>\n</ng-template>\n    ", styles: ["label{z-index:2;line-height:1;font-size:var(--p-iftalabel-font-size);font-weight:var(--p-iftalabel-font-weight);inset-inline-start:var(--p-iftalabel-position-x);color:var(--p-iftalabel-color)}label.mandatory-control:after{content:\"*\";margin-left:2px}label .floating-tooltip{position:absolute;right:-20px;top:50%;transform:translateY(-50%);pointer-events:all}label .floating-tooltip.normal-tooltip{position:unset;transform:unset;margin-left:5px}.p-iconfield.has-icon .p-inputtext:not(.p-inputnumber-input),.p-iconfield.has-icon .p-inputnumber-input,.p-iconfield.has-icon .p-select-label,.p-iconfield.has-icon .p-multiselect-label,.p-iconfield.has-icon .p-textarea{padding-inline-start:calc(var(--p-form-field-padding-x) * 2 + var(--p-icon-size))}.p-floatlabel:has(.p-inputicon:first-child) label{inset-inline-start:5px}.p-floatlabel:has(.checkbox-label) label{top:12px!important;padding-left:18px!important;transform:none;transition:none!important}.p-floatlabel:has(.has-icon>.p-inputicon:first-child) label{inset-inline-start:calc(var(--p-form-field-padding-x) * 2 + var(--p-icon-size))}\n"], dependencies: [{ kind: "ngmodule", type: IftaLabelModule }, { kind: "component", type: i1$d.IftaLabel, selector: "p-iftalabel, p-iftaLabel, p-ifta-label" }, { kind: "ngmodule", type: FloatLabelModule }, { kind: "component", type: i2$4.FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: IconFieldModule }, { kind: "component", type: i3.IconField, selector: "p-iconfield, p-iconField, p-icon-field", inputs: ["hostName", "iconPosition", "styleClass"] }, { kind: "ngmodule", type: InputIconModule }, { kind: "component", type: i4.InputIcon, selector: "p-inputicon, p-inputIcon", inputs: ["hostName", "styleClass"] }, { kind: "component", type: FormFieldTooltip, selector: "frm-field-tooltip", inputs: ["value"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LabelWrapperComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-label-wrapper", imports: [
                        IftaLabelModule,
                        FloatLabelModule,
                        NgTemplateOutlet,
                        IconFieldModule,
                        InputIconModule,
                        FormFieldTooltip,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "@switch (fieldLabelStrategy()) {\n    @case (\"float\") {\n        <p-floatLabel [variant]=\"labelVariant() ?? 'on'\">\n            <ng-container *ngTemplateOutlet=\"labelContentTemplate\" />\n        </p-floatLabel>\n    }\n    @case (\"ifta\") {\n        <p-iftalabel>\n            <ng-container *ngTemplateOutlet=\"labelContentTemplate\" />\n        </p-iftalabel>\n    }\n    @default {\n        <ng-container *ngTemplateOutlet=\"labelContentTemplate\" />\n    }\n}\n<ng-template #labelContentTemplate>\n    @let isCheckbox = config().controlType === 'checkbox';\n    <!-- Empty element to align correctly checkboxes -->\n    @if (isCheckbox && labelStrategy() === 'normal' ) {\n        <span>&nbsp;</span>\n    }\n    <!-- Label -->\n    <label [for]=\"config().key\" \n        [class.mandatory-control]=\"isRequired()\"\n        [class.checkbox-label]=\"isCheckbox\">\n        {{ label() }}                  \n        @if (options().tooltipLabel) {\n            <frm-field-tooltip\n                [value]=\"options().tooltipLabel\"\n                class=\"floating-tooltip\"\n                [class.normal-tooltip]=\"fieldLabelStrategy() === 'normal'\"\n            />\n        }\n    </label>\n    <p-iconfield [class.has-icon]=\"!!inputIcon()\">\n        <p-inputicon [class]=\"inputIcon()\" />\n        <ng-content />\n    </p-iconfield>\n</ng-template>\n    ", styles: ["label{z-index:2;line-height:1;font-size:var(--p-iftalabel-font-size);font-weight:var(--p-iftalabel-font-weight);inset-inline-start:var(--p-iftalabel-position-x);color:var(--p-iftalabel-color)}label.mandatory-control:after{content:\"*\";margin-left:2px}label .floating-tooltip{position:absolute;right:-20px;top:50%;transform:translateY(-50%);pointer-events:all}label .floating-tooltip.normal-tooltip{position:unset;transform:unset;margin-left:5px}.p-iconfield.has-icon .p-inputtext:not(.p-inputnumber-input),.p-iconfield.has-icon .p-inputnumber-input,.p-iconfield.has-icon .p-select-label,.p-iconfield.has-icon .p-multiselect-label,.p-iconfield.has-icon .p-textarea{padding-inline-start:calc(var(--p-form-field-padding-x) * 2 + var(--p-icon-size))}.p-floatlabel:has(.p-inputicon:first-child) label{inset-inline-start:5px}.p-floatlabel:has(.checkbox-label) label{top:12px!important;padding-left:18px!important;transform:none;transition:none!important}.p-floatlabel:has(.has-icon>.p-inputicon:first-child) label{inset-inline-start:calc(var(--p-form-field-padding-x) * 2 + var(--p-icon-size))}\n"] }]
        }], propDecorators: { labelStrategy: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategy", required: true }] }], labelVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelVariant", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], control: [{ type: i0.Input, args: [{ isSignal: true, alias: "control", required: true }] }] } });

class FormSimpleElement {
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    control = input.required(...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    isFormReadonly = input.required(...(ngDevMode ? [{ debugName: "isFormReadonly" }] : /* istanbul ignore next */ []));
    defaultControlWidth = input.required(...(ngDevMode ? [{ debugName: "defaultControlWidth" }] : /* istanbul ignore next */ []));
    labelStrategy = input.required(...(ngDevMode ? [{ debugName: "labelStrategy" }] : /* istanbul ignore next */ []));
    labelStrategyVariant = input.required(...(ngDevMode ? [{ debugName: "labelStrategyVariant" }] : /* istanbul ignore next */ []));
    syncValueInc = input.required(...(ngDevMode ? [{ debugName: "syncValueInc" }] : /* istanbul ignore next */ []));
    fieldInteraction = output();
    ControlType = CONTROL_TYPES;
    controlOptions = computed(() => {
        return this.config()?.controlOptions ?? {};
    }, ...(ngDevMode ? [{ debugName: "controlOptions" }] : /* istanbul ignore next */ []));
    width = computed(() => this.controlOptions().width, ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    minWidth = computed(() => this.controlOptions().minWidth, ...(ngDevMode ? [{ debugName: "minWidth" }] : /* istanbul ignore next */ []));
    maxWidth = computed(() => this.controlOptions().maxWidth, ...(ngDevMode ? [{ debugName: "maxWidth" }] : /* istanbul ignore next */ []));
    isVisible = computed(() => {
        return !this.controlOptions().hidden;
    }, ...(ngDevMode ? [{ debugName: "isVisible" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        if (!isNil(this.control().value) &&
            !this.control().hasValidator(required)) {
            this.control().markAsTouched();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormSimpleElement, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: FormSimpleElement, isStandalone: true, selector: "frm-simple-element", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, isFormReadonly: { classPropertyName: "isFormReadonly", publicName: "isFormReadonly", isSignal: true, isRequired: true, transformFunction: null }, defaultControlWidth: { classPropertyName: "defaultControlWidth", publicName: "defaultControlWidth", isSignal: true, isRequired: true, transformFunction: null }, labelStrategy: { classPropertyName: "labelStrategy", publicName: "labelStrategy", isSignal: true, isRequired: true, transformFunction: null }, labelStrategyVariant: { classPropertyName: "labelStrategyVariant", publicName: "labelStrategyVariant", isSignal: true, isRequired: true, transformFunction: null }, syncValueInc: { classPropertyName: "syncValueInc", publicName: "syncValueInc", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { fieldInteraction: "fieldInteraction" }, host: { properties: { "class.display-none": "!isVisible()", "style.minWidth": "width() ?? minWidth() ?? defaultControlWidth()", "style.maxWidth": "width() ?? maxWidth() ?? defaultControlWidth()", "class": "controlOptions().styleClass" } }, ngImport: i0, template: "@if (isVisible()) {\n  @let options = controlOptions();\n  @let hasError = control().invalid && control().touched;\n  <div\n    class=\"form-control-container\"\n    [class.invalid]=\"hasError\">\n    <frm-label-wrapper \n      [config]=\"config()\"\n      [control]=\"control()\"\n      [labelStrategy]=\"labelStrategy()\"\n      [labelVariant]=\"labelStrategyVariant()\">\n      <frm-field-renderer\n        [config]=\"config()\"\n        [control]=\"control()\"\n        [isFormReadonly]=\"isFormReadonly()\"\n        [syncValueInc]=\"syncValueInc()\"\n        (fieldInteraction)=\"fieldInteraction.emit($event)\"\n      />\n    </frm-label-wrapper>\n    <div class=\"hints\">\n      @if (options.helpText) {\n        <small class=\"help-text\" \n          [title]=\"options.helpText\">\n          {{ options.helpText }}\n        </small>\n      }\n      @if (hasError) {\n        <frm-error-message   \n          [controlErrors]=\"control().errors\" \n        />\n      }\n    </div>\n  </div>\n}", styles: [".form-control-container{position:relative;padding:0 .25rem 1.5rem}.form-control-container .p-disabled,.form-control-container .p-disabled .p-datatable-thead>tr>th,.form-control-container .p-disabled .p-datatable-tbody>tr>td,.form-control-container .p-editor.p-disabled .p-editor-toolbar,.form-control-container .p-editor.p-disabled .p-editor-content .ql-editor,.form-control-container frm-select-button-control .p-disabled .p-togglebutton{background:var(--p-inputtext-disabled-background);color:var(--p-inputtext-disabled-color);opacity:1}.form-control-container .hints{position:absolute;bottom:5px;left:5px;width:100%;font-size:11px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;gap:.5rem}.form-control-container .hints .control-error{color:var(--p-red-500)}.form-control-container .hints .help-text{color:var(--p-gray-600)}.form-control-container .p-select,.form-control-container .p-textarea,.form-control-container .p-autocomplete,.form-control-container .p-inputtext,.form-control-container .p-inputnumber,.form-control-container .p-multiselect,.form-control-container .p-iconfield,.form-control-container .p-datepicker{width:100%}.form-control-container .button-control{padding-top:15px;padding-left:10px;cursor:pointer}.form-control-container .textarea-input{resize:none}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MultiSelectModule }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: CheckboxModule }, { kind: "ngmodule", type: ButtonModule }, { kind: "ngmodule", type: IftaLabelModule }, { kind: "component", type: FormErrorMessage, selector: "frm-error-message", inputs: ["controlErrors"] }, { kind: "component", type: FormFieldRenderer, selector: "frm-field-renderer", inputs: ["config", "control", "isFormReadonly", "syncValueInc"], outputs: ["fieldInteraction"] }, { kind: "component", type: LabelWrapperComponent, selector: "frm-label-wrapper", inputs: ["labelStrategy", "labelVariant", "config", "control"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormSimpleElement, decorators: [{
            type: Component,
            args: [{ selector: "frm-simple-element", imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        MultiSelectModule,
                        SharedModule,
                        CheckboxModule,
                        ButtonModule,
                        IftaLabelModule,
                        FormErrorMessage,
                        FormFieldRenderer,
                        LabelWrapperComponent,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        "[class.display-none]": "!isVisible()",
                        "[style.minWidth]": "width() ?? minWidth() ?? defaultControlWidth()",
                        "[style.maxWidth]": "width() ?? maxWidth() ?? defaultControlWidth()",
                        "[class]": "controlOptions().styleClass",
                    }, template: "@if (isVisible()) {\n  @let options = controlOptions();\n  @let hasError = control().invalid && control().touched;\n  <div\n    class=\"form-control-container\"\n    [class.invalid]=\"hasError\">\n    <frm-label-wrapper \n      [config]=\"config()\"\n      [control]=\"control()\"\n      [labelStrategy]=\"labelStrategy()\"\n      [labelVariant]=\"labelStrategyVariant()\">\n      <frm-field-renderer\n        [config]=\"config()\"\n        [control]=\"control()\"\n        [isFormReadonly]=\"isFormReadonly()\"\n        [syncValueInc]=\"syncValueInc()\"\n        (fieldInteraction)=\"fieldInteraction.emit($event)\"\n      />\n    </frm-label-wrapper>\n    <div class=\"hints\">\n      @if (options.helpText) {\n        <small class=\"help-text\" \n          [title]=\"options.helpText\">\n          {{ options.helpText }}\n        </small>\n      }\n      @if (hasError) {\n        <frm-error-message   \n          [controlErrors]=\"control().errors\" \n        />\n      }\n    </div>\n  </div>\n}", styles: [".form-control-container{position:relative;padding:0 .25rem 1.5rem}.form-control-container .p-disabled,.form-control-container .p-disabled .p-datatable-thead>tr>th,.form-control-container .p-disabled .p-datatable-tbody>tr>td,.form-control-container .p-editor.p-disabled .p-editor-toolbar,.form-control-container .p-editor.p-disabled .p-editor-content .ql-editor,.form-control-container frm-select-button-control .p-disabled .p-togglebutton{background:var(--p-inputtext-disabled-background);color:var(--p-inputtext-disabled-color);opacity:1}.form-control-container .hints{position:absolute;bottom:5px;left:5px;width:100%;font-size:11px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;gap:.5rem}.form-control-container .hints .control-error{color:var(--p-red-500)}.form-control-container .hints .help-text{color:var(--p-gray-600)}.form-control-container .p-select,.form-control-container .p-textarea,.form-control-container .p-autocomplete,.form-control-container .p-inputtext,.form-control-container .p-inputnumber,.form-control-container .p-multiselect,.form-control-container .p-iconfield,.form-control-container .p-datepicker{width:100%}.form-control-container .button-control{padding-top:15px;padding-left:10px;cursor:pointer}.form-control-container .textarea-input{resize:none}\n"] }]
        }], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], control: [{ type: i0.Input, args: [{ isSignal: true, alias: "control", required: true }] }], isFormReadonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "isFormReadonly", required: true }] }], defaultControlWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultControlWidth", required: true }] }], labelStrategy: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategy", required: true }] }], labelStrategyVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategyVariant", required: true }] }], syncValueInc: [{ type: i0.Input, args: [{ isSignal: true, alias: "syncValueInc", required: true }] }], fieldInteraction: [{ type: i0.Output, args: ["fieldInteraction"] }] } });

/**
 * Angular pipe to extract a FormGroup from a parent FormGroup using a key.
 *
 * @param parentForm The parent FormGroup.
 * @param key The key of the child FormGroup to retrieve.
 * @returns The child FormGroup if found, otherwise null.
 * @throws If the control at the given key is not a FormGroup.
 * @example
 *   <form [formGroup]="parentForm">
 *     <div *ngIf="parentForm | formGroupByKey:'address' as addressGroup">
 *       <!-- Use addressGroup here -->
 *     </div>
 *   </form>
 */
class FormGroupByKeyPipe {
    transform(parentForm, key) {
        if (!parentForm || !key) {
            return null;
        }
        const control = parentForm.get(key);
        if (control instanceof FormGroup) {
            return control;
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormGroupByKeyPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.7", ngImport: i0, type: FormGroupByKeyPipe, isStandalone: true, name: "formGroupByKey" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormGroupByKeyPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "formGroupByKey",
                    pure: true,
                }]
        }] });

class FullJsonPipe {
    transform(value) {
        return JSON.stringify(value, replacer, 2);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FullJsonPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.7", ngImport: i0, type: FullJsonPipe, isStandalone: true, name: "fullJson" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FullJsonPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "fullJson",
                }]
        }] });
function replacer(_key, value) {
    if (isFunction(value)) {
        const knownValidator = isKnownValidator(value);
        return knownValidator ? knownValidator : "Function";
    }
    return value;
}
function isKnownValidator(value) {
    const knownValidators = [
        "required",
        "minlength",
        "maxlength",
        "min",
        "max",
        "email",
    ];
    const functionString = value.toString();
    return (functionString
        // split by whitespace and parenthesis and double quotes
        .split(/[\s()]+|"/)
        .find((part) => knownValidators.includes(part)));
}

class ToControlPipe {
    transform(form, key) {
        return form.get(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ToControlPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.7", ngImport: i0, type: ToControlPipe, isStandalone: true, name: "toControl" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ToControlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "toControl",
                    /**
                     * Pipe that retrieves a specific `FormControl` from a given `FormGroup` by its key.
                     *
                     * @example
                     * // In a template:
                     * // <input [formControl]="form | toControl:'username'">
                     *
                     * @param form - The `FormGroup` instance containing the control.
                     * @param key - The name of the control to retrieve from the form group.
                     * @returns The `FormControl` associated with the specified key.
                     */
                }]
        }] });

const FOUR_COLUMN_WIDTH = "25%";
const THREE_COLUMN_WIDTH = "33.333%";
const TWO_COLUMN_WIDTH = "50%";
const ONE_COLUMN_WIDTH = "100%";
class FormComponent {
    // Injected services
    dynamicFormService = inject(FormBuilderService);
    destroyRef = inject(DestroyRef);
    labels = inject(CRUD_LABELS);
    // Inputs
    /** Defines the number of columns for form layout */
    columnsCount = input(1, ...(ngDevMode ? [{ debugName: "columnsCount" }] : /* istanbul ignore next */ []));
    /** Configuration array that defines the structure and behavior of form fields */
    config = model.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /** Trigger to force form recreation */
    forceReload = input(0, ...(ngDevMode ? [{ debugName: "forceReload" }] : /* istanbul ignore next */ []));
    /** Trigger to force form values reload without recreating the form */
    forceReloadValues = input(0, ...(ngDevMode ? [{ debugName: "forceReloadValues" }] : /* istanbul ignore next */ []));
    /** Custom validator applied to the entire form group */
    groupValidator = input(...(ngDevMode ? [undefined, { debugName: "groupValidator" }] : /* istanbul ignore next */ []));
    /** Makes the entire form read-only */
    isReadonly = input(false, ...(ngDevMode ? [{ debugName: "isReadonly" }] : /* istanbul ignore next */ []));
    /** Strategy for generating labels for form controls */
    labelStrategy = input("ifta", ...(ngDevMode ? [{ debugName: "labelStrategy" }] : /* istanbul ignore next */ []));
    /** Variant for the label strategy. Will be applied for float labels */
    labelStrategyVariant = input("on", ...(ngDevMode ? [{ debugName: "labelStrategyVariant" }] : /* istanbul ignore next */ []));
    /** Two-way binding for form values */
    model = model.required(...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    /** Custom label for the reset button */
    resetButtonLabel = input(undefined, ...(ngDevMode ? [{ debugName: "resetButtonLabel" }] : /* istanbul ignore next */ []));
    /** Shows debug information including form values and validation state */
    showDebug = input(false, ...(ngDevMode ? [{ debugName: "showDebug" }] : /* istanbul ignore next */ []));
    /** Shows/hides the reset button */
    showReset = input(false, ...(ngDevMode ? [{ debugName: "showReset" }] : /* istanbul ignore next */ []));
    /** Shows/hides the submit button */
    showSubmit = input(false, ...(ngDevMode ? [{ debugName: "showSubmit" }] : /* istanbul ignore next */ []));
    /** Custom label for the submit button */
    submitButtonLabel = input(undefined, ...(ngDevMode ? [{ debugName: "submitButtonLabel" }] : /* istanbul ignore next */ []));
    // Outputs
    /** Emitted when user interacts with form fields */
    fieldInteraction = output();
    /** Emitted when form values change (two-way binding) */
    modelChange = output();
    /** Emitted when form is reset (if showReset is true) */
    reset = output();
    /** Emitted when form is submitted (if showSubmit is true) */
    submitted = output();
    /** Emitted when form validation state changes */
    validityChange = output();
    // ViewChild
    /** Angular FormGroupDirective reference */
    formDir = viewChild("formGroup", { ...(ngDevMode ? { debugName: "formDir" } : /* istanbul ignore next */ {}), read: FormGroupDirective });
    // Computed
    /** Default width for form controls based on column count */
    defaultControlWidth = computed(() => {
        const size = this.columnsCount();
        switch (size) {
            case 4:
                return FOUR_COLUMN_WIDTH;
            case 3:
                return THREE_COLUMN_WIDTH;
            case 2:
                return TWO_COLUMN_WIDTH;
            default:
                return ONE_COLUMN_WIDTH;
        }
    }, ...(ngDevMode ? [{ debugName: "defaultControlWidth" }] : /* istanbul ignore next */ []));
    syncValueInc = signal(0, ...(ngDevMode ? [{ debugName: "syncValueInc" }] : /* istanbul ignore next */ []));
    /** Angular FormGroup instance */
    form = signal(null, ...(ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []));
    /** Formatted error messages from form validation */
    get formErrors() {
        const errors = this.form()?.errors ?? {};
        return Object.values(errors)
            .map((error) => supplant(error.message, error))
            .join(", ");
    }
    // Effects
    /** Effect to handle form reload when forceReload input changes */
    forceReloadFormEffect = effect(() => {
        if (this.forceReload() !== this.prevReloadForm) {
            this.prevReloadForm = this.forceReload();
            this.destroyForm();
            this.createAndWatchForm();
        }
    }, ...(ngDevMode ? [{ debugName: "forceReloadFormEffect" }] : /* istanbul ignore next */ []));
    // Private properties
    initialValues = {};
    prevReloadForm = 0;
    sub = null;
    pendingActions = signal([], ...(ngDevMode ? [{ debugName: "pendingActions" }] : /* istanbul ignore next */ []));
    // Lifecycle methods
    /**
     * Angular OnInit lifecycle hook
     * Initializes form creation and change watching
     */
    ngOnInit() {
        this.createAndWatchForm();
    }
    // Public methods
    /**
     * Resets form to initial values and emits reset event
     * resetForm() => clean values, validators, touched/dirty statuses...
     * resetForm(value) => set specific values but clean the rest
     */
    onReset() {
        this.formDir()?.resetForm(this.initialValues);
        this.syncValueInc.update((n) => n + 1);
        this.reset.emit();
    }
    /**
     * Handles form submission if valid
     */
    onSubmit() {
        if (!this.form()?.valid) {
            console.warn("Form is invalid, cannot submit.");
            // TODO: check show errors
            return;
        }
        // Reset the form to the saved values
        const newInitialValues = this.model();
        this.formDir()?.resetForm(newInitialValues);
        this.initialValues = newInitialValues;
        // Emit event for optional parent use
        this.submitted.emit(this.model());
    }
    /**
     * Track function for ngFor to optimize rendering
     */
    trackControl(index, item) {
        return `${index}-${item.key}-${JSON.stringify(item.controlOptions)}`;
    }
    emitInteraction(event) {
        this.fieldInteraction.emit(event);
        // Add to pending action if one is found for this control
        const action = this.config().find((item) => item.key === event.key)
            ?.controlOptions?.action;
        const pendingAction = action?.(event);
        if (pendingAction) {
            this.pendingActions.update((actions) => [...actions, ...pendingAction]);
        }
    }
    // Private methods
    /**
     * Applies condition result to the actual form control
     */
    applyCondition(controlKey, propertyName, value, parentForm) {
        const control = this.getControl(controlKey, parentForm);
        if (!control)
            return;
        switch (propertyName) {
            case "validators": {
                this.setValidators(control, value);
                break;
            }
            case "asyncValidators": {
                this.setAsyncValidators(control, value);
                break;
            }
            case "disabled": {
                this.setDisabled(control, value);
                break;
            }
            case "hidden": {
                this.setHidden(control, value);
                break;
            }
            case "defaultValue": {
                control.setValue(value);
                break;
            }
        }
    }
    /**
     * Creates form group and sets up value change watching
     */
    createAndWatchForm() {
        // Evaluate expressions before creating the form
        this.updateControlsWithConditions();
        // Create the form group
        const form = this.dynamicFormService.toFormGroup(this.config(), this.model(), this.groupValidator(), this.isReadonly() ?? false);
        // Set the initial values according to what has been set in the form
        const initialValues = form.getRawValue();
        this.model.set(initialValues);
        this.initialValues = initialValues;
        // Set the form group in the signal
        this.form.set(form);
        // Listen to changes in the form values
        this.sub = form.valueChanges
            .pipe(debounceTime(300), distinctUntilChanged((a, b) => isEqual(a, b)), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            // Get raw values to avoid issues with disabled controls
            const values = this.form()?.getRawValue();
            this.log();
            const evaluatedValues = this.evaluatePendingActions(values);
            this.pendingActions.set([]);
            this.model.set(evaluatedValues);
            this.modelChange.emit(evaluatedValues);
            this.updateControlsWithConditions();
            this.validityChange.emit(this.form()?.valid ?? false);
        });
    }
    evaluatePendingActions(currentValue) {
        let evaluatedValue = { ...currentValue };
        const actions = this.pendingActions();
        for (const action of actions) {
            // Do nothing if soft action and value is already set
            if (!isNil(evaluatedValue[action.key]) && action.soft)
                continue;
            // Otherwise, evaluate the action mode: push, remove, set (default)
            let valueToSet = action.value;
            switch (action.mode) {
                case "push": {
                    const current = evaluatedValue[action.key];
                    if (isNil(current)) {
                        valueToSet = [action.value];
                    }
                    else if (isArray(current)) {
                        valueToSet = [...current, action.value];
                    }
                    break;
                }
                case "remove": {
                    const current = evaluatedValue[action.key];
                    if (isArray(current)) {
                        valueToSet = current.filter((item) => item !== action.value);
                    }
                    break;
                }
                default: {
                    break;
                }
            }
            this.form()?.get(action.key)?.setValue(valueToSet, { emitEvent: false });
            evaluatedValue = { ...evaluatedValue, [action.key]: valueToSet };
        }
        return evaluatedValue;
    }
    log() {
        const formDir = this.formDir();
        if (formDir) {
            console.log({ value: formDir.value, valid: formDir.valid });
        }
    }
    /**
     * Destroys current form and cleans up subscriptions
     */
    destroyForm() {
        this.form.set(null);
        this.sub?.unsubscribe();
        this.sub = null;
    }
    /**
     * Gets a form control by key from parent form
     */
    getControl(itemKey, parentForm) {
        return parentForm?.get(itemKey.toString()) ?? null;
    }
    /**
     * Recursively evaluates and applies conditions to a control
     */
    getUpdatedControl(control, parentForm, model) {
        // recursively evaluate conditions
        // the value can either be a function or a nested property
        for (const key in control.conditions) {
            const prop = key;
            const value = control.conditions[prop];
            if (isFunction(value)) {
                const result = value({ control, model });
                control[prop] = result;
            }
            else {
                if (!control.controlOptions)
                    control.controlOptions = {};
                for (const subKey in value) {
                    const subProp = subKey;
                    const subValue = value[subProp];
                    if (isFunction(subValue)) {
                        const result = subValue({ control, model });
                        control.controlOptions[subProp] = result;
                        this.applyCondition(control.key, subProp, result, parentForm);
                    }
                }
            }
        }
        return {
            ...control,
            controlOptions: control.controlOptions
                ? { ...control.controlOptions }
                : undefined,
        }; // create a new object to trigger change detection
    }
    /**
     * Sets async validators on a form control
     */
    setAsyncValidators(control, asyncValidators) {
        control.setAsyncValidators(asyncValidators);
        control.updateValueAndValidity();
    }
    /**
     * Enables or disables a form control
     */
    setDisabled(control, disabled) {
        if (disabled) {
            control.disable();
        }
        else {
            control.enable();
        }
    }
    /**
     * Shows or hides a form control and resets its value if hidden
     */
    setHidden(control, hidden) {
        if (hidden) {
            const isFormArray = control instanceof FormArray;
            if (isFormArray) {
                control.clear();
            }
            else {
                // Simple FormControl
                control.reset();
            }
        }
    }
    /**
     * Sets validators on a form control
     */
    setValidators(control, validators) {
        control.setValidators(validators);
        control.updateValueAndValidity();
    }
    /**
     * Updates control configurations based on conditional logic
     */
    updateControlsWithConditions() {
        const model = this.model();
        this.config.update((controls) => {
            return controls.map((control) => {
                if (control.conditions) {
                    return this.getUpdatedControl(control, this.form(), model);
                }
                if (control.children) {
                    const form = this.form()?.get(control.key);
                    const values = (model[control.key] ?? {});
                    const updatedChildren = [];
                    for (const child of control.children) {
                        updatedChildren.push(this.getUpdatedControl(child, form, values));
                    }
                    return { ...control, children: updatedChildren };
                }
                return control;
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: FormComponent, isStandalone: true, selector: "frm-form", inputs: { columnsCount: { classPropertyName: "columnsCount", publicName: "columnsCount", isSignal: true, isRequired: false, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, forceReload: { classPropertyName: "forceReload", publicName: "forceReload", isSignal: true, isRequired: false, transformFunction: null }, forceReloadValues: { classPropertyName: "forceReloadValues", publicName: "forceReloadValues", isSignal: true, isRequired: false, transformFunction: null }, groupValidator: { classPropertyName: "groupValidator", publicName: "groupValidator", isSignal: true, isRequired: false, transformFunction: null }, isReadonly: { classPropertyName: "isReadonly", publicName: "isReadonly", isSignal: true, isRequired: false, transformFunction: null }, labelStrategy: { classPropertyName: "labelStrategy", publicName: "labelStrategy", isSignal: true, isRequired: false, transformFunction: null }, labelStrategyVariant: { classPropertyName: "labelStrategyVariant", publicName: "labelStrategyVariant", isSignal: true, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: true, transformFunction: null }, resetButtonLabel: { classPropertyName: "resetButtonLabel", publicName: "resetButtonLabel", isSignal: true, isRequired: false, transformFunction: null }, showDebug: { classPropertyName: "showDebug", publicName: "showDebug", isSignal: true, isRequired: false, transformFunction: null }, showReset: { classPropertyName: "showReset", publicName: "showReset", isSignal: true, isRequired: false, transformFunction: null }, showSubmit: { classPropertyName: "showSubmit", publicName: "showSubmit", isSignal: true, isRequired: false, transformFunction: null }, submitButtonLabel: { classPropertyName: "submitButtonLabel", publicName: "submitButtonLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { config: "configChange", model: "modelChange", fieldInteraction: "fieldInteraction", modelChange: "modelChange", reset: "reset", submitted: "submitted", validityChange: "validityChange" }, viewQueries: [{ propertyName: "formDir", first: true, predicate: ["formGroup"], descendants: true, read: FormGroupDirective, isSignal: true }], ngImport: i0, template: "@let _form = form();\n@if (_form) {\n  <div [formGroup]=\"_form\" class=\"form-container\" #formGroup=\"ngForm\">\n    @for (config of config(); track trackControl($index, config)) {\n      @if (config.controlType === \"group\") {\n        @let group= _form | formGroupByKey:config.key;\n        @if (group) {\n           <p-panel [formGroup]=\"group\" \n            class=\"form-group\" #childFormGroup=\"ngForm\" \n            [toggleable]=\"true\"\n            [header]=\"config.label\">\n            @for (child of config.children; track trackControl($index, child)) {              \n              <ng-container \n                [ngTemplateOutlet]=\"controlTemplate\" \n                [ngTemplateOutletContext]=\"{ $implicit: child, form: group }\" \n              />\n            }\n          </p-panel>\n        }\n      } @else if (config.controlOptions?.isFormArray) {\n        <frm-array-element \n          [config]=\"config\" \n          [formGroup]=\"_form\" \n          [defaultControlWidth]=\"defaultControlWidth()\"\n          [isFormReadonly]=\"isReadonly()\"\n          [syncValueInc]=\"syncValueInc()\"\n        />\n      } @else {\n        <ng-container \n          [ngTemplateOutlet]=\"controlTemplate\" \n          [ngTemplateOutletContext]=\"{ $implicit: config, form: _form }\" \n        />\n      }\n    }\n    @empty {\n      <p class=\"empty-form\">{{ labels.form.noFields }}</p>\n    }\n  </div>\n  @if (formErrors) {\n    <small class=\"error\">\n      <i class=\"pi pi-exclamation-triangle\"></i>\n      {{ formErrors }}\n    </small>\n  }\n  <div class=\"actions-container\">\n    @if (showReset()) {\n      <crd-crud-button \n        type=\"cancel\"\n        [label]=\"resetButtonLabel() ?? labels.form.reset\" \n        (click)=\"onReset()\" \n        [disabled]=\"formGroup.pristine ?? true\"\n      />\n    }\n    @if (showSubmit()) {\n      <crd-crud-button \n        type=\"validate\"\n        [label]=\"submitButtonLabel() ?? labels.form.submit\" \n        (click)=\"onSubmit()\" \n        [disabled]=\"formGroup.invalid ?? true\" \n      />\n    }\n  </div> \n  @if (showDebug()) {\n    <h4>Debug: values</h4>\n    <pre>{{ model() | json }}</pre>\n    <h4>Debug: conf</h4>\n    <pre>{{ config() | fullJson }}</pre>\n  } \n} @else {\n  <p-progressSpinner />\n}\n\n\n<ng-template #controlTemplate let-item let-form=\"form\">\n    <frm-simple-element\n      [config]=\"item\"\n      [control]=\"form | toControl:item.key\"\n      [isFormReadonly]=\"isReadonly()\"\n      [defaultControlWidth]=\"defaultControlWidth()\"\n      [labelStrategy]=\"labelStrategy()\"\n      [labelStrategyVariant]=\"labelStrategyVariant()\"\n      [syncValueInc]=\"syncValueInc()\"\n      (fieldInteraction)=\"emitInteraction($event)\"\n    />\n</ng-template>", styles: [".form-container{position:relative;display:flex;flex-wrap:wrap}.form-container .display-none{display:none}.form-container .error{color:red}.form-container .form-group{width:100%;display:flex;flex-wrap:wrap;padding:5px;border-radius:8px;background-color:var(--primary-bg-color);margin:10px 0}.form-container .form-group .p-panel-header{width:100%}.form-container .form-group .p-panel-content{display:flex;flex-wrap:wrap;align-items:center}.actions-container{display:flex;align-items:center;justify-content:space-between;margin-top:1rem}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: FormSimpleElement, selector: "frm-simple-element", inputs: ["config", "control", "isFormReadonly", "defaultControlWidth", "labelStrategy", "labelStrategyVariant", "syncValueInc"], outputs: ["fieldInteraction"] }, { kind: "ngmodule", type: ProgressSpinnerModule }, { kind: "component", type: i2$5.ProgressSpinner, selector: "p-progressSpinner, p-progress-spinner, p-progressspinner", inputs: ["styleClass", "strokeWidth", "fill", "animationDuration", "ariaLabel"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: FormArrayElement, selector: "frm-array-element", inputs: ["config", "formGroup", "isFormReadonly", "defaultControlWidth", "syncValueInc"] }, { kind: "component", type: CrudButtonComponent, selector: "crd-crud-button", inputs: ["type", "disabled", "loading", "label", "icon", "severity"], outputs: ["clicked"] }, { kind: "ngmodule", type: PanelModule }, { kind: "component", type: i3$1.Panel, selector: "p-panel", inputs: ["id", "toggleable", "header", "collapsed", "styleClass", "iconPos", "showHeader", "toggler", "transitionOptions", "toggleButtonProps", "motionOptions"], outputs: ["collapsedChange", "onBeforeToggle", "onAfterToggle"] }, { kind: "pipe", type: JsonPipe, name: "json" }, { kind: "pipe", type: FullJsonPipe, name: "fullJson" }, { kind: "pipe", type: FormGroupByKeyPipe, name: "formGroupByKey" }, { kind: "pipe", type: ToControlPipe, name: "toControl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FormComponent, decorators: [{
            type: Component,
            args: [{ selector: "frm-form", imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        FormSimpleElement,
                        JsonPipe,
                        FullJsonPipe,
                        ProgressSpinnerModule,
                        FormGroupByKeyPipe,
                        NgTemplateOutlet,
                        FormArrayElement,
                        ToControlPipe,
                        CrudButtonComponent,
                        PanelModule,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "@let _form = form();\n@if (_form) {\n  <div [formGroup]=\"_form\" class=\"form-container\" #formGroup=\"ngForm\">\n    @for (config of config(); track trackControl($index, config)) {\n      @if (config.controlType === \"group\") {\n        @let group= _form | formGroupByKey:config.key;\n        @if (group) {\n           <p-panel [formGroup]=\"group\" \n            class=\"form-group\" #childFormGroup=\"ngForm\" \n            [toggleable]=\"true\"\n            [header]=\"config.label\">\n            @for (child of config.children; track trackControl($index, child)) {              \n              <ng-container \n                [ngTemplateOutlet]=\"controlTemplate\" \n                [ngTemplateOutletContext]=\"{ $implicit: child, form: group }\" \n              />\n            }\n          </p-panel>\n        }\n      } @else if (config.controlOptions?.isFormArray) {\n        <frm-array-element \n          [config]=\"config\" \n          [formGroup]=\"_form\" \n          [defaultControlWidth]=\"defaultControlWidth()\"\n          [isFormReadonly]=\"isReadonly()\"\n          [syncValueInc]=\"syncValueInc()\"\n        />\n      } @else {\n        <ng-container \n          [ngTemplateOutlet]=\"controlTemplate\" \n          [ngTemplateOutletContext]=\"{ $implicit: config, form: _form }\" \n        />\n      }\n    }\n    @empty {\n      <p class=\"empty-form\">{{ labels.form.noFields }}</p>\n    }\n  </div>\n  @if (formErrors) {\n    <small class=\"error\">\n      <i class=\"pi pi-exclamation-triangle\"></i>\n      {{ formErrors }}\n    </small>\n  }\n  <div class=\"actions-container\">\n    @if (showReset()) {\n      <crd-crud-button \n        type=\"cancel\"\n        [label]=\"resetButtonLabel() ?? labels.form.reset\" \n        (click)=\"onReset()\" \n        [disabled]=\"formGroup.pristine ?? true\"\n      />\n    }\n    @if (showSubmit()) {\n      <crd-crud-button \n        type=\"validate\"\n        [label]=\"submitButtonLabel() ?? labels.form.submit\" \n        (click)=\"onSubmit()\" \n        [disabled]=\"formGroup.invalid ?? true\" \n      />\n    }\n  </div> \n  @if (showDebug()) {\n    <h4>Debug: values</h4>\n    <pre>{{ model() | json }}</pre>\n    <h4>Debug: conf</h4>\n    <pre>{{ config() | fullJson }}</pre>\n  } \n} @else {\n  <p-progressSpinner />\n}\n\n\n<ng-template #controlTemplate let-item let-form=\"form\">\n    <frm-simple-element\n      [config]=\"item\"\n      [control]=\"form | toControl:item.key\"\n      [isFormReadonly]=\"isReadonly()\"\n      [defaultControlWidth]=\"defaultControlWidth()\"\n      [labelStrategy]=\"labelStrategy()\"\n      [labelStrategyVariant]=\"labelStrategyVariant()\"\n      [syncValueInc]=\"syncValueInc()\"\n      (fieldInteraction)=\"emitInteraction($event)\"\n    />\n</ng-template>", styles: [".form-container{position:relative;display:flex;flex-wrap:wrap}.form-container .display-none{display:none}.form-container .error{color:red}.form-container .form-group{width:100%;display:flex;flex-wrap:wrap;padding:5px;border-radius:8px;background-color:var(--primary-bg-color);margin:10px 0}.form-container .form-group .p-panel-header{width:100%}.form-container .form-group .p-panel-content{display:flex;flex-wrap:wrap;align-items:center}.actions-container{display:flex;align-items:center;justify-content:space-between;margin-top:1rem}\n"] }]
        }], propDecorators: { columnsCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnsCount", required: false }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }, { type: i0.Output, args: ["configChange"] }], forceReload: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceReload", required: false }] }], forceReloadValues: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceReloadValues", required: false }] }], groupValidator: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupValidator", required: false }] }], isReadonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "isReadonly", required: false }] }], labelStrategy: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategy", required: false }] }], labelStrategyVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategyVariant", required: false }] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: true }] }, { type: i0.Output, args: ["modelChange"] }], resetButtonLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetButtonLabel", required: false }] }], showDebug: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDebug", required: false }] }], showReset: [{ type: i0.Input, args: [{ isSignal: true, alias: "showReset", required: false }] }], showSubmit: [{ type: i0.Input, args: [{ isSignal: true, alias: "showSubmit", required: false }] }], submitButtonLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "submitButtonLabel", required: false }] }], fieldInteraction: [{ type: i0.Output, args: ["fieldInteraction"] }], modelChange: [{ type: i0.Output, args: ["modelChange"] }], reset: [{ type: i0.Output, args: ["reset"] }], submitted: [{ type: i0.Output, args: ["submitted"] }], validityChange: [{ type: i0.Output, args: ["validityChange"] }], formDir: [{ type: i0.ViewChild, args: ["formGroup", { ...{
                            read: FormGroupDirective,
                        }, isSignal: true }] }] } });

const NO_ROWS_AND_COUNT = {
    rows: [],
    total: 0,
};
const NO_ROWS = {
    rows: [],
};

/**
 * Optional injection token to provide a global mapper that transforms raw API history rows
 * into the `HistorizedData` shape expected by the history component.
 *
 * Provide this token in your `app.config.ts` when your API response shape differs
 * from the `HistorizedData` contract (e.g. different field names).
 *
 * The `historyMapper` input on `EditionDialogComponent` takes precedence over this token
 * when both are defined.
 *
 * @example
 * // app.config.ts
 * {
 *   provide: HISTORY_MAPPER,
 *   useValue: (raw: unknown): HistorizedData<unknown> => {
 *     const r = raw as { timestamp: string; action: string; consumerId: number; consumerName: string; data: unknown };
 *     return {
 *       tstamp: r.timestamp,
 *       operation: r.action,
 *       updaterId: r.consumerId,
 *       updaterName: r.consumerName,
 *       val: r.data,
 *       table_name: 'unknown',
 *     };
 *   }
 * }
 */
const HISTORY_MAPPER = new InjectionToken("HISTORY_MAPPER");

class HistoryComponent {
    labels = inject(CRUD_LABELS);
    data = input.required(...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    rows = computed(() => this.buildHistoryTable(), ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    selected = output();
    showOldValue = input(false, ...(ngDevMode ? [{ debugName: "showOldValue" }] : /* istanbul ignore next */ []));
    dateFormat = DATE_WITH_SECONDS_FORMAT;
    selectedDate = null;
    expandedRows = {};
    showVersion(entry) {
        this.selectedDate = entry.tstamp;
        this.selected.emit(entry);
    }
    buildHistoryTable() {
        const rows = [...(this.data()?.rows ?? [])].sort((a, b) => new Date(b.tstamp).getTime() - new Date(a.tstamp).getTime());
        return rows.map((row, rowIndex) => {
            const currentRow = row.record;
            const lastRow = rows[rowIndex + 1]?.record;
            const changes = [];
            for (const propKey in currentRow) {
                const change = this.buildChangesTable(propKey, currentRow, lastRow);
                if (change) {
                    changes.push(change);
                }
            }
            return { ...row, changes };
        });
    }
    buildChangesTable(propKey, currentRow, lastRow) {
        const confItem = this.config().find((c) => c.key === propKey);
        const isHidden = confItem?.controlOptions?.hidden;
        if (!isHidden && confItem) {
            const label = confItem.label;
            const newValue = currentRow[propKey];
            const oldValue = lastRow ? lastRow[propKey] : undefined;
            return {
                propKey,
                label,
                oldValue,
                newValue,
                hasChanged: !isEqual(oldValue, newValue),
            };
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: HistoryComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: HistoryComponent, isStandalone: true, selector: "crd-history", inputs: { data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, showOldValue: { classPropertyName: "showOldValue", publicName: "showOldValue", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selected: "selected" }, ngImport: i0, template: "@if (rows()) {\n  <p-table [value]=\"rows()\"\n    dataKey=\"id\"\n    [expandedRowKeys]=\"expandedRows\">\n    <ng-template #header>\n      <tr>\n        <th class=\"first-col\"></th>\n          <th>{{ labels.history.updatedAt }}</th>\n        <th>{{ labels.history.updatedBy }}</th>\n        <th></th>\n      </tr>\n    </ng-template>\n    <ng-template #body let-entry let-rowIndex=\"rowIndex\" let-expanded=\"expanded\">\n      <tr [class.selected]=\"entry.tstamp === selectedDate\">\n        <td class=\"first-col\">\n          <p-button type=\"button\" pRipple\n            [pRowToggler]=\"entry\"\n            [text]=\"true\"\n            [rounded]=\"true\"\n            [plain]=\"true\"\n            [icon]=\"expanded ? 'pi pi-chevron-down' : 'pi pi-chevron-right'\" \n          />\n        </td>\n        <td>{{ entry.tstamp | date:dateFormat }}</td>\n        <td>{{ entry.updaterName }}</td>\n        <td>\n          @if (rowIndex) {\n            <p-button type=\"button\" pRipple\n              class=\"action-button\"\n              icon=\"pi pi-history\"\n              [title]=\"labels.history.restore\"\n              (click)=\"showVersion(entry)\"\n            />\n          }\n        </td>\n      </tr>\n    </ng-template>\n    <ng-template #expandedrow let-entry>\n      <tr>\n        <td class=\"first-col\"></td>\n        <td colspan=\"3\" class=\"expansion-cell\">\n          @if (entry.changes.length > 0) {\n            <div class=\"changes-grid\" [class.show-old-value]=\"showOldValue()\">\n              <div class=\"changes-header\">{{ labels.history.property }}</div>\n              <div class=\"changes-header\">{{ labels.history.value }}</div>\n              @if (showOldValue()) {\n                <div class=\"changes-header\">{{ labels.history.previousValue }}</div>\n              }\n              @for (row of entry.changes; track row.propKey) {\n                <div class=\"changes-cell\">{{ row.label }}</div>\n                <div class=\"changes-cell\" [class.has-changed]=\"row.hasChanged\">{{ row.newValue }}</div>\n                @if (showOldValue()) {\n                  <div class=\"changes-cell\">{{ row.oldValue }}</div>\n                }\n              }\n            </div>\n          } @else {\n            <div class=\"no-changes\">{{ labels.history.noChanges }}</div>\n          }\n        </td>\n      </tr>\n      \n    </ng-template>\n  </p-table>\n}\n", styles: ["crd-history td:not(.first-col):not(.expansion-cell),crd-history th:not(.first-col):not(.expansion-cell){width:200px;max-width:200px;min-width:200px;overflow:hidden;text-overflow:ellipsis;padding:5px}crd-history .first-col{width:100px;max-width:100px;min-width:100px;padding:5px!important}crd-history .first-col p-button button{padding:0}crd-history td.expansion-cell{padding:0!important;width:auto!important;max-width:none!important;min-width:0!important}crd-history .changes-grid{display:grid;grid-template-columns:200px 1fr}crd-history .changes-grid.show-old-value{grid-template-columns:200px 1fr 1fr}crd-history .changes-header{padding:5px;font-weight:700;border-bottom:1px solid var(--p-datatable-border-color, #e2e8f0);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}crd-history .changes-cell{padding:5px;border-bottom:1px solid var(--p-datatable-border-color, #e2e8f0);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}crd-history .action-button button{width:20px;height:20px;margin:2px}crd-history .has-changed{color:var(--p-orange-500);font-weight:700}\n"], dependencies: [{ kind: "ngmodule", type: TableModule }, { kind: "component", type: i1$b.Table, selector: "p-table", inputs: ["frozenColumns", "frozenValue", "styleClass", "tableStyle", "tableStyleClass", "paginator", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorStyleClass", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "selectionMode", "selectionPageOnly", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "rowSelectable", "rowTrackBy", "lazy", "lazyLoadOnInit", "compareSelectionBy", "csvSeparator", "exportFilename", "filters", "globalFilterFields", "filterDelay", "filterLocale", "expandedRowKeys", "editingRowKeys", "rowExpandMode", "scrollable", "rowGroupMode", "scrollHeight", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "virtualScrollDelay", "frozenWidth", "contextMenu", "resizableColumns", "columnResizeMode", "reorderableColumns", "loading", "loadingIcon", "showLoader", "rowHover", "customSort", "showInitialSortBadge", "exportFunction", "exportHeader", "stateKey", "stateStorage", "editMode", "groupRowsBy", "size", "showGridlines", "stripedRows", "groupRowsByOrder", "responsiveLayout", "breakpoint", "paginatorLocale", "value", "columns", "first", "rows", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection", "selectAll"], outputs: ["contextMenuSelectionChange", "selectAllChange", "selectionChange", "onRowSelect", "onRowUnselect", "onPage", "onSort", "onFilter", "onLazyLoad", "onRowExpand", "onRowCollapse", "onContextMenuSelect", "onColResize", "onColReorder", "onRowReorder", "onEditInit", "onEditComplete", "onEditCancel", "onHeaderCheckboxToggle", "sortFunction", "firstChange", "rowsChange", "onStateSave", "onStateRestore"] }, { kind: "directive", type: i1$b.RowToggler, selector: "[pRowToggler]", inputs: ["pRowToggler", "pRowTogglerDisabled"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i1.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "pipe", type: DatePipe, name: "date" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: HistoryComponent, decorators: [{
            type: Component,
            args: [{ selector: "crd-history", imports: [TableModule, SharedModule, DatePipe, ButtonModule], encapsulation: ViewEncapsulation.None, template: "@if (rows()) {\n  <p-table [value]=\"rows()\"\n    dataKey=\"id\"\n    [expandedRowKeys]=\"expandedRows\">\n    <ng-template #header>\n      <tr>\n        <th class=\"first-col\"></th>\n          <th>{{ labels.history.updatedAt }}</th>\n        <th>{{ labels.history.updatedBy }}</th>\n        <th></th>\n      </tr>\n    </ng-template>\n    <ng-template #body let-entry let-rowIndex=\"rowIndex\" let-expanded=\"expanded\">\n      <tr [class.selected]=\"entry.tstamp === selectedDate\">\n        <td class=\"first-col\">\n          <p-button type=\"button\" pRipple\n            [pRowToggler]=\"entry\"\n            [text]=\"true\"\n            [rounded]=\"true\"\n            [plain]=\"true\"\n            [icon]=\"expanded ? 'pi pi-chevron-down' : 'pi pi-chevron-right'\" \n          />\n        </td>\n        <td>{{ entry.tstamp | date:dateFormat }}</td>\n        <td>{{ entry.updaterName }}</td>\n        <td>\n          @if (rowIndex) {\n            <p-button type=\"button\" pRipple\n              class=\"action-button\"\n              icon=\"pi pi-history\"\n              [title]=\"labels.history.restore\"\n              (click)=\"showVersion(entry)\"\n            />\n          }\n        </td>\n      </tr>\n    </ng-template>\n    <ng-template #expandedrow let-entry>\n      <tr>\n        <td class=\"first-col\"></td>\n        <td colspan=\"3\" class=\"expansion-cell\">\n          @if (entry.changes.length > 0) {\n            <div class=\"changes-grid\" [class.show-old-value]=\"showOldValue()\">\n              <div class=\"changes-header\">{{ labels.history.property }}</div>\n              <div class=\"changes-header\">{{ labels.history.value }}</div>\n              @if (showOldValue()) {\n                <div class=\"changes-header\">{{ labels.history.previousValue }}</div>\n              }\n              @for (row of entry.changes; track row.propKey) {\n                <div class=\"changes-cell\">{{ row.label }}</div>\n                <div class=\"changes-cell\" [class.has-changed]=\"row.hasChanged\">{{ row.newValue }}</div>\n                @if (showOldValue()) {\n                  <div class=\"changes-cell\">{{ row.oldValue }}</div>\n                }\n              }\n            </div>\n          } @else {\n            <div class=\"no-changes\">{{ labels.history.noChanges }}</div>\n          }\n        </td>\n      </tr>\n      \n    </ng-template>\n  </p-table>\n}\n", styles: ["crd-history td:not(.first-col):not(.expansion-cell),crd-history th:not(.first-col):not(.expansion-cell){width:200px;max-width:200px;min-width:200px;overflow:hidden;text-overflow:ellipsis;padding:5px}crd-history .first-col{width:100px;max-width:100px;min-width:100px;padding:5px!important}crd-history .first-col p-button button{padding:0}crd-history td.expansion-cell{padding:0!important;width:auto!important;max-width:none!important;min-width:0!important}crd-history .changes-grid{display:grid;grid-template-columns:200px 1fr}crd-history .changes-grid.show-old-value{grid-template-columns:200px 1fr 1fr}crd-history .changes-header{padding:5px;font-weight:700;border-bottom:1px solid var(--p-datatable-border-color, #e2e8f0);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}crd-history .changes-cell{padding:5px;border-bottom:1px solid var(--p-datatable-border-color, #e2e8f0);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}crd-history .action-button button{width:20px;height:20px;margin:2px}crd-history .has-changed{color:var(--p-orange-500);font-weight:700}\n"] }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], selected: [{ type: i0.Output, args: ["selected"] }], showOldValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "showOldValue", required: false }] }] } });

class EditionDialogComponent {
    labels = inject(CRUD_LABELS);
    globalHistoryMapper = inject(HISTORY_MAPPER, {
        optional: true,
    });
    // Inputs
    /** Configuration array that defines the structure and behavior of form fields */
    config = input([], ...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /** CRUD features configuration that defines available operations */
    features = input({}, ...(ngDevMode ? [{ debugName: "features" }] : /* istanbul ignore next */ []));
    /** Function to retrieve history data for an entry by ID */
    getHistory = input(...(ngDevMode ? [undefined, { debugName: "getHistory" }] : /* istanbul ignore next */ []));
    /**
     * Optional mapper to transform raw history rows from the API into `HistorizedData<TData>`.
     * Use this when the API response shape differs from the expected `HistorizedData` contract.
     */
    historyMapper = input(...(ngDevMode ? [undefined, { debugName: "historyMapper" }] : /* istanbul ignore next */ []));
    /** Custom validator applied to the entire form group */
    groupValidator = input(...(ngDevMode ? [undefined, { debugName: "groupValidator" }] : /* istanbul ignore next */ []));
    /** Dialog header title text */
    customHeader = input("", ...(ngDevMode ? [{ debugName: "customHeader" }] : /* istanbul ignore next */ []));
    /** Displayed entity label */
    entityLabel = input("", ...(ngDevMode ? [{ debugName: "entityLabel" }] : /* istanbul ignore next */ []));
    /** Dialog height (CSS value) */
    height = input(...(ngDevMode ? [undefined, { debugName: "height" }] : /* istanbul ignore next */ []));
    /** Whether the dialog is in creation mode (vs edit mode) */
    isCreation = input(false, ...(ngDevMode ? [{ debugName: "isCreation" }] : /* istanbul ignore next */ []));
    /** Whether the dialog is in readonly mode */
    isReadonly = input(false, ...(ngDevMode ? [{ debugName: "isReadonly" }] : /* istanbul ignore next */ []));
    /** Controls dialog visibility state */
    isVisible = input(false, ...(ngDevMode ? [{ debugName: "isVisible" }] : /* istanbul ignore next */ []));
    /** Dialog width (CSS value) */
    width = input(undefined, ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    /**
     * Optional option to configure the default size of the dialog
     * @param "xs" | "s" | "m" | "l"
     * @default "s"
     * */
    size = input("s", ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Is something loading */
    isLoading = input(false, ...(ngDevMode ? [{ debugName: "isLoading" }] : /* istanbul ignore next */ []));
    /** Strategy for generating labels for form controls */
    labelStrategy = input("ifta", ...(ngDevMode ? [{ debugName: "labelStrategy" }] : /* istanbul ignore next */ []));
    /** Variant for the label strategy. Will be applied for float labels */
    labelStrategyVariant = input("on", ...(ngDevMode ? [{ debugName: "labelStrategyVariant" }] : /* istanbul ignore next */ []));
    // Model inputs
    /** The data object being edited (two-way binding) */
    editedEntry = model.required(...(ngDevMode ? [{ debugName: "editedEntry" }] : /* istanbul ignore next */ []));
    // Outputs
    /** Emitted when entry is archived/deleted */
    archived = output();
    /** Emitted when entry is restored */
    restored = output();
    /** Emitted when entry is edited (value changes) */
    edited = output();
    /** Emitted when form values change */
    formChanged = output();
    /** Emitted when dialog should be hidden */
    hide = output();
    /** Emitted when entry is saved */
    saved = output();
    /** Emitted when form validation state changes */
    validityChanged = output();
    // Public properties
    /** Whether the form is currently invalid */
    invalidForm = true;
    /** Timestamp to force form reload */
    forceReloadTime = signal(0, ...(ngDevMode ? [{ debugName: "forceReloadTime" }] : /* istanbul ignore next */ []));
    /** Whether to show the previous value column in history */
    showOldValue = signal(false, ...(ngDevMode ? [{ debugName: "showOldValue" }] : /* istanbul ignore next */ []));
    // Computed
    /** ID of the currently edited entry */
    editedEntryId = computed(() => this.editedEntry()?.id, ...(ngDevMode ? [{ debugName: "editedEntryId" }] : /* istanbul ignore next */ []));
    /** Calculated width of the dialog based on size or fixed width */
    calculatedWidth = computed(() => {
        const size = this.size();
        const fixedWidth = this.width();
        if (fixedWidth) {
            return fixedWidth;
        }
        switch (size) {
            case "xs":
                return "400px";
            case "s":
                return "50vw";
            case "m":
                return "70vw";
            case "l":
                return "90vw";
            default:
                return "50vw";
        }
    }, ...(ngDevMode ? [{ debugName: "calculatedWidth" }] : /* istanbul ignore next */ []));
    formColumnsCount = computed(() => {
        const size = this.size();
        switch (size) {
            case "xs":
                return 1;
            case "s":
                return 2;
            case "m":
                return 3;
            case "l":
                return 4;
            default:
                return 1;
        }
    }, ...(ngDevMode ? [{ debugName: "formColumnsCount" }] : /* istanbul ignore next */ []));
    /** Dialog header label */
    dialogTitle = computed(() => {
        if (this.customHeader()) {
            return this.customHeader();
        }
        let action;
        if (this.isCreation()) {
            action = this.labels.editionDialog.modeCreate;
        }
        else if (this.isReadonly()) {
            action = this.labels.editionDialog.modeConsult;
        }
        else {
            action = this.labels.editionDialog.modeEdit;
        }
        return `${action} - ${this.entityLabel()}`;
    }, ...(ngDevMode ? [{ debugName: "dialogTitle" }] : /* istanbul ignore next */ []));
    canArchiveRestore = computed(() => {
        if (!this.canInteract())
            return false;
        if (this.isCreation())
            return false;
        return true;
    }, ...(ngDevMode ? [{ debugName: "canArchiveRestore" }] : /* istanbul ignore next */ []));
    isArchiveBtnDisplayed = computed(() => {
        return (this.features().archive &&
            this.canArchiveRestore() &&
            !this.editedEntry()?.archived);
    }, ...(ngDevMode ? [{ debugName: "isArchiveBtnDisplayed" }] : /* istanbul ignore next */ []));
    isRestoreBtnDisplayed = computed(() => {
        return (this.features().restore &&
            this.canArchiveRestore() &&
            this.editedEntry()?.archived);
    }, ...(ngDevMode ? [{ debugName: "isRestoreBtnDisplayed" }] : /* istanbul ignore next */ []));
    /** Observable stream of history data for the current entry */
    history$ = toObservable(this.editedEntryId).pipe(distinctUntilChanged(), filter((id) => !!id), switchMap((id) => {
        const getHistory = this.getHistory();
        if (this.features().getHistory && getHistory) {
            return getHistory(id).pipe(map(({ rows, total }) => {
                const mapper = this.historyMapper() ??
                    this.globalHistoryMapper;
                return {
                    rows: mapper
                        ? rows.map(mapper)
                        : rows,
                    total,
                };
            }));
        }
        return of(NO_ROWS_AND_COUNT);
    }));
    /** Whether the save button should be displayed based on form state and permissions */
    canInteract = computed(() => {
        if (this.isReadonly())
            return false;
        if (this.isCreation())
            return true;
        if (!this.features().update)
            return false;
        const areAllFieldsReadonly = this.config().every((ctrl) => ctrl.controlOptions?.disabled || ctrl.controlOptions?.hidden);
        return !areAllFieldsReadonly;
    }, ...(ngDevMode ? [{ debugName: "canInteract" }] : /* istanbul ignore next */ []));
    closeButtonLabel = computed(() => {
        return this.canInteract()
            ? this.labels.editionDialog.cancel
            : this.labels.editionDialog.close;
    }, ...(ngDevMode ? [{ debugName: "closeButtonLabel" }] : /* istanbul ignore next */ []));
    // Public methods
    /**
     * Handles form value changes and updates the edited entry
     * @param value - The new form values
     */
    onFormChanged(value) {
        this.editedEntry.set(value);
        // if (this.canOnlyCloseEditionModal()) {
        //   this.edited.emit(this.editedEntry());
        // }
    }
    /**
     * Handles form validation state changes
     * @param valid - Whether the form is currently valid
     */
    onValidityChange(valid) {
        this.invalidForm = !valid;
    }
    /**
     * Handles selection of a history entry to restore
     * @param entry - The history entry to restore
     */
    onHistorySelect(entry) {
        this.editedEntry.set(entry.record);
        this.invalidForm = false;
        this.forceReloadTime.set(Date.now());
    }
    /**
     * Handles save action and emits the current entry
     */
    onSave() {
        this.saved.emit(this.editedEntry());
    }
    /**
     * Handles dialog hide action
     */
    onHide() {
        this.hide.emit();
    }
    /**
     * Handles delete/archive action and emits the current entry
     */
    onArchive() {
        this.archived.emit(this.editedEntry());
    }
    onRestore() {
        this.archived.emit(this.editedEntry());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: EditionDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: EditionDialogComponent, isStandalone: true, selector: "crd-edition-dialog", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: false, transformFunction: null }, features: { classPropertyName: "features", publicName: "features", isSignal: true, isRequired: false, transformFunction: null }, getHistory: { classPropertyName: "getHistory", publicName: "getHistory", isSignal: true, isRequired: false, transformFunction: null }, historyMapper: { classPropertyName: "historyMapper", publicName: "historyMapper", isSignal: true, isRequired: false, transformFunction: null }, groupValidator: { classPropertyName: "groupValidator", publicName: "groupValidator", isSignal: true, isRequired: false, transformFunction: null }, customHeader: { classPropertyName: "customHeader", publicName: "customHeader", isSignal: true, isRequired: false, transformFunction: null }, entityLabel: { classPropertyName: "entityLabel", publicName: "entityLabel", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, isCreation: { classPropertyName: "isCreation", publicName: "isCreation", isSignal: true, isRequired: false, transformFunction: null }, isReadonly: { classPropertyName: "isReadonly", publicName: "isReadonly", isSignal: true, isRequired: false, transformFunction: null }, isVisible: { classPropertyName: "isVisible", publicName: "isVisible", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, isLoading: { classPropertyName: "isLoading", publicName: "isLoading", isSignal: true, isRequired: false, transformFunction: null }, labelStrategy: { classPropertyName: "labelStrategy", publicName: "labelStrategy", isSignal: true, isRequired: false, transformFunction: null }, labelStrategyVariant: { classPropertyName: "labelStrategyVariant", publicName: "labelStrategyVariant", isSignal: true, isRequired: false, transformFunction: null }, editedEntry: { classPropertyName: "editedEntry", publicName: "editedEntry", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { editedEntry: "editedEntryChange", archived: "archived", restored: "restored", edited: "edited", formChanged: "formChanged", hide: "hide", saved: "saved", validityChanged: "validityChanged" }, ngImport: i0, template: "<p-dialog\n  [visible]=\"isVisible()\"\n  [style]=\"{width: calculatedWidth(), height: height()}\"\n  [header]=\"dialogTitle()\"\n  [modal]=\"true\"\n  [maximizable]=\"true\"\n  styleClass=\"p-fluid\"\n  (visibleChange)=\"$event ? false : onHide()\"\n  (onHide)=\"onHide()\"\n  appendTo=\"body\">\n\n  <ng-template pTemplate=\"content\">\n    <div class=\"content-container\">\n      <frm-form\n        [config]=\"config()\"\n        [model]=\"editedEntry()\"\n        [groupValidator]=\"groupValidator()\"\n        [isReadonly]=\"isReadonly()\"\n        [forceReload]=\"forceReloadTime()\"\n        [columnsCount]=\"formColumnsCount()\"\n        [labelStrategy]=\"labelStrategy()\"\n        [labelStrategyVariant]=\"labelStrategyVariant()\"\n        (modelChange)=\"onFormChanged($event)\"\n        (validityChange)=\"onValidityChange($event)\"\n      />\n\n      @if (features().getHistory && !!getHistory()) {\n        @let historyData = history$ | async;\n        @if (historyData) {\n          <p-card>\n            <ng-template #header>\n              <span>\n                {{ labels.editionDialog.historyHeader }} ({{ historyData.total ?? historyData.rows.length }})\n              </span>\n              <!-- <span class=\"history-header-toggle\">\n                <p-checkbox [(ngModel)]=\"showOldValue\" [binary]=\"true\" inputId=\"showOldValue\" />\n                <label for=\"showOldValue\">{{ labels.history.showPreviousValue }}</label>\n              </span> -->\n            </ng-template>\n            <crd-history\n              [data]=\"historyData\"\n              [config]=\"config()\"\n              [showOldValue]=\"showOldValue()\"\n              (selected)=\"onHistorySelect($event)\"\n            />\n          </p-card>\n        }\n      }\n    </div>\n  </ng-template>\n\n  <ng-template pTemplate=\"footer\">\n    <div class=\"dialog-actions-container\">\n      <div class=\"left-actions\">\n        <crd-crud-button\n          type=\"cancel\"\n          [label]=\"closeButtonLabel()\"\n          icon=\"pi pi-times\"\n          [disabled]=\"isLoading()\"\n          (click)=\"onHide()\"\n        />\n        @if (isArchiveBtnDisplayed()) {\n          <crd-crud-button\n            type=\"delete\"\n            [label]=\"labels.editionDialog.archive\"\n            icon=\"pi pi-trash\"\n            [disabled]=\"isLoading()\"\n            (click)=\"onArchive()\"\n          />\n        }\n        @if (isRestoreBtnDisplayed()) {\n          <crd-crud-button\n            type=\"restore\"\n            icon=\"pi pi-bolt\"\n            [disabled]=\"isLoading()\"\n            (click)=\"onRestore()\"\n          />\n        }\n      </div>\n\n      <div class=\"right-actions\">\n        @if (canInteract()) {\n          <crd-crud-button\n            type=\"validate\"\n            [label]=\"labels.editionDialog.validate\"\n            icon=\"pi pi-check\"\n            [disabled]=\"isLoading() || invalidForm\"\n            (click)=\"onSave()\"\n          />\n        }\n      </div>\n\n    </div>\n  </ng-template>\n</p-dialog>", styles: ["crd-edition-dialog .content-container{min-height:300px}crd-edition-dialog .content-container .accordion{padding:0 1rem;margin:.5rem 0;display:block}crd-edition-dialog .content-container .accordion .flex-row{display:flex}crd-edition-dialog .content-container .accordion .flex-row .delete-button{width:auto;margin-left:auto}crd-edition-dialog .content-container .accordion.deletion-container .p-accordion-header:hover .p-accordion-header-link,crd-edition-dialog .content-container .accordion.deletion-container .p-accordion-header .p-accordion-header-link{background-color:var(--p-orange-500);color:#fff}crd-edition-dialog .error{color:red}\n"], dependencies: [{ kind: "ngmodule", type: DialogModule }, { kind: "component", type: i1$e.Dialog, selector: "p-dialog", inputs: ["hostName", "header", "draggable", "resizable", "contentStyle", "contentStyleClass", "modal", "closeOnEscape", "dismissableMask", "rtl", "closable", "breakpoints", "styleClass", "maskStyleClass", "maskStyle", "showHeader", "blockScroll", "autoZIndex", "baseZIndex", "minX", "minY", "focusOnShow", "maximizable", "keepInViewport", "focusTrap", "transitionOptions", "maskMotionOptions", "motionOptions", "closeIcon", "closeAriaLabel", "closeTabindex", "minimizeIcon", "maximizeIcon", "closeButtonProps", "maximizeButtonProps", "visible", "style", "position", "role", "appendTo", "content", "contentTemplate", "footerTemplate", "closeIconTemplate", "maximizeIconTemplate", "minimizeIconTemplate", "headlessTemplate"], outputs: ["onShow", "onHide", "visibleChange", "onResizeInit", "onResizeEnd", "onDragEnd", "onMaximize"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: SharedModule }, { kind: "component", type: FormComponent, selector: "frm-form", inputs: ["columnsCount", "config", "forceReload", "forceReloadValues", "groupValidator", "isReadonly", "labelStrategy", "labelStrategyVariant", "model", "resetButtonLabel", "showDebug", "showReset", "showSubmit", "submitButtonLabel"], outputs: ["configChange", "modelChange", "fieldInteraction", "reset", "submitted", "validityChange"] }, { kind: "ngmodule", type: CardModule }, { kind: "component", type: i3$2.Card, selector: "p-card", inputs: ["header", "subheader", "style", "styleClass"] }, { kind: "component", type: HistoryComponent, selector: "crd-history", inputs: ["data", "config", "showOldValue"], outputs: ["selected"] }, { kind: "ngmodule", type: CheckboxModule }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: CrudButtonComponent, selector: "crd-crud-button", inputs: ["type", "disabled", "loading", "label", "icon", "severity"], outputs: ["clicked"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: EditionDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: "crd-edition-dialog", imports: [
                        DialogModule,
                        SharedModule,
                        FormComponent,
                        CardModule,
                        HistoryComponent,
                        CheckboxModule,
                        FormsModule,
                        ButtonModule,
                        AsyncPipe,
                        CrudButtonComponent,
                    ], encapsulation: ViewEncapsulation.None, template: "<p-dialog\n  [visible]=\"isVisible()\"\n  [style]=\"{width: calculatedWidth(), height: height()}\"\n  [header]=\"dialogTitle()\"\n  [modal]=\"true\"\n  [maximizable]=\"true\"\n  styleClass=\"p-fluid\"\n  (visibleChange)=\"$event ? false : onHide()\"\n  (onHide)=\"onHide()\"\n  appendTo=\"body\">\n\n  <ng-template pTemplate=\"content\">\n    <div class=\"content-container\">\n      <frm-form\n        [config]=\"config()\"\n        [model]=\"editedEntry()\"\n        [groupValidator]=\"groupValidator()\"\n        [isReadonly]=\"isReadonly()\"\n        [forceReload]=\"forceReloadTime()\"\n        [columnsCount]=\"formColumnsCount()\"\n        [labelStrategy]=\"labelStrategy()\"\n        [labelStrategyVariant]=\"labelStrategyVariant()\"\n        (modelChange)=\"onFormChanged($event)\"\n        (validityChange)=\"onValidityChange($event)\"\n      />\n\n      @if (features().getHistory && !!getHistory()) {\n        @let historyData = history$ | async;\n        @if (historyData) {\n          <p-card>\n            <ng-template #header>\n              <span>\n                {{ labels.editionDialog.historyHeader }} ({{ historyData.total ?? historyData.rows.length }})\n              </span>\n              <!-- <span class=\"history-header-toggle\">\n                <p-checkbox [(ngModel)]=\"showOldValue\" [binary]=\"true\" inputId=\"showOldValue\" />\n                <label for=\"showOldValue\">{{ labels.history.showPreviousValue }}</label>\n              </span> -->\n            </ng-template>\n            <crd-history\n              [data]=\"historyData\"\n              [config]=\"config()\"\n              [showOldValue]=\"showOldValue()\"\n              (selected)=\"onHistorySelect($event)\"\n            />\n          </p-card>\n        }\n      }\n    </div>\n  </ng-template>\n\n  <ng-template pTemplate=\"footer\">\n    <div class=\"dialog-actions-container\">\n      <div class=\"left-actions\">\n        <crd-crud-button\n          type=\"cancel\"\n          [label]=\"closeButtonLabel()\"\n          icon=\"pi pi-times\"\n          [disabled]=\"isLoading()\"\n          (click)=\"onHide()\"\n        />\n        @if (isArchiveBtnDisplayed()) {\n          <crd-crud-button\n            type=\"delete\"\n            [label]=\"labels.editionDialog.archive\"\n            icon=\"pi pi-trash\"\n            [disabled]=\"isLoading()\"\n            (click)=\"onArchive()\"\n          />\n        }\n        @if (isRestoreBtnDisplayed()) {\n          <crd-crud-button\n            type=\"restore\"\n            icon=\"pi pi-bolt\"\n            [disabled]=\"isLoading()\"\n            (click)=\"onRestore()\"\n          />\n        }\n      </div>\n\n      <div class=\"right-actions\">\n        @if (canInteract()) {\n          <crd-crud-button\n            type=\"validate\"\n            [label]=\"labels.editionDialog.validate\"\n            icon=\"pi pi-check\"\n            [disabled]=\"isLoading() || invalidForm\"\n            (click)=\"onSave()\"\n          />\n        }\n      </div>\n\n    </div>\n  </ng-template>\n</p-dialog>", styles: ["crd-edition-dialog .content-container{min-height:300px}crd-edition-dialog .content-container .accordion{padding:0 1rem;margin:.5rem 0;display:block}crd-edition-dialog .content-container .accordion .flex-row{display:flex}crd-edition-dialog .content-container .accordion .flex-row .delete-button{width:auto;margin-left:auto}crd-edition-dialog .content-container .accordion.deletion-container .p-accordion-header:hover .p-accordion-header-link,crd-edition-dialog .content-container .accordion.deletion-container .p-accordion-header .p-accordion-header-link{background-color:var(--p-orange-500);color:#fff}crd-edition-dialog .error{color:red}\n"] }]
        }], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: false }] }], features: [{ type: i0.Input, args: [{ isSignal: true, alias: "features", required: false }] }], getHistory: [{ type: i0.Input, args: [{ isSignal: true, alias: "getHistory", required: false }] }], historyMapper: [{ type: i0.Input, args: [{ isSignal: true, alias: "historyMapper", required: false }] }], groupValidator: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupValidator", required: false }] }], customHeader: [{ type: i0.Input, args: [{ isSignal: true, alias: "customHeader", required: false }] }], entityLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "entityLabel", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], isCreation: [{ type: i0.Input, args: [{ isSignal: true, alias: "isCreation", required: false }] }], isReadonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "isReadonly", required: false }] }], isVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "isVisible", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], isLoading: [{ type: i0.Input, args: [{ isSignal: true, alias: "isLoading", required: false }] }], labelStrategy: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategy", required: false }] }], labelStrategyVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategyVariant", required: false }] }], editedEntry: [{ type: i0.Input, args: [{ isSignal: true, alias: "editedEntry", required: true }] }, { type: i0.Output, args: ["editedEntryChange"] }], archived: [{ type: i0.Output, args: ["archived"] }], restored: [{ type: i0.Output, args: ["restored"] }], edited: [{ type: i0.Output, args: ["edited"] }], formChanged: [{ type: i0.Output, args: ["formChanged"] }], hide: [{ type: i0.Output, args: ["hide"] }], saved: [{ type: i0.Output, args: ["saved"] }], validityChanged: [{ type: i0.Output, args: ["validityChanged"] }] } });

class ArchiveInfo {
    updatedAt = null;
    updaterId = null;
    updaterName = null;
    createdAt = null;
    creatorId = null;
    creatorName = null;
    archived = false;
    archivedAt = null;
}
function createArchivedConfig(labels = DEFAULT_CRUD_LABELS.archivedConfig) {
    return [
        {
            key: "archived",
            controlType: CONTROL_TYPES.CHECKBOX,
            label: labels.label,
            columnOptions: {
                isSoftHidden: true,
                customCellRenderer: (cellValue) => {
                    return cellValue
                        ? `<span class="red">${labels.archived}</span>`
                        : `<span class="green">${labels.active}</span>`;
                },
                tooltip: (cellValue) => {
                    return cellValue ? labels.archived : labels.active;
                },
            },
            controlOptions: {
                hidden: true,
            },
        },
        {
            key: "archivedAt",
            controlType: CONTROL_TYPES.DATE,
            label: labels.labelAt,
            columnOptions: {
                isSoftHidden: true,
            },
            controlOptions: {
                hidden: true,
            },
        },
    ];
}
/** @deprecated Use createArchivedConfig() instead */
const ARCHIVED_CONFIG = createArchivedConfig();

function createAuditConfig(labels = DEFAULT_CRUD_LABELS.auditConfig) {
    return [
        {
            key: "createdAt",
            label: labels.createdAt,
            controlType: CONTROL_TYPES.INPUT,
            type: INPUT_TYPES.TEXT,
            controlOptions: { hidden: true },
            columnOptions: { isSoftHidden: true },
        },
        {
            key: "creatorName",
            label: labels.createdBy,
            controlType: CONTROL_TYPES.INPUT,
            type: INPUT_TYPES.TEXT,
            controlOptions: { hidden: true },
            columnOptions: { isSoftHidden: true },
        },
        {
            key: "updatedAt",
            label: labels.updatedAt,
            controlType: CONTROL_TYPES.INPUT,
            type: INPUT_TYPES.TEXT,
            controlOptions: { hidden: true },
            columnOptions: { isSoftHidden: true },
        },
        {
            key: "updaterName",
            label: labels.updatedBy,
            controlType: CONTROL_TYPES.INPUT,
            type: INPUT_TYPES.TEXT,
            controlOptions: { hidden: true },
            columnOptions: { isSoftHidden: true },
        },
    ];
}

class IdInfo {
    id = null;
}
const ID_CONFIG = {
    key: "id",
    controlType: CONTROL_TYPES.INPUT,
    type: INPUT_TYPES.TEXT,
    label: "ID",
    columnOptions: {
        isHardHidden: true,
    },
    controlOptions: {
        hidden: true,
        disabled: true,
    },
};

/**
 * Injection token for the ACL adapter.
 * The default implementation grants all permissions (open access).
 *
 * @example — provide your own implementation in app.config.ts:
 * providers: [
 *   { provide: ACL_ADAPTER, useExisting: AclService }
 * ]
 */
const ACL_ADAPTER = new InjectionToken("ACL_ADAPTER", {
    factory: () => ({
        permissionsFor: () => ({
            canCreate: true,
            canUpdate: true,
            canArchive: true,
            canRestore: true,
        }),
    }),
});

/**
 * Generic helper class to build entity configuration with resolved route data
 */
class ConfigHelper {
    route = inject(ActivatedRoute);
    /**
     * Get the entity configuration with resolved data from the activated route
     * @param service The service instance that provides the config method
     */
    getConfig(service) {
        return service.config(this.route.snapshot);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ConfigHelper, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ConfigHelper });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ConfigHelper, decorators: [{
            type: Injectable
        }] });

class CrudRepository {
    http = inject(HttpClient);
    apiPrefix = inject(APP_CONFIG).apiPrefix;
    /* Initialized in with() */
    apiUrl = "";
    fileOperationsConfig = {};
    _all$ = null;
    /** Configure the repository with an endpoint and return CRUD operations */
    with(config) {
        const { endpoint, fileOperationsConfig } = config;
        this.apiUrl = `${this.apiPrefix}${endpoint}`;
        this.fileOperationsConfig = fileOperationsConfig ?? {};
        return this.operations();
    }
    operations = () => ({
        get: (e) => this.get(e),
        getById: (id) => this.getById(id),
        getAll: () => this.get({}),
        getAndCacheAll: () => this.getAllAndCache(),
        create: (item) => this.create(item).pipe(tap(() => this.invalidateCache())),
        update: (item) => this.update(item).pipe(tap(() => this.invalidateCache())),
        archive: (ids) => this.archive(ids).pipe(tap(() => this.invalidateCache())),
        restore: (ids) => this.restore(ids).pipe(tap(() => this.invalidateCache())),
        getHistory: (id) => this.getHistory(id),
        updateFiles: (files, id) => this.updateFiles(files, id),
    });
    /**
     * Search for entities in the database, and return the result as an
     * observable of RowsAndCount.
     *
     * @param e The TableLazyLoadEvent to send to the server. If null, returns
     *          NO_ROWS_AND_COUNT.
     * @returns An observable of RowsAndCount<T>
     */
    get(e) {
        if (!e) {
            return of(NO_ROWS_AND_COUNT);
        }
        return this.http
            .post(`${this.apiUrl}/search`, e)
            .pipe(catchError(() => of(NO_ROWS_AND_COUNT)));
    }
    /**
     * Retrieve a single entity by its ID.
     *
     * @param itemId The ID of the item to retrieve.
     * @returns An observable of RowsAndCount<T>, containing a single item.
     */
    getById(itemId) {
        const filter = {
            filters: {
                id: { value: itemId, matchMode: "equals" },
            },
        };
        return this.get(filter);
    }
    /**
     * Create a single entity in the database.
     *
     * @param item The entity to create.
     * @returns An observable of Rows<T>, containing a single item.
     */
    create(item) {
        const data = this.fileOperationsConfig?.serializer
            ? this.fileOperationsConfig.serializer(item)
            : { rows: [item] };
        return this.http.post(this.apiUrl, data);
    }
    /**
     * Update a single entity in the database.
     *
     * @param item The entity to update.
     * @returns An observable of Rows<T>, containing a single item.
     */
    update(item) {
        const data = this.fileOperationsConfig?.serializer
            ? this.fileOperationsConfig.serializer(item)
            : { rows: [item] };
        return this.http.put(this.apiUrl, data);
    }
    /**
     * Archive a list of items in the database.
     *
     * @param itemId The IDs of the items to archive.
     * @returns An observable of null.
     */
    archive(itemIds) {
        return this.http.post(`${this.apiUrl}/archive`, {
            rows: itemIds,
        });
    }
    restore(ids) {
        return this.http.post(`${this.apiUrl}/restore`, { rows: ids });
    }
    getAllAndCache() {
        if (!this._all$) {
            this._all$ = this.get({}).pipe(map((res) => res.rows ?? []), shareReplay(1));
        }
        return this._all$;
    }
    invalidateCache() {
        this._all$ = null;
    }
    getHistory(id) {
        return this.http.get(`${this.apiUrl}/${id}/history`);
    }
    // TODO: test again when backend works again (events & user)
    // Or maybe move to documents service way? (all form values converted to form data)
    updateFiles(media, id, formDataKey = "pictures", suffix = "pictures") {
        const formData = new FormData();
        const files = isArray(media) ? media : [media];
        for (const file of files) {
            formData.append(formDataKey, file);
        }
        return this.http
            .post(`${this.apiUrl}/${id}/${suffix}`, formData)
            .pipe(catchError(() => {
            return of(NO_ROWS);
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CrudRepository, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CrudRepository, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: CrudRepository, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

/**
 * Filters a Calls object based on a permissions object.
 * Read operations (get, getById, getAll, getHistory...) are always preserved.
 * Designed to be used inside a `computed()` for signal-based reactivity.
 *
 * @example
 * public readonly httpCalls = computed(() =>
 *   filterCalls(this.service.httpCalls, {
 *     canCreate: this.acls.canWrite(),
 *     canUpdate: this.acls.canWrite(),
 *     canArchive: this.acls.canDelete(),
 *   })
 * );
 */
function filterCalls(calls, permissions) {
    return {
        ...calls,
        create: permissions.canCreate !== false ? calls.create : undefined,
        update: permissions.canUpdate !== false ? calls.update : undefined,
        archive: permissions.canArchive !== false ? calls.archive : undefined,
        restore: permissions.canRestore !== false ? calls.restore : undefined,
    };
}

class DocumentFormDataMapper {
    toFormData(formValues, fileProperties) {
        const formData = new FormData();
        for (const itemKey in formValues) {
            const key = itemKey;
            const value = formValues[key];
            // Check if file property
            if (fileProperties.includes(key)) {
                if (isNil(value)) {
                    continue;
                }
                const files = isArray(value) ? value : [value];
                for (const file of files) {
                    if (file instanceof File) {
                        formData.append(key, file, file.name);
                    }
                }
            }
            else {
                // Other property types
                formData.append(key, this.stringify(value));
            }
        }
        return formData;
    }
    stringify(value) {
        if (isNil(value)) {
            return "";
        }
        if (isDate(value)) {
            return new Date(value).toISOString();
        }
        return value.toString();
    }
}

class OfflineService {
    _isOnline = signal(true, ...(ngDevMode ? [{ debugName: "_isOnline" }] : /* istanbul ignore next */ []));
    get isOnline() {
        return this._isOnline.asReadonly();
    }
    constructor() {
        window.addEventListener("online", () => this.updateOnlineStatus());
        window.addEventListener("offline", () => this.updateOnlineStatus());
    }
    updateOnlineStatus() {
        console.log("updateOnlineStatus", window.navigator.onLine);
        this._isOnline.set(window.navigator.onLine);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: OfflineService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: OfflineService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: OfflineService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root",
                }]
        }], ctorParameters: () => [] });

const FILTER_LEVELS = {
    BASIC: "basic",
    INTERMEDIATE: "intermediate",
    ADVANCED: "advanced",
};

function EmailValidator(control) {
    const email = control.value || "";
    if (!email) {
        return null;
    }
    return isEmail(email) ? null : { emailInvalid: "Email invalide" };
}

const INIT_COORDINATES = {
    location: [0, 0],
    street: "",
    zipCode: "",
    city: "",
    label: "",
};
const LOCATION_CONFIG = [
    {
        key: "street",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Adresse",
        columnOptions: {},
        controlOptions: {
            validators: [required, minlength(4)],
            minLength: 4,
            // searchOptionsFn: (query: string) =>
            //   this.geoService.search(query, "housenumber").pipe(
            //     map((payload) => {
            //       return (payload.rows || []).map((res) => ({
            //         value: res.street,
            //         label: res.street,
            //         extraData: res,
            //         displayValue: res.label,
            //       }));
            //     }),
            //   ),
            // onSelect: (event: AutocompleteItem) => {
            //   return [
            //     {
            //       ctrl: "city",
            //       value: event.extraData.city,
            //     },
            //     {
            //       ctrl: "zipCode",
            //       value: event.extraData.zipCode,
            //     },
            //     {
            //       ctrl: "location",
            //       value: event.extraData.location,
            //     },
            //   ];
            // },
        },
    },
    {
        key: "zipCode",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Code postal",
        columnOptions: {},
        controlOptions: {
            validators: [required, minlength(5), maxlength(5)],
            minLength: 5,
            maxLength: 5,
            // searchOptionsFn: (query: string) =>
            //   this.geoService.search(query).pipe(
            //     map((payload) => {
            //       return (payload.rows || []).map((res) => ({
            //         value: res.zipCode,
            //         label: res.zipCode,
            //         extraData: res,
            //         displayValue: `${res.city} (${res.zipCode})`,
            //       }));
            //     }),
            //   ),
            // onSelect: (event: AutocompleteItem) => {
            //   return [
            //     { ctrl: "city", value: event.extraData.city },
            //     {
            //       ctrl: "location",
            //       value: event.extraData.location,
            //     },
            //   ];
            // },
        },
    },
    {
        key: "city",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Ville",
        columnOptions: {},
        controlOptions: {
            validators: [required],
            // searchOptionsFn: (query: string) =>
            //   this.geoService.search(query).pipe(
            //     map((payload) => {
            //       return (payload.rows || []).map((res) => ({
            //         value: res.city,
            //         label: res.city,
            //         extraData: res,
            //         displayValue: `${res.city} (${res.zipCode})`,
            //       }));
            //     }),
            //   ),
            // onSelect: (event: AutocompleteItem) => {
            //   return [
            //     { ctrl: "zipCode", value: event.extraData.zipCode },
            //     {
            //       ctrl: "location",
            //       value: event.extraData.location,
            //     },
            //   ];
            // },
        },
    },
    // {
    //   key: "location",
    //   label: "Lng/Lat",
    //   controlType: CONTROL_TYPES.MAP,
    //   columnOptions: {
    //     isHardHidden: true,
    //   },
    //   controlOptions: {
    //     // validators: [Validators.required],
    //     hidden: true,
    //     minWidth: "100%",
    //     // hidden: true,
    //   },
    // },
];

function patternValidator(config) {
    const patternValidator = Validators.pattern(config.pattern);
    return (control) => {
        const validationResult = patternValidator(control);
        if (validationResult) {
            return { pattern: { expected: config.message } };
        }
        return null;
    };
}

/** ALPHABETICAL */
const alphabeticalCaracters = "a-zA-Zàâçéèêëîïôûùüÿñæœ'";
const nameWithDashes = (message = "") => ({
    pattern: `^[${alphabeticalCaracters} —-]+$`,
    message,
});
const lettersWithSpaces = (message = "") => ({
    pattern: `^[${alphabeticalCaracters} ]+$`,
    message,
});
const lettersWithoutSpaces = (message = "") => ({
    pattern: `^[${alphabeticalCaracters}]+$`,
    message,
});
/** ALPHANUMERICAL */
const alphanumericalWithSpaces = (message = "") => ({
    pattern: /^[\p{L}0-9 ]+$/u,
    message,
});
const alphanumericalWithoutSpaces = (message = "") => ({
    pattern: /^[\p{L}0-9]+$/u,
    message,
});
const onlyCaps = (message = "") => ({
    pattern: /^[A-Z0-9]+$/,
    message,
});
/** NUMERICAL */
const integer = (message = "") => ({
    pattern: /^[0-9]+$/,
    message,
});
/** OTHERS */
const phoneNumber = (message = "") => ({
    pattern: /^\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/,
    message,
});
const withExtension = (message = "") => ({
    pattern: /[^\\]*\.(\w+)$/,
    message,
});

const INIT_SOCIALS = {
    website: "",
    video: "",
    instagram: "",
    facebook: "",
    x: "",
    linkedin: "",
};
const SOCIALS_CONFIG = [
    {
        key: "website",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Site web",
        controlOptions: {
            inputIcon: "pi pi-globe",
        },
        columnOptions: {
            isSoftHidden: true,
        },
    },
    {
        key: "video",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Lien vidéo",
        controlOptions: {
            inputIcon: "pi pi-youtube",
        },
        columnOptions: {
            isSoftHidden: true,
        },
    },
    {
        key: "instagram",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Lien Instagram",
        controlOptions: {
            inputIcon: "pi pi-instagram",
        },
        columnOptions: {
            isSoftHidden: true,
        },
    },
    {
        key: "facebook",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Lien Facebook",
        controlOptions: {
            inputIcon: "pi pi-facebook",
        },
        columnOptions: {
            isSoftHidden: true,
        },
    },
    {
        key: "x",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Lien X",
        controlOptions: {
            inputIcon: "pi pi-twitter",
        },
        columnOptions: {
            isSoftHidden: true,
        },
    },
    {
        key: "linkedin",
        controlType: CONTROL_TYPES.INPUT,
        type: INPUT_TYPES.TEXT,
        label: "Lien Linkedin",
        controlOptions: {
            inputIcon: "pi pi-linkedin",
        },
        columnOptions: {
            isSoftHidden: true,
        },
    },
];

class TableConfig {
    id = null;
    name = "";
    component = "";
    conf = [];
    isActive = false;
    locked = false;
    constructor(component, name = "Default") {
        this.component = component;
        this.name = name;
        this.isActive = true;
    }
}

class TableConfigService {
    api = `${inject(APP_CONFIG).apiPrefix}preferences`;
    http = inject(HttpClient);
    getViews(componentId) {
        return this.http
            .get(`${this.api}/${componentId}`)
            .pipe(map((res) => res.rows), catchError(() => of([])));
    }
    updateMany(componentId, views) {
        return this.http.put(`${this.api}/${componentId}`, {
            rows: views,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableConfigService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableConfigService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableConfigService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

/**
 * This class is used to store and consume a location intercepted by the location interceptor
 */
class LocationInterceptorService {
    _waitingForLocationHeader = signal(false, ...(ngDevMode ? [{ debugName: "_waitingForLocationHeader" }] : /* istanbul ignore next */ []));
    //The location header intercepted by the location interceptor
    locationHeader;
    //Indicates if the interceptor is currently waiting for a location header
    waitingForLocationHeader = this._waitingForLocationHeader.asReadonly();
    /**
     * Consume the location header stored in this service. This will clear the stored location.
     * It also clear the waiting flag
     * @returns The stored location header, or undefined if there is none.
     */
    consumeLocation() {
        this._waitingForLocationHeader.set(false);
        const location = this.locationHeader;
        this.locationHeader = undefined;
        return location;
    }
    /**
     * Indicates that the location interceptor should wait for a location header
     * to be received in the next response.
     */
    enableLocationHeaderWaiting() {
        this._waitingForLocationHeader.set(true);
    }
    /**
     * Store the location header intercepted by the location interceptor. This will clear
     * the waiting flag.
     * @param location The location header to store.
     */
    setLocation(location) {
        this.locationHeader = location;
        this._waitingForLocationHeader.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocationInterceptorService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocationInterceptorService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocationInterceptorService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

class TableLoadingService {
    _isLoading = signal(false, ...(ngDevMode ? [{ debugName: "_isLoading" }] : /* istanbul ignore next */ []));
    isLoading = this._isLoading.asReadonly();
    start() {
        this._isLoading.set(true);
    }
    stop() {
        this._isLoading.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableLoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableLoadingService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableLoadingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root",
                }]
        }] });

const CACHEABLE_KEY = "Is-Cacheable";
const CACHEABLE_PROP = { [CACHEABLE_KEY]: "1" };
const isCacheable = (req) => req.headers.get(CACHEABLE_KEY) === CACHEABLE_PROP[CACHEABLE_KEY];
const hasCacheable = (obj) => Object.hasOwn(obj, CACHEABLE_KEY);
const CACHEABLE_HEADER = {
    headers: CACHEABLE_PROP,
};

class TableStateService {
    currentTime = signal(Date.now(), ...(ngDevMode ? [{ debugName: "currentTime" }] : /* istanbul ignore next */ []));
    currentParams = signal(undefined, ...(ngDevMode ? [{ debugName: "currentParams" }] : /* istanbul ignore next */ []));
    data = signal([], ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    entityLabel = signal("", ...(ngDevMode ? [{ debugName: "entityLabel" }] : /* istanbul ignore next */ []));
    excelExportMode = signal("server", ...(ngDevMode ? [{ debugName: "excelExportMode" }] : /* istanbul ignore next */ []));
    lazy = signal(true, ...(ngDevMode ? [{ debugName: "lazy" }] : /* istanbul ignore next */ []));
    total = signal(0, ...(ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []));
    fileName = computed(() => `${this.entityLabel().toLowerCase()}_${this.currentTime()}`, ...(ngDevMode ? [{ debugName: "fileName" }] : /* istanbul ignore next */ []));
    state = computed(() => {
        return {
            currentTime: this.currentTime(),
            currentParams: this.currentParams(),
            data: this.data(),
            entityLabel: this.entityLabel(),
            excelExportMode: this.excelExportMode(),
            fileName: this.fileName(),
            lazy: this.lazy(),
            total: this.total(),
        };
    }, ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    setStaticInformation(payload) {
        this.lazy.set(payload.lazy);
        this.entityLabel.set(payload.entityLabel);
        this.excelExportMode.set(payload.excelExportMode);
    }
    setCurrentTime() {
        this.currentTime.set(Date.now());
    }
    setParams(params) {
        this.currentParams.set(params);
    }
    setData(res) {
        this.total.set(res.total);
        this.data.set(res.rows);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableStateService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableStateService, decorators: [{
            type: Injectable
        }] });

class CrudFeatures {
    create = false;
    update = false;
    archive = false;
    getHistory = false;
    updateFiles = false;
    restore = false;
}
// TODO: rename to CrudTableLoader // rename file accordingly
class CrudLoader {
    loadingService = inject(TableLoadingService);
    state = inject(TableStateService);
    _features = signal(new CrudFeatures(), ...(ngDevMode ? [{ debugName: "_features" }] : /* istanbul ignore next */ []));
    features = this._features.asReadonly();
    params = computed(() => this.state.state().currentParams, ...(ngDevMode ? [{ debugName: "params" }] : /* istanbul ignore next */ []));
    httpCalls;
    _forceCloseEdition = signal(null, ...(ngDevMode ? [{ debugName: "_forceCloseEdition" }] : /* istanbul ignore next */ []));
    forceCloseEdition = this._forceCloseEdition.asReadonly();
    _config = signal([], ...(ngDevMode ? [{ debugName: "_config" }] : /* istanbul ignore next */ []));
    get getCall() {
        return this.httpCalls.get ?? (() => of(NO_ROWS_AND_COUNT));
    }
    set(httpCalls) {
        this.httpCalls = httpCalls;
    }
    storeConfig(config) {
        this._config.set(config);
    }
    enableFeatures() {
        const features = new CrudFeatures();
        for (const feature in this.httpCalls) {
            features[feature] =
                !!this.httpCalls[feature];
        }
        this._features.set(features);
    }
    load(event = {
        partial: "false",
    }) {
        let params;
        if (event.partial === "false") {
            params = event.params ?? this.params();
        }
        else {
            params = { ...this.params(), ...event.params };
        }
        this.state.setParams(params);
        this.get().subscribe();
    }
    create(args) {
        if (!this.httpCalls.create) {
            return of(null);
        }
        this.loadingService.start();
        return this.httpCalls.create(args).pipe(tap(() => this.loadingService.stop()), this.handleLocalData((res) => ({
            value: res?.rows?.[0] ?? { ...args, id: Date.now() },
            feature: "create",
        })), catchError((err) => {
            this.loadingService.stop();
            return throwError(() => err);
        }));
    }
    update(args) {
        if (!this.httpCalls.update) {
            return of(null);
        }
        this.loadingService.start();
        return this.httpCalls.update(args).pipe(tap(() => this.loadingService.stop()), this.handleLocalData({ value: args, feature: "update" }), catchError((err) => {
            this.loadingService.stop();
            return throwError(() => err);
        }));
    }
    archive(args) {
        if (!this.httpCalls.archive) {
            return of(null);
        }
        this.loadingService.start();
        return this.httpCalls.archive(args).pipe(tap(() => this.loadingService.stop()), this.handleLocalData({ value: args, feature: "archive" }), catchError((err) => {
            this.loadingService.stop();
            return throwError(() => err);
        }));
    }
    restore(args) {
        if (!this.httpCalls.restore) {
            return of(null);
        }
        this.loadingService.start();
        return this.httpCalls.restore(args).pipe(tap(() => this.loadingService.stop()), this.handleLocalData({ value: args, feature: "restore" }), catchError((err) => {
            this.loadingService.stop();
            return throwError(() => err);
        }));
    }
    get() {
        let params = this.params();
        if (!params) {
            params = {};
        }
        this.loadingService.start();
        if (!this.getCall) {
            this.loadingService.stop();
            return of(NO_ROWS_AND_COUNT);
        }
        return this.getCall(params).pipe(delay(0), map((res) => {
            // Special treatment when an item has 'filesResolver' property
            const itemsWithFileResolver = this._config().filter((c) => c.filesPathResolver && c.controlType === "files");
            if (itemsWithFileResolver.length) {
                return this.assignFilePaths(res, itemsWithFileResolver);
            }
            // Otherwise return as is
            return res;
        }), tap((res) => {
            this.state.setData(res);
            this.loadingService.stop();
        }), catchError(() => {
            this.loadingService.stop();
            return of(NO_ROWS_AND_COUNT);
        }));
    }
    assignFilePaths(initialRes, itemsWithFileResolver) {
        return {
            total: initialRes.total,
            rows: initialRes.rows.map((row) => {
                const newRow = { ...row };
                for (const item of itemsWithFileResolver) {
                    const filesInfo = item.filesPathResolver?.(row);
                    // Must not override existing value if already provided by backend
                    const hasProperty = Object.hasOwn(newRow, item.key);
                    const hasValue = hasProperty && !!newRow[item.key];
                    if (filesInfo && !hasValue) {
                        newRow[item.key] = filesInfo;
                    }
                }
                return newRow;
            }),
        };
    }
    updateFiles(files, id) {
        const updateFiles = this.httpCalls.updateFiles;
        const canUpdateFiles = id && this.features().updateFiles && updateFiles && files?.length;
        if (canUpdateFiles) {
            return updateFiles(files, id);
        }
        return of(true);
    }
    updateLocalRows(payload) {
        let rows = this.state.state().data;
        let total = this.state.state().total;
        const { value, feature } = payload;
        switch (feature) {
            case "update": {
                rows = rows.map((r) => {
                    if (r.id === value.id) {
                        return value;
                    }
                    return r;
                });
                break;
            }
            case "create": {
                rows = [value, ...rows];
                total = total + 1;
                break;
            }
            case "archive": {
                rows = rows.filter((r) => {
                    const isFound = value.some((val) => val === r.id);
                    if (isFound) {
                        total = total - 1;
                    }
                    return !isFound;
                });
                break;
            }
            case "restore": {
                rows = rows.map((r) => {
                    const isFound = value.some((val) => val === r.id);
                    if (isFound) {
                        total = total + 1;
                        return { ...r, archived: false };
                    }
                    return r;
                });
                break;
            }
        }
        this.state.setData({ rows, total });
    }
    handleLocalData(payload) {
        const resolvePayload = (res) => typeof payload === "function" ? payload(res) : payload;
        return (source) => {
            return source.pipe(tap((res) => {
                this.updateLocalRows(resolvePayload(res));
            }), catchError((err) => {
                const isOfflineError = err.status === 0;
                const isCacheable = hasCacheable(err);
                if (isOfflineError && isCacheable) {
                    this.updateLocalRows(resolvePayload(err));
                    this._forceCloseEdition.set(Date.now());
                }
                return throwError(() => err);
            }));
        };
    }
}

class ColumnsManagementComponent {
    activeView = input.required(...(ngDevMode ? [{ debugName: "activeView" }] : /* istanbul ignore next */ []));
    isViewCreation = input.required(...(ngDevMode ? [{ debugName: "isViewCreation" }] : /* istanbul ignore next */ []));
    isPreferencesModeEnabled = input.required(...(ngDevMode ? [{ debugName: "isPreferencesModeEnabled" }] : /* istanbul ignore next */ []));
    columnsReordered = output();
    selectedColumnsKeysChange = output();
    selectedColumnsKeys = linkedSignal(() => this.activeView()
        .columns.filter((col) => col.isVisible)
        .map((col) => col.key), ...(ngDevMode ? [{ debugName: "selectedColumnsKeys" }] : /* istanbul ignore next */ []));
    isColumnsEditionDisabled = computed(() => {
        // If preferences mode is not enabled, we can edit the front-end default view
        if (!this.isPreferencesModeEnabled()) {
            return false;
        }
        // If we are creating a new view, we cannot edit columns
        if (this.isViewCreation()) {
            return false;
        }
        // Otherwise, we can edit columns only if the active view is not locked
        return this.activeView().locked;
    }, ...(ngDevMode ? [{ debugName: "isColumnsEditionDisabled" }] : /* istanbul ignore next */ []));
    isOptionDisabled(col) {
        return col.isHardHidden === true;
    }
    onChange() {
        this.selectedColumnsKeysChange.emit(this.selectedColumnsKeys());
    }
    onDrop(event) {
        this.columnsReordered.emit(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ColumnsManagementComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.7", type: ColumnsManagementComponent, isStandalone: true, selector: "tbl-columns-management", inputs: { activeView: { classPropertyName: "activeView", publicName: "activeView", isSignal: true, isRequired: true, transformFunction: null }, isViewCreation: { classPropertyName: "isViewCreation", publicName: "isViewCreation", isSignal: true, isRequired: true, transformFunction: null }, isPreferencesModeEnabled: { classPropertyName: "isPreferencesModeEnabled", publicName: "isPreferencesModeEnabled", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { columnsReordered: "columnsReordered", selectedColumnsKeysChange: "selectedColumnsKeysChange" }, ngImport: i0, template: "<p-listbox \n  class=\"columns-listbox\"\n  [options]=\"activeView().columns\" \n  [(ngModel)]=\"selectedColumnsKeys\" \n  (onChange)=\"onChange()\"\n  (onDrop)=\"onDrop($event)\"\n  optionLabel=\"label\" \n  optionValue=\"key\"\n  [optionDisabled]=\"isOptionDisabled\"\n  [dragdrop]=\"true\" \n  [multiple]=\"true\" \n  [checkbox]=\"true\"\n  [disabled]=\"isColumnsEditionDisabled()\"\n  dataKey=\"key\"\n/>", styles: [".columns-listbox .p-listbox-list-container{max-height:unset!important}.columns-listbox .p-listbox-option.p-disabled{visibility:hidden;height:0;margin:0;padding:0}\n"], dependencies: [{ kind: "ngmodule", type: ListboxModule }, { kind: "component", type: i1$f.Listbox, selector: "p-listbox, p-listBox, p-list-box", inputs: ["hostName", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "ariaLabel", "selectOnFocus", "searchLocale", "focusOnHover", "filterMessage", "filterFields", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "scrollHeight", "tabindex", "multiple", "styleClass", "listStyle", "listStyleClass", "readonly", "checkbox", "filter", "filterBy", "filterMatchMode", "filterLocale", "metaKeySelection", "dataKey", "showToggleAll", "optionLabel", "optionValue", "optionGroupChildren", "optionGroupLabel", "optionDisabled", "ariaFilterLabel", "filterPlaceHolder", "emptyFilterMessage", "emptyMessage", "group", "options", "filterValue", "selectAll", "striped", "highlightOnSelect", "checkmark", "dragdrop", "dropListData", "fluid"], outputs: ["onChange", "onClick", "onDblClick", "onFilter", "onFocus", "onBlur", "onSelectAllChange", "onLazyLoad", "onDrop"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ColumnsManagementComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-columns-management", imports: [ListboxModule, DragDropModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<p-listbox \n  class=\"columns-listbox\"\n  [options]=\"activeView().columns\" \n  [(ngModel)]=\"selectedColumnsKeys\" \n  (onChange)=\"onChange()\"\n  (onDrop)=\"onDrop($event)\"\n  optionLabel=\"label\" \n  optionValue=\"key\"\n  [optionDisabled]=\"isOptionDisabled\"\n  [dragdrop]=\"true\" \n  [multiple]=\"true\" \n  [checkbox]=\"true\"\n  [disabled]=\"isColumnsEditionDisabled()\"\n  dataKey=\"key\"\n/>", styles: [".columns-listbox .p-listbox-list-container{max-height:unset!important}.columns-listbox .p-listbox-option.p-disabled{visibility:hidden;height:0;margin:0;padding:0}\n"] }]
        }], propDecorators: { activeView: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeView", required: true }] }], isViewCreation: [{ type: i0.Input, args: [{ isSignal: true, alias: "isViewCreation", required: true }] }], isPreferencesModeEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isPreferencesModeEnabled", required: true }] }], columnsReordered: [{ type: i0.Output, args: ["columnsReordered"] }], selectedColumnsKeysChange: [{ type: i0.Output, args: ["selectedColumnsKeysChange"] }] } });

class ColumnsViewsComponent {
    confirmationService = inject(ConfirmationService);
    labels = inject(CRUD_LABELS);
    views = input.required(...(ngDevMode ? [{ debugName: "views" }] : /* istanbul ignore next */ []));
    deleteView = output();
    addView = output();
    viewSelected = output();
    viewCreationClicked = output();
    viewCreationDone = output();
    activeViewId = computed(() => {
        return this.views().find((view) => view.isActive)?.id ?? null;
    }, ...(ngDevMode ? [{ debugName: "activeViewId" }] : /* istanbul ignore next */ []));
    isNewFieldDisplayed = false;
    onSelectView(viewId) {
        this.viewSelected.emit(viewId);
    }
    onDeleteView(event, viewId) {
        event.stopPropagation();
        if (!viewId) {
            return;
        }
        this.confirmationService.confirm({
            message: this.labels.columnsViews.deleteConfirmation,
            accept: () => this.deleteView.emit(viewId),
        });
    }
    showNewViewField() {
        this.isNewFieldDisplayed = true;
        this.viewCreationClicked.emit();
    }
    hideNewViewField() {
        this.isNewFieldDisplayed = false;
        this.viewCreationDone.emit();
    }
    submitNewView(name) {
        if (name) {
            this.hideNewViewField();
            this.addView.emit(name);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ColumnsViewsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: ColumnsViewsComponent, isStandalone: true, selector: "tbl-columns-views", inputs: { views: { classPropertyName: "views", publicName: "views", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { deleteView: "deleteView", addView: "addView", viewSelected: "viewSelected", viewCreationClicked: "viewCreationClicked", viewCreationDone: "viewCreationDone" }, ngImport: i0, template: "<div class=\"view-header\">\n  <h3>{{ labels.columnsViews.title }}</h3>\n  <p-button\n    [label]=\"labels.columnsViews.add\"\n    icon=\"pi pi-plus\"\n    [disabled]=\"isNewFieldDisplayed\"\n    (click)=\"showNewViewField()\"\n  />\n</div>\n\n<div class=\"views-container-list\">\n  <p-listbox [options]=\"views()\" \n    optionLabel=\"name\" \n    optionValue=\"id\" \n    [disabled]=\"isNewFieldDisplayed\"\n    [ngModel]=\"activeViewId()\" \n    (onChange)=\"onSelectView($event.value)\">\n    <ng-template #item let-view>      \n        <div class=\"flex-item\">\n            <div>\n              {{ view.name }}\n              @if (view.locked) {\n                <i class=\"pi pi-lock\" style=\"font-size: 0.75rem; margin-left: 0.35rem; opacity: 0.6;\"></i>\n              }\n            </div>\n            @if (!view.locked) {\n              <p-button\n                  icon=\"pi pi-trash\"\n                  [title]=\"labels.columnsViews.delete\"\n                  [text]=\"true\"\n                  (click)=\"onDeleteView($event, view.id)\"\n              />\n            }\n        </div>       \n    </ng-template>\n  </p-listbox>\n    @if (isNewFieldDisplayed) {\n      <div class=\"new-view\">\n        <input #name\n          type=\"text\"\n          pInputText\n          (keyup.enter)=\"submitNewView(name.value)\"\n          autofocus\n        />\n        <p-button\n            class=\"validate-view-button\"\n            icon=\"pi pi-check\"\n            [title]=\"labels.columnsViews.validate\"\n            [text]=\"true\"\n            (click)=\"submitNewView(name.value)\"\n        />\n        <p-button\n            class=\"delete-view-button\"\n            icon=\"pi pi-times\"\n            [title]=\"labels.columnsViews.cancel\"\n            [text]=\"true\"\n            (click)=\"hideNewViewField()\"\n        />\n      </div>\n    }\n  </div>\n", styles: [".view-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem}.views-container-list{display:flex;flex-direction:column}.views-container-list .p-listbox-option{padding:0 5px;height:40px}.views-container-list .flex-item{display:flex;align-items:center;justify-content:space-between;width:100%}.new-view{display:flex;align-items:center;margin-top:1rem}.cancel-new-view{margin-left:auto}.add-view-button{max-width:max-content;margin-top:1rem}\n"], dependencies: [{ kind: "ngmodule", type: RadioButtonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i1.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i1$4.InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "ngmodule", type: ListboxModule }, { kind: "component", type: i1$f.Listbox, selector: "p-listbox, p-listBox, p-list-box", inputs: ["hostName", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "ariaLabel", "selectOnFocus", "searchLocale", "focusOnHover", "filterMessage", "filterFields", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "scrollHeight", "tabindex", "multiple", "styleClass", "listStyle", "listStyleClass", "readonly", "checkbox", "filter", "filterBy", "filterMatchMode", "filterLocale", "metaKeySelection", "dataKey", "showToggleAll", "optionLabel", "optionValue", "optionGroupChildren", "optionGroupLabel", "optionDisabled", "ariaFilterLabel", "filterPlaceHolder", "emptyFilterMessage", "emptyMessage", "group", "options", "filterValue", "selectAll", "striped", "highlightOnSelect", "checkmark", "dragdrop", "dropListData", "fluid"], outputs: ["onChange", "onClick", "onDblClick", "onFilter", "onFocus", "onBlur", "onSelectAllChange", "onLazyLoad", "onDrop"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ColumnsViewsComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-columns-views", imports: [
                        RadioButtonModule,
                        FormsModule,
                        ButtonModule,
                        InputTextModule,
                        ListboxModule,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<div class=\"view-header\">\n  <h3>{{ labels.columnsViews.title }}</h3>\n  <p-button\n    [label]=\"labels.columnsViews.add\"\n    icon=\"pi pi-plus\"\n    [disabled]=\"isNewFieldDisplayed\"\n    (click)=\"showNewViewField()\"\n  />\n</div>\n\n<div class=\"views-container-list\">\n  <p-listbox [options]=\"views()\" \n    optionLabel=\"name\" \n    optionValue=\"id\" \n    [disabled]=\"isNewFieldDisplayed\"\n    [ngModel]=\"activeViewId()\" \n    (onChange)=\"onSelectView($event.value)\">\n    <ng-template #item let-view>      \n        <div class=\"flex-item\">\n            <div>\n              {{ view.name }}\n              @if (view.locked) {\n                <i class=\"pi pi-lock\" style=\"font-size: 0.75rem; margin-left: 0.35rem; opacity: 0.6;\"></i>\n              }\n            </div>\n            @if (!view.locked) {\n              <p-button\n                  icon=\"pi pi-trash\"\n                  [title]=\"labels.columnsViews.delete\"\n                  [text]=\"true\"\n                  (click)=\"onDeleteView($event, view.id)\"\n              />\n            }\n        </div>       \n    </ng-template>\n  </p-listbox>\n    @if (isNewFieldDisplayed) {\n      <div class=\"new-view\">\n        <input #name\n          type=\"text\"\n          pInputText\n          (keyup.enter)=\"submitNewView(name.value)\"\n          autofocus\n        />\n        <p-button\n            class=\"validate-view-button\"\n            icon=\"pi pi-check\"\n            [title]=\"labels.columnsViews.validate\"\n            [text]=\"true\"\n            (click)=\"submitNewView(name.value)\"\n        />\n        <p-button\n            class=\"delete-view-button\"\n            icon=\"pi pi-times\"\n            [title]=\"labels.columnsViews.cancel\"\n            [text]=\"true\"\n            (click)=\"hideNewViewField()\"\n        />\n      </div>\n    }\n  </div>\n", styles: [".view-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem}.views-container-list{display:flex;flex-direction:column}.views-container-list .p-listbox-option{padding:0 5px;height:40px}.views-container-list .flex-item{display:flex;align-items:center;justify-content:space-between;width:100%}.new-view{display:flex;align-items:center;margin-top:1rem}.cancel-new-view{margin-left:auto}.add-view-button{max-width:max-content;margin-top:1rem}\n"] }]
        }], propDecorators: { views: [{ type: i0.Input, args: [{ isSignal: true, alias: "views", required: true }] }], deleteView: [{ type: i0.Output, args: ["deleteView"] }], addView: [{ type: i0.Output, args: ["addView"] }], viewSelected: [{ type: i0.Output, args: ["viewSelected"] }], viewCreationClicked: [{ type: i0.Output, args: ["viewCreationClicked"] }], viewCreationDone: [{ type: i0.Output, args: ["viewCreationDone"] }] } });

class ColumnsManagementDialogComponent {
    labels = inject(CRUD_LABELS);
    views = input.required(...(ngDevMode ? [{ debugName: "views" }] : /* istanbul ignore next */ []));
    isPreferencesModeEnabled = input.required(...(ngDevMode ? [{ debugName: "isPreferencesModeEnabled" }] : /* istanbul ignore next */ []));
    visible = model(false, ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    closed = output();
    saved = output();
    editedViews = linkedSignal(() => this.views(), ...(ngDevMode ? [{ debugName: "editedViews" }] : /* istanbul ignore next */ []));
    activeView = computed(() => this.editedViews().find((view) => view.isActive) ?? this.views()[0], ...(ngDevMode ? [{ debugName: "activeView" }] : /* istanbul ignore next */ []));
    localColumns = linkedSignal(() => this.activeView().columns, ...(ngDevMode ? [{ debugName: "localColumns" }] : /* istanbul ignore next */ []));
    isViewCreation = signal(false, ...(ngDevMode ? [{ debugName: "isViewCreation" }] : /* istanbul ignore next */ []));
    onSelectView(viewId) {
        const view = this.editedViews().find((v) => v.id === viewId);
        if (!view)
            return;
        // Find old active view and update its columns before changing active view
        const oldActiveView = this.activeView();
        this.setColumnsInView(oldActiveView.id, this.localColumns());
        // Set new active view
        this.editedViews.update((views) => views.map((v) => ({ ...v, isActive: v.id === viewId })));
    }
    onSelectedColumnsKeysChange(selectedColumnsKeys) {
        const columns = this.localColumns().map((col) => {
            return { ...col, isVisible: selectedColumnsKeys.includes(col.key) };
        });
        this.localColumns.set(columns);
    }
    onColumnsReordered(event) {
        const columns = [...this.localColumns()];
        moveItemInArray(columns, event.previousIndex, event.currentIndex);
        this.localColumns.set(columns);
    }
    onDeleteView(viewId) {
        const views = this.editedViews().filter((v) => v.id !== viewId);
        if (!views.some((v) => v.isActive) && views.length > 0) {
            views[0].isActive = true;
        }
        this.editedViews.set(views);
    }
    onCreateView(name) {
        const newView = {
            id: Date.now(),
            name,
            isActive: true,
            columns: this.activeView().columns,
            conf: this.activeView().conf,
            component: this.activeView().component,
            locked: false,
            isCreation: true,
        };
        const currentViews = this.editedViews().map((v) => ({
            ...v,
            isActive: false,
        }));
        this.editedViews.update(() => [...currentViews, newView]);
        this.isViewCreation.set(false);
    }
    onSaved() {
        this.setColumnsInView(this.activeView().id, this.localColumns());
        this.saved.emit(this.editedViews());
    }
    onCancel() {
        this.closed.emit();
    }
    setColumnsInView(viewId, columns) {
        const conf = columns.map((col) => ({
            key: col.key,
            isVisible: col.isVisible,
        }));
        this.editedViews.update((views) => {
            return views.map((v) => {
                if (v.id === viewId) {
                    return {
                        ...v,
                        columns,
                        conf,
                    };
                }
                return v;
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ColumnsManagementDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: ColumnsManagementDialogComponent, isStandalone: true, selector: "tbl-columns-management-dialog", inputs: { views: { classPropertyName: "views", publicName: "views", isSignal: true, isRequired: true, transformFunction: null }, isPreferencesModeEnabled: { classPropertyName: "isPreferencesModeEnabled", publicName: "isPreferencesModeEnabled", isSignal: true, isRequired: true, transformFunction: null }, visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { visible: "visibleChange", closed: "closed", saved: "saved" }, ngImport: i0, template: "<p-dialog\n  [(visible)]=\"visible\"\n  [header]=\"labels.columnsDialog.header\"\n  [modal]=\"false\"\n  [focusOnShow]=\"false\"\n  [maximizable]=\"true\"\n  styleClass=\"p-fluid\"\n  (onHide)=\"onCancel()\">\n  \n  <ng-template pTemplate=\"content\">\n    <div class=\"dialog-content\">\n      @if (isPreferencesModeEnabled()) {\n        <div class=\"views-container\">\n          <tbl-columns-views\n            [views]=\"editedViews()\"\n            (viewSelected)=\"onSelectView($event)\"\n            (viewCreationClicked)=\"isViewCreation.set(true)\"\n            (viewCreationDone)=\"isViewCreation.set(false)\"\n            (addView)=\"onCreateView($event)\"\n            (deleteView)=\"onDeleteView($event)\"\n          />\n        </div>\n      }\n      <div class=\"cols-container\">\n        <tbl-columns-management\n          [activeView]=\"activeView()\"\n          [isViewCreation]=\"isViewCreation()\"\n          [isPreferencesModeEnabled]=\"isPreferencesModeEnabled()\"\n          (columnsReordered)=\"onColumnsReordered($event)\"\n          (selectedColumnsKeysChange)=\"onSelectedColumnsKeysChange($event)\"\n        />\n      </div>\n    </div>\n  </ng-template>\n\n  <ng-template pTemplate=\"footer\">\n    <p-button\n      pRipple\n      severity=\"secondary\"\n      [label]=\"labels.columnsDialog.cancel\"\n      icon=\"pi pi-times\"\n      (click)=\"onCancel()\"\n    />\n    <p-button\n      pRipple\n      severity=\"primary\"\n      [label]=\"labels.columnsDialog.save\"\n      icon=\"pi pi-check\"\n      [disabled]=\"isViewCreation()\"\n      (click)=\"onSaved()\"\n    />\n  </ng-template>\n</p-dialog>\n", styles: [".dialog-content{display:flex;height:100%}.dialog-content .views-container tbl-columns-views,.dialog-content .views-container tbl-columns-management,.dialog-content .cols-container tbl-columns-views,.dialog-content .cols-container tbl-columns-management{height:100%;display:block}.dialog-content .views-container{padding-right:20px;width:280px}.dialog-content .cols-container{flex:1}\n"], dependencies: [{ kind: "ngmodule", type: DialogModule }, { kind: "component", type: i1$e.Dialog, selector: "p-dialog", inputs: ["hostName", "header", "draggable", "resizable", "contentStyle", "contentStyleClass", "modal", "closeOnEscape", "dismissableMask", "rtl", "closable", "breakpoints", "styleClass", "maskStyleClass", "maskStyle", "showHeader", "blockScroll", "autoZIndex", "baseZIndex", "minX", "minY", "focusOnShow", "maximizable", "keepInViewport", "focusTrap", "transitionOptions", "maskMotionOptions", "motionOptions", "closeIcon", "closeAriaLabel", "closeTabindex", "minimizeIcon", "maximizeIcon", "closeButtonProps", "maximizeButtonProps", "visible", "style", "position", "role", "appendTo", "content", "contentTemplate", "footerTemplate", "closeIconTemplate", "maximizeIconTemplate", "minimizeIconTemplate", "headlessTemplate"], outputs: ["onShow", "onHide", "visibleChange", "onResizeInit", "onResizeEnd", "onDragEnd", "onMaximize"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i1.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "component", type: ColumnsManagementComponent, selector: "tbl-columns-management", inputs: ["activeView", "isViewCreation", "isPreferencesModeEnabled"], outputs: ["columnsReordered", "selectedColumnsKeysChange"] }, { kind: "component", type: ColumnsViewsComponent, selector: "tbl-columns-views", inputs: ["views"], outputs: ["deleteView", "addView", "viewSelected", "viewCreationClicked", "viewCreationDone"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ColumnsManagementDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-columns-management-dialog", imports: [
                        DialogModule,
                        ButtonModule,
                        ColumnsManagementComponent,
                        ColumnsViewsComponent,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<p-dialog\n  [(visible)]=\"visible\"\n  [header]=\"labels.columnsDialog.header\"\n  [modal]=\"false\"\n  [focusOnShow]=\"false\"\n  [maximizable]=\"true\"\n  styleClass=\"p-fluid\"\n  (onHide)=\"onCancel()\">\n  \n  <ng-template pTemplate=\"content\">\n    <div class=\"dialog-content\">\n      @if (isPreferencesModeEnabled()) {\n        <div class=\"views-container\">\n          <tbl-columns-views\n            [views]=\"editedViews()\"\n            (viewSelected)=\"onSelectView($event)\"\n            (viewCreationClicked)=\"isViewCreation.set(true)\"\n            (viewCreationDone)=\"isViewCreation.set(false)\"\n            (addView)=\"onCreateView($event)\"\n            (deleteView)=\"onDeleteView($event)\"\n          />\n        </div>\n      }\n      <div class=\"cols-container\">\n        <tbl-columns-management\n          [activeView]=\"activeView()\"\n          [isViewCreation]=\"isViewCreation()\"\n          [isPreferencesModeEnabled]=\"isPreferencesModeEnabled()\"\n          (columnsReordered)=\"onColumnsReordered($event)\"\n          (selectedColumnsKeysChange)=\"onSelectedColumnsKeysChange($event)\"\n        />\n      </div>\n    </div>\n  </ng-template>\n\n  <ng-template pTemplate=\"footer\">\n    <p-button\n      pRipple\n      severity=\"secondary\"\n      [label]=\"labels.columnsDialog.cancel\"\n      icon=\"pi pi-times\"\n      (click)=\"onCancel()\"\n    />\n    <p-button\n      pRipple\n      severity=\"primary\"\n      [label]=\"labels.columnsDialog.save\"\n      icon=\"pi pi-check\"\n      [disabled]=\"isViewCreation()\"\n      (click)=\"onSaved()\"\n    />\n  </ng-template>\n</p-dialog>\n", styles: [".dialog-content{display:flex;height:100%}.dialog-content .views-container tbl-columns-views,.dialog-content .views-container tbl-columns-management,.dialog-content .cols-container tbl-columns-views,.dialog-content .cols-container tbl-columns-management{height:100%;display:block}.dialog-content .views-container{padding-right:20px;width:280px}.dialog-content .cols-container{flex:1}\n"] }]
        }], propDecorators: { views: [{ type: i0.Input, args: [{ isSignal: true, alias: "views", required: true }] }], isPreferencesModeEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isPreferencesModeEnabled", required: true }] }], visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }, { type: i0.Output, args: ["visibleChange"] }], closed: [{ type: i0.Output, args: ["closed"] }], saved: [{ type: i0.Output, args: ["saved"] }] } });

class TableFilterCellPrimeComponent {
    col = input.required(...(ngDevMode ? [{ debugName: "col" }] : /* istanbul ignore next */ []));
    ControlType = CONTROL_TYPES;
    InputType = INPUT_TYPES;
    DATE_FORMAT = DATE_FORMAT_CALENDAR;
    options = computed(() => {
        return this.col().options ?? [];
    }, ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    // TODO: handle default filter value
    onSelectDate(event, filter) {
        const date = new Date(event).toDateString();
        filter(date);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableFilterCellPrimeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableFilterCellPrimeComponent, isStandalone: true, selector: "crd-table-filter-cell-prime", inputs: { col: { classPropertyName: "col", publicName: "col", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "@let column = col();\n\n@switch (column.filterType) {\n  @case (ControlType.DATE) {\n    <ng-container [ngTemplateOutlet]=\"date\"/>\n  }\n  @case (ControlType.CHECKBOX) {\n    <p-columnFilter type=\"boolean\" [field]=\"column.key\" display=\"menu\" matchMode=\"equals\" />\n  }\n  @case (ControlType.SELECT) {\n    <ng-container [ngTemplateOutlet]=\"select\"/>\n  }\n  @case (ControlType.MULTISELECT) {\n    <ng-container [ngTemplateOutlet]=\"select\"/>\n  }\n  @case (ControlType.INPUT) {\n    @switch (column.type) {\n      @case (InputType.TEXT) {\n        <p-columnFilter type=\"text\" [field]=\"column.key\" display=\"menu\" />\n      }\n      @case (InputType.NUMBER) {\n        <p-columnFilter type=\"numeric\" [field]=\"column.key\" display=\"menu\" />\n      }\n    }\n  }\n}\n\n<ng-template #select>\n  <p-columnFilter\n    [field]=\"column.key\"\n    matchMode=\"in\"\n    display=\"menu\"\n    [showMenu]=\"true\"\n    [showMatchModes]=\"false\"\n    [showOperator]=\"false\"\n    [showAddButton]=\"false\"\n    [showApplyButton]=\"false\"\n    [showClearButton]=\"true\">\n    <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n      <p-multiSelect [ngModel]=\"value\"\n        [options]=\"options()\"\n        (onChange)=\"filter($event.value)\"\n        placeholder=\"---\"\n        filterPlaceHolder=\"---\"\n        style=\"width: 100%;\">\n        <ng-template let-option pTemplate=\"item\">\n          <div class=\"flex\">\n            @if (option.icon) {\n              <span [innerHtml]=\"option.icon\" class=\"mr-2\"></span>\n            }\n            <div>{{ option.label }}</div>\n          </div>\n        </ng-template>\n      </p-multiSelect>\n    </ng-template>\n  </p-columnFilter>\n</ng-template>\n\n<ng-template #date>\n  <p-columnFilter type=\"date\"\n    [field]=\"column.key\"\n    display=\"menu\"\n    [showMenu]=\"true\">\n    <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n      <p-datepicker\n        [readonlyInput]=\"true\"\n        [showButtonBar]=\"true\"\n        [dateFormat]=\"DATE_FORMAT\"\n        appendTo=\"body\"\n        dataType=\"string\"\n        (onSelect)=\"onSelectDate($event, filter)\"\n        (onClearClick)=\"filter('', col, 'equals')\"\n      />\n    </ng-template>\n  </p-columnFilter>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: TableModule }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "component", type: i1$b.ColumnFilter, selector: "p-columnFilter, p-column-filter, p-columnfilter", inputs: ["field", "type", "display", "showMenu", "matchMode", "operator", "showOperator", "showClearButton", "showApplyButton", "showMatchModes", "showAddButton", "hideOnClear", "placeholder", "matchModeOptions", "maxConstraints", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "locale", "localeMatcher", "currency", "currencyDisplay", "filterOn", "useGrouping", "showButtons", "ariaLabel", "filterButtonProps", "motionOptions"], outputs: ["onShow", "onHide"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MultiSelectModule }, { kind: "component", type: i1$5.MultiSelect, selector: "p-multiSelect, p-multiselect, p-multi-select", inputs: ["id", "ariaLabel", "styleClass", "panelStyle", "panelStyleClass", "inputId", "readonly", "group", "filter", "filterPlaceHolder", "filterLocale", "overlayVisible", "tabindex", "dataKey", "ariaLabelledBy", "displaySelectedLabel", "maxSelectedLabels", "selectionLimit", "selectedItemsLabel", "showToggleAll", "emptyFilterMessage", "emptyMessage", "resetFilterOnHide", "dropdownIcon", "chipIcon", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "showHeader", "filterBy", "scrollHeight", "lazy", "virtualScroll", "loading", "virtualScrollItemSize", "loadingIcon", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "autofocusFilter", "display", "autocomplete", "showClear", "autofocus", "placeholder", "options", "filterValue", "selectAll", "focusOnHover", "filterFields", "selectOnFocus", "autoOptionFocus", "highlightOnSelect", "size", "variant", "fluid", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onClear", "onPanelShow", "onPanelHide", "onLazyLoad", "onRemove", "onSelectAllChange"] }, { kind: "ngmodule", type: DatePickerModule }, { kind: "component", type: i1$2.DatePicker, selector: "p-datePicker, p-datepicker, p-date-picker", inputs: ["iconDisplay", "styleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "ariaLabelledBy", "ariaLabel", "iconAriaLabel", "dateFormat", "multipleSeparator", "rangeSeparator", "inline", "showOtherMonths", "selectOtherMonths", "showIcon", "icon", "readonlyInput", "shortYearCutoff", "hourFormat", "timeOnly", "stepHour", "stepMinute", "stepSecond", "showSeconds", "showOnFocus", "showWeek", "startWeekFromFirstDayOfYear", "showClear", "dataType", "selectionMode", "maxDateCount", "showButtonBar", "todayButtonStyleClass", "clearButtonStyleClass", "autofocus", "autoZIndex", "baseZIndex", "panelStyleClass", "panelStyle", "keepInvalid", "hideOnDateTimeSelect", "touchUI", "timeSeparator", "focusTrap", "showTransitionOptions", "hideTransitionOptions", "tabindex", "minDate", "maxDate", "disabledDates", "disabledDays", "showTime", "responsiveOptions", "numberOfMonths", "firstDayOfWeek", "view", "defaultDate", "appendTo", "motionOptions"], outputs: ["onFocus", "onBlur", "onClose", "onSelect", "onClear", "onInput", "onTodayClick", "onClearClick", "onMonthChange", "onYearChange", "onClickOutside", "onShow"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableFilterCellPrimeComponent, decorators: [{
            type: Component,
            args: [{ selector: "crd-table-filter-cell-prime", imports: [
                        TableModule,
                        FormsModule,
                        NgTemplateOutlet,
                        MultiSelectModule,
                        DatePickerModule,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "@let column = col();\n\n@switch (column.filterType) {\n  @case (ControlType.DATE) {\n    <ng-container [ngTemplateOutlet]=\"date\"/>\n  }\n  @case (ControlType.CHECKBOX) {\n    <p-columnFilter type=\"boolean\" [field]=\"column.key\" display=\"menu\" matchMode=\"equals\" />\n  }\n  @case (ControlType.SELECT) {\n    <ng-container [ngTemplateOutlet]=\"select\"/>\n  }\n  @case (ControlType.MULTISELECT) {\n    <ng-container [ngTemplateOutlet]=\"select\"/>\n  }\n  @case (ControlType.INPUT) {\n    @switch (column.type) {\n      @case (InputType.TEXT) {\n        <p-columnFilter type=\"text\" [field]=\"column.key\" display=\"menu\" />\n      }\n      @case (InputType.NUMBER) {\n        <p-columnFilter type=\"numeric\" [field]=\"column.key\" display=\"menu\" />\n      }\n    }\n  }\n}\n\n<ng-template #select>\n  <p-columnFilter\n    [field]=\"column.key\"\n    matchMode=\"in\"\n    display=\"menu\"\n    [showMenu]=\"true\"\n    [showMatchModes]=\"false\"\n    [showOperator]=\"false\"\n    [showAddButton]=\"false\"\n    [showApplyButton]=\"false\"\n    [showClearButton]=\"true\">\n    <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n      <p-multiSelect [ngModel]=\"value\"\n        [options]=\"options()\"\n        (onChange)=\"filter($event.value)\"\n        placeholder=\"---\"\n        filterPlaceHolder=\"---\"\n        style=\"width: 100%;\">\n        <ng-template let-option pTemplate=\"item\">\n          <div class=\"flex\">\n            @if (option.icon) {\n              <span [innerHtml]=\"option.icon\" class=\"mr-2\"></span>\n            }\n            <div>{{ option.label }}</div>\n          </div>\n        </ng-template>\n      </p-multiSelect>\n    </ng-template>\n  </p-columnFilter>\n</ng-template>\n\n<ng-template #date>\n  <p-columnFilter type=\"date\"\n    [field]=\"column.key\"\n    display=\"menu\"\n    [showMenu]=\"true\">\n    <ng-template pTemplate=\"filter\" let-value let-filter=\"filterCallback\">\n      <p-datepicker\n        [readonlyInput]=\"true\"\n        [showButtonBar]=\"true\"\n        [dateFormat]=\"DATE_FORMAT\"\n        appendTo=\"body\"\n        dataType=\"string\"\n        (onSelect)=\"onSelectDate($event, filter)\"\n        (onClearClick)=\"filter('', col, 'equals')\"\n      />\n    </ng-template>\n  </p-columnFilter>\n</ng-template>\n" }]
        }], propDecorators: { col: [{ type: i0.Input, args: [{ isSignal: true, alias: "col", required: true }] }] } });

class FirstRowPipe {
    transform(dataTable, _cdrTrigger) {
        if (!dataTable) {
            return 0;
        }
        const { first } = dataTable;
        return (first ?? 0) + 1;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FirstRowPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.7", ngImport: i0, type: FirstRowPipe, isStandalone: true, name: "firstRow" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: FirstRowPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "firstRow",
                }]
        }] });

class LastRowPipe {
    transform(dataTable, total, _cdrTrigger) {
        if (!dataTable) {
            return 0;
        }
        const { first, rows } = dataTable;
        if (!rows) {
            return 0;
        }
        return Math.min((first ?? 0) + rows, Number(total));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LastRowPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.7", ngImport: i0, type: LastRowPipe, isStandalone: true, name: "lastRow" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LastRowPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "lastRow",
                }]
        }] });

class TableActionsCellComponent {
    labels = inject(CRUD_LABELS);
    features = input.required(...(ngDevMode ? [{ debugName: "features" }] : /* istanbul ignore next */ []));
    editClicked = output();
    deleteClicked = output();
    onEdit() {
        this.editClicked.emit();
    }
    onDelete() {
        this.deleteClicked.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableActionsCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableActionsCellComponent, isStandalone: true, selector: "tbl-table-actions-cell", inputs: { features: { classPropertyName: "features", publicName: "features", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { editClicked: "editClicked", deleteClicked: "deleteClicked" }, ngImport: i0, template: "@if (features().update) {\n  <button\n    pButton\n    pRipple\n    icon=\"pi pi-pencil\"\n    class=\"p-button-sm p-button-rounded p-button-text\"\n    [title]=\"labels.tableActions.edit\"\n    (click)=\"onEdit()\">\n  </button>\n}\n@if (features().archive) {\n  <button\n    pButton\n    pRipple icon=\"pi pi-trash\"\n    class=\"p-button-sm p-button-rounded p-button-text p-button-danger\"\n    [title]=\"labels.tableActions.delete\"\n    (click)=\"onDelete()\">\n  </button>\n}", styles: [""], dependencies: [{ kind: "ngmodule", type: ButtonModule }, { kind: "directive", type: i1.ButtonDirective, selector: "[pButton]", inputs: ["ptButtonDirective", "pButtonPT", "pButtonUnstyled", "hostName", "text", "plain", "raised", "size", "outlined", "rounded", "iconPos", "loadingIcon", "fluid", "label", "icon", "loading", "buttonProps", "severity"] }, { kind: "ngmodule", type: TooltipModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableActionsCellComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-table-actions-cell", imports: [ButtonModule, TooltipModule], template: "@if (features().update) {\n  <button\n    pButton\n    pRipple\n    icon=\"pi pi-pencil\"\n    class=\"p-button-sm p-button-rounded p-button-text\"\n    [title]=\"labels.tableActions.edit\"\n    (click)=\"onEdit()\">\n  </button>\n}\n@if (features().archive) {\n  <button\n    pButton\n    pRipple icon=\"pi pi-trash\"\n    class=\"p-button-sm p-button-rounded p-button-text p-button-danger\"\n    [title]=\"labels.tableActions.delete\"\n    (click)=\"onDelete()\">\n  </button>\n}" }]
        }], propDecorators: { features: [{ type: i0.Input, args: [{ isSignal: true, alias: "features", required: true }] }], editClicked: [{ type: i0.Output, args: ["editClicked"] }], deleteClicked: [{ type: i0.Output, args: ["deleteClicked"] }] } });

class CellTextContent {
    value = "";
    options = null;
    cellValue = "";
    checkboxLabels = {
        yes: "Oui",
        no: "Non",
    };
    defaultRenderer = () => `${this.cellValue}`;
    /**
     * Strategy pattern with specific renderers for complex control types.
     * Types not listed here will automatically fallback to defaultRenderer.
     */
    SPECIFIC_RENDERERS = {
        [CONTROL_TYPES.CHECKBOX]: () => this.checkboxCellRenderer(),
        [CONTROL_TYPES.DATE]: () => this.dateCellRenderer(),
        [CONTROL_TYPES.FILES]: () => this.getFileRenderer(),
        [CONTROL_TYPES.MULTISELECT]: () => this.multiselectCellRenderer(),
        [CONTROL_TYPES.PICKLIST]: () => this.multiselectCellRenderer(),
        [CONTROL_TYPES.RADIO]: () => this.selectCellRenderer(),
        [CONTROL_TYPES.SELECT]: () => this.selectCellRenderer(),
        [CONTROL_TYPES.WYSIWYG]: () => this.wysiwygRenderer(),
        [CONTROL_TYPES.GROUP]: () => this.groupCellRenderer(),
    };
    /**
     * Gets the appropriate renderer for the given control type.
     * Fallbacks to defaultRenderer for unhandled types.
     * @param controlType - The control type to get renderer for
     * @returns The renderer function
     */
    getRenderer(controlType) {
        return this.SPECIFIC_RENDERERS[controlType] ?? this.defaultRenderer;
    }
    constructor(config) {
        const { options, cellValue, checkboxLabels } = config;
        this.options = options;
        this.cellValue = cellValue;
        if (checkboxLabels) {
            this.checkboxLabels = checkboxLabels;
        }
        if (options.columnOptions?.tooltip) {
            this.value = options.columnOptions.tooltip(this.cellValue);
            return;
        }
        if (cellValue === undefined || cellValue === null) {
            this.value = "";
            return;
        }
        this.value = this.getRenderer(options.controlType)();
    }
    selectCellRenderer() {
        return this.getOption(this.cellValue);
    }
    multiselectCellRenderer() {
        if (this.isCellArray(this.cellValue)) {
            const values = this.cellValue
                .map((val) => this.getOption(val))
                .filter((val) => Boolean(val));
            return values.join(", ");
        }
        return this.selectCellRenderer();
    }
    wysiwygRenderer() {
        if (!isString(this.cellValue)) {
            return "";
        }
        const tmp = document.createElement("DIV");
        tmp.innerHTML = this.cellValue;
        return tmp.textContent || tmp.innerText || "";
    }
    dateCellRenderer() {
        if (!canBeDate(this.cellValue)) {
            return "";
        }
        return formatDate$1(this.cellValue, DATE_FORMAT, "fr");
    }
    checkboxCellRenderer() {
        return this.cellValue ? this.checkboxLabels.yes : this.checkboxLabels.no;
    }
    isCellArray(cellValue) {
        return !!cellValue && isArray(cellValue);
    }
    getOption(val) {
        const option = this.options?.options?.find((opt) => opt.value === val);
        if (!option) {
            return "";
        }
        const text = option.label || "";
        return text;
    }
    getFileRenderer() {
        return "file";
    }
    groupCellRenderer() {
        if (!isObject(this.cellValue)) {
            return "";
        }
        const information = [];
        const entries = Object.entries(this.cellValue);
        for (const [, val] of entries) {
            if (!isNil(val)) {
                information.push(`${val}`);
            }
        }
        const text = information.join(", ");
        return text;
    }
}

class TableCellTooltipComponent {
    labels = inject(CRUD_LABELS);
    cellValue = input.required(...(ngDevMode ? [{ debugName: "cellValue" }] : /* istanbul ignore next */ []));
    options = input.required(...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    tooltipValue = computed(() => {
        return new CellTextContent({
            options: this.options(),
            cellValue: this.cellValue(),
            checkboxLabels: this.labels.checkbox,
        }).value;
    }, ...(ngDevMode ? [{ debugName: "tooltipValue" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableCellTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.7", type: TableCellTooltipComponent, isStandalone: true, selector: "tbl-table-cell-tooltip", inputs: { cellValue: { classPropertyName: "cellValue", publicName: "cellValue", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "{{ tooltipValue() }}", changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableCellTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-table-cell-tooltip", changeDetection: ChangeDetectionStrategy.OnPush, imports: [], template: "{{ tooltipValue() }}" }]
        }], propDecorators: { cellValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "cellValue", required: true }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }] } });

class TableHeaderCellComponent {
    col = input.required(...(ngDevMode ? [{ debugName: "col" }] : /* istanbul ignore next */ []));
    customRenderedHeader = computed(() => {
        const renderer = this.col().columnOptions?.customHeaderRenderer;
        if (!renderer)
            return null;
        return renderer(this.col().label ?? this.col().key);
    }, ...(ngDevMode ? [{ debugName: "customRenderedHeader" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableHeaderCellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableHeaderCellComponent, isStandalone: true, selector: "tbl-table-header-cell", inputs: { col: { classPropertyName: "col", publicName: "col", isSignal: true, isRequired: true, transformFunction: null } }, host: { styleAttribute: "display: contents;" }, ngImport: i0, template: "@if (customRenderedHeader()) {\n  <span [innerHTML]=\"customRenderedHeader()\"></span>\n} @else {\n  <span>{{ col().label }}</span>\n}\n", changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableHeaderCellComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-table-header-cell", changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        style: "display: contents;",
                    }, template: "@if (customRenderedHeader()) {\n  <span [innerHTML]=\"customRenderedHeader()\"></span>\n} @else {\n  <span>{{ col().label }}</span>\n}\n" }]
        }], propDecorators: { col: [{ type: i0.Input, args: [{ isSignal: true, alias: "col", required: true }] }] } });

const defaultWidth = "150px";
class ColWidthPipe {
    transform(width) {
        return width ?? defaultWidth;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ColWidthPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.7", ngImport: i0, type: ColWidthPipe, isStandalone: true, name: "colWidth" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ColWidthPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: "colWidth",
                    standalone: true,
                }]
        }] });

function buildContextMenu(tableRegular) {
    if (!tableRegular.isContextMenuEnabled())
        return [];
    const seeItem = {
        label: "Visualiser",
        icon: "pi pi-fw pi-eye",
        command: () => {
            if (!tableRegular.rightClickedEntry) {
                return;
            }
            tableRegular.cellClicked.emit({
                row: tableRegular.rightClickedEntry,
                mode: "read",
            });
        },
    };
    const items = [seeItem];
    const editItem = {
        label: "Modifier",
        icon: "pi pi-fw pi-pencil",
        command: () => {
            if (!tableRegular.rightClickedEntry) {
                return;
            }
            tableRegular.cellClicked.emit({
                row: tableRegular.rightClickedEntry,
                mode: "write",
            });
        },
    };
    if (tableRegular.features().update) {
        items.push(editItem);
    }
    return items;
}

class TableRegularComponent {
    labels = inject(CRUD_LABELS);
    dataTable = viewChild(Table, ...(ngDevMode ? [{ debugName: "dataTable" }] : /* istanbul ignore next */ []));
    // TODO: rows number could be computed to take all the screen height
    columns = input.required(...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    data = input.required(...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    total = input.required(...(ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []));
    selectable = input.required(...(ngDevMode ? [{ debugName: "selectable" }] : /* istanbul ignore next */ []));
    clickableRows = input.required(...(ngDevMode ? [{ debugName: "clickableRows" }] : /* istanbul ignore next */ []));
    lazy = input.required(...(ngDevMode ? [{ debugName: "lazy" }] : /* istanbul ignore next */ []));
    features = input.required(...(ngDevMode ? [{ debugName: "features" }] : /* istanbul ignore next */ []));
    selectedEntries = model.required(...(ngDevMode ? [{ debugName: "selectedEntries" }] : /* istanbul ignore next */ []));
    filterable = input.required(...(ngDevMode ? [{ debugName: "filterable" }] : /* istanbul ignore next */ []));
    defaultFilters = input.required({ ...(ngDevMode ? { debugName: "defaultFilters" } : /* istanbul ignore next */ {}), transform: (filters) => filters });
    sortable = input.required(...(ngDevMode ? [{ debugName: "sortable" }] : /* istanbul ignore next */ []));
    defaultSort = input.required(...(ngDevMode ? [{ debugName: "defaultSort" }] : /* istanbul ignore next */ []));
    paginator = input.required(...(ngDevMode ? [{ debugName: "paginator" }] : /* istanbul ignore next */ []));
    filterLevel = input.required(...(ngDevMode ? [{ debugName: "filterLevel" }] : /* istanbul ignore next */ []));
    customRowStyles = input.required(...(ngDevMode ? [{ debugName: "customRowStyles" }] : /* istanbul ignore next */ []));
    customActionsTemplate = input.required(...(ngDevMode ? [{ debugName: "customActionsTemplate" }] : /* istanbul ignore next */ []));
    isContextMenuEnabled = input.required(...(ngDevMode ? [{ debugName: "isContextMenuEnabled" }] : /* istanbul ignore next */ []));
    entityId = input.required(...(ngDevMode ? [{ debugName: "entityId" }] : /* istanbul ignore next */ []));
    stateStorage = input.required(...(ngDevMode ? [{ debugName: "stateStorage" }] : /* istanbul ignore next */ []));
    persistState = input.required(...(ngDevMode ? [{ debugName: "persistState" }] : /* istanbul ignore next */ []));
    areColumnsResizable = input.required(...(ngDevMode ? [{ debugName: "areColumnsResizable" }] : /* istanbul ignore next */ []));
    rows = input.required(...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    rowsPerPageOptions = input.required(...(ngDevMode ? [{ debugName: "rowsPerPageOptions" }] : /* istanbul ignore next */ []));
    outsideTableHeight = input.required(...(ngDevMode ? [{ debugName: "outsideTableHeight" }] : /* istanbul ignore next */ []));
    stripedRows = input.required(...(ngDevMode ? [{ debugName: "stripedRows" }] : /* istanbul ignore next */ []));
    additionalReadonlyProperties = input.required(...(ngDevMode ? [{ debugName: "additionalReadonlyProperties" }] : /* istanbul ignore next */ []));
    selectedEntriesChange = output();
    lazyLoaded = output();
    archived = output();
    cellClicked = output();
    columnResized = output();
    lastUpdateTime = signal(0, ...(ngDevMode ? [{ debugName: "lastUpdateTime" }] : /* istanbul ignore next */ []));
    totalCount = computed(() => this.total() ?? 0, ...(ngDevMode ? [{ debugName: "totalCount" }] : /* istanbul ignore next */ []));
    visibleColumns = computed(() => this.columns().filter((col) => col.isVisible), ...(ngDevMode ? [{ debugName: "visibleColumns" }] : /* istanbul ignore next */ []));
    contextMenuItems = computed(() => buildContextMenu(this), ...(ngDevMode ? [{ debugName: "contextMenuItems" }] : /* istanbul ignore next */ []));
    rightClickedEntry = null;
    scrollHeight = computed(() => {
        return `calc(100vh - ${this.outsideTableHeight()})`;
    }, ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    // Handle sorting manually to be able to synchronize with stateStorage
    sortEffect = effect(() => {
        const table = this.dataTable();
        if (!table) {
            return;
        }
        const { field, order } = this.defaultSort();
        table.sortField = field;
        table.sortOrder = order;
    }, ...(ngDevMode ? [{ debugName: "sortEffect" }] : /* istanbul ignore next */ []));
    trackCol(col) {
        return col;
    }
    onLazyLoad(event) {
        this.lazyLoaded.emit(event);
        this.lastUpdateTime.set(Date.now());
    }
    onCellClick(rowData, col) {
        if (!this.clickableRows() || col.controlType === CONTROL_TYPES.CUSTOM) {
            return;
        }
        let mode = this.features().update ? "write" : "read";
        const readonlyProperties = this.additionalReadonlyProperties();
        if (readonlyProperties) {
            const match = Object.entries(readonlyProperties).find(([key, value]) => {
                return rowData[key] === value;
            });
            if (match) {
                mode = "read";
            }
        }
        this.cellClicked.emit({ row: rowData, mode });
    }
    onActionClick(rowData, mode) {
        this.cellClicked.emit({ row: rowData, mode });
    }
    resolvedRowStyles(rowData) {
        const base = this.customRowStyles()?.(rowData) ?? {};
        const isArchived = rowData.archived === true;
        const readonlyProperties = this.additionalReadonlyProperties();
        const matchesReadonly = readonlyProperties
            ? Object.entries(readonlyProperties).some(([key, value]) => rowData[key] === value)
            : false;
        const noUpdate = !this.features().update;
        return isArchived || matchesReadonly || noUpdate
            ? { ...base, opacity: "0.5" }
            : base;
    }
    onColumnResized(event) {
        const colKey = event.element.getAttribute("data-colkey") ?? "";
        if (!colKey)
            return;
        // Emit the resize event
        const newWidthPx = event.element.offsetWidth;
        const resizeEvent = {
            colKey,
            newWidthPx,
        };
        this.columnResized.emit(resizeEvent);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableRegularComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableRegularComponent, isStandalone: true, selector: "tbl-table-regular", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: true, transformFunction: null }, total: { classPropertyName: "total", publicName: "total", isSignal: true, isRequired: true, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: true, transformFunction: null }, clickableRows: { classPropertyName: "clickableRows", publicName: "clickableRows", isSignal: true, isRequired: true, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: true, transformFunction: null }, features: { classPropertyName: "features", publicName: "features", isSignal: true, isRequired: true, transformFunction: null }, selectedEntries: { classPropertyName: "selectedEntries", publicName: "selectedEntries", isSignal: true, isRequired: true, transformFunction: null }, filterable: { classPropertyName: "filterable", publicName: "filterable", isSignal: true, isRequired: true, transformFunction: null }, defaultFilters: { classPropertyName: "defaultFilters", publicName: "defaultFilters", isSignal: true, isRequired: true, transformFunction: null }, sortable: { classPropertyName: "sortable", publicName: "sortable", isSignal: true, isRequired: true, transformFunction: null }, defaultSort: { classPropertyName: "defaultSort", publicName: "defaultSort", isSignal: true, isRequired: true, transformFunction: null }, paginator: { classPropertyName: "paginator", publicName: "paginator", isSignal: true, isRequired: true, transformFunction: null }, filterLevel: { classPropertyName: "filterLevel", publicName: "filterLevel", isSignal: true, isRequired: true, transformFunction: null }, customRowStyles: { classPropertyName: "customRowStyles", publicName: "customRowStyles", isSignal: true, isRequired: true, transformFunction: null }, customActionsTemplate: { classPropertyName: "customActionsTemplate", publicName: "customActionsTemplate", isSignal: true, isRequired: true, transformFunction: null }, isContextMenuEnabled: { classPropertyName: "isContextMenuEnabled", publicName: "isContextMenuEnabled", isSignal: true, isRequired: true, transformFunction: null }, entityId: { classPropertyName: "entityId", publicName: "entityId", isSignal: true, isRequired: true, transformFunction: null }, stateStorage: { classPropertyName: "stateStorage", publicName: "stateStorage", isSignal: true, isRequired: true, transformFunction: null }, persistState: { classPropertyName: "persistState", publicName: "persistState", isSignal: true, isRequired: true, transformFunction: null }, areColumnsResizable: { classPropertyName: "areColumnsResizable", publicName: "areColumnsResizable", isSignal: true, isRequired: true, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: true, transformFunction: null }, rowsPerPageOptions: { classPropertyName: "rowsPerPageOptions", publicName: "rowsPerPageOptions", isSignal: true, isRequired: true, transformFunction: null }, outsideTableHeight: { classPropertyName: "outsideTableHeight", publicName: "outsideTableHeight", isSignal: true, isRequired: true, transformFunction: null }, stripedRows: { classPropertyName: "stripedRows", publicName: "stripedRows", isSignal: true, isRequired: true, transformFunction: null }, additionalReadonlyProperties: { classPropertyName: "additionalReadonlyProperties", publicName: "additionalReadonlyProperties", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { selectedEntries: "selectedEntriesChange", selectedEntriesChange: "selectedEntriesChange", lazyLoaded: "lazyLoaded", archived: "archived", cellClicked: "cellClicked", columnResized: "columnResized" }, viewQueries: [{ propertyName: "dataTable", first: true, predicate: Table, descendants: true, isSignal: true }], ngImport: i0, template: "<p-contextmenu #cm [model]=\"contextMenuItems()\" appendTo=\"body\" />\n<p-table #dataTable\n  class=\"table\"\n  [stripedRows]=\"stripedRows()\"\n  [scrollable]=\"true\"\n  [scrollHeight]=\"scrollHeight()\"\n  [columns]=\"visibleColumns()\"\n  [value]=\"data()\"\n  [totalRecords]=\"total()\"\n  [rowHover]=\"true\"\n  [rows]=\"rows()\"\n  [rowsPerPageOptions]=\"rowsPerPageOptions()\"\n  [paginator]=\"paginator()\"\n  [filters]=\"defaultFilters()\"\n  [showCurrentPageReport]=\"data().length > 0\"\n  i18n-currentPageReportTemplate=\"@@Table_CurrentPageReportTemplate\"\n  [currentPageReportTemplate]=\"labels.tableRegular.currentPageReport(\n    (dataTable | firstRow:lastUpdateTime()).toString(),\n    (dataTable | lastRow:totalCount():lastUpdateTime()).toString(),\n    totalCount().toString()\n  )\"\n  [lazy]=\"lazy()\"\n  [contextMenu]=\"isContextMenuEnabled() ? cm : null\"\n  [stateStorage]=\"stateStorage()\"\n  [stateKey]=\"persistState() ? entityId() + '-table-state' : undefined\"\n  [resizableColumns]=\"areColumnsResizable()\" \n  columnResizeMode=\"expand\"\n  [(selection)]=\"selectedEntries\"\n  [(contextMenuSelection)]=\"rightClickedEntry\"\n  (onLazyLoad)=\"onLazyLoad($event)\"\n  (selectionChange)=\"selectedEntriesChange.emit($event)\"\n  (onColResize)=\"onColumnResized($event)\">\n\n  <!-- No data panel -->\n  <ng-template pTemplate=\"emptymessage\">\n    <tr>\n      <td \n        [attr.colspan]=\"columns().length\" \n        class=\"no-data-row\">\n        {{ labels.tableControl.noData }}\n      </td>\n    </tr>\n  </ng-template>\n\n  <ng-template pTemplate=\"header\" let-columns>\n    <!-- Header labels row -->\n    <tr>\n      @if (selectable()) {\n        <th class=\"checkbox-column\" scope=\"col\">\n          <p-tableHeaderCheckbox />\n        </th>\n      }\n      @for (col of columns; track trackCol(col)) {\n        <th [pSortableColumnDisabled]=\"!sortable() || !col.sortable\"\n          [pSortableColumn]=\"col.key\"\n          pResizableColumn\n          [pTooltip]=\"col.headerTooltip ?? col.label\"\n          [tooltipDisabled]=\"!col.headerTooltip\"\n          [style.width]=\"col.defaultWidth | colWidth\"\n          [style.max-width]=\"col.defaultWidth | colWidth\"\n          scope=\"th\"\n          [attr.data-colkey]=\"col.key\">\n          <div class=\"header-container\">\n            <div class=\"sub-container\">\n              <tbl-table-header-cell [col]=\"col\" />\n              @if (col.sortable) {\n                <p-sortIcon [field]=\"col.key\" />\n              }\n              @if (col.filterable && filterLevel() === \"advanced\") {\n                <crd-table-filter-cell-prime\n                  [col]=\"col\"\n                />\n              }\n            </div>\n          </div>\n        </th>\n      }\n      @if (!clickableRows() || customActionsTemplate()) {\n        <th scope=\"th\" class=\"actions-column\">{{ labels.tableControl.actionsColumnHeader }}</th>\n      }\n    </tr>\n    <!-- Filter row -->\n    @if (filterable() && (filterLevel() === \"basic\" || filterLevel() === \"intermediate\")) {\n      <tr>\n        @if (selectable()) {\n          <th class=\"checkbox-column\" scope=\"col\"></th>\n        }\n        @for (col of columns; track trackCol(col)) {\n          <th\n            class=\"filter-row-th\"\n            [style.width]=\"col.defaultWidth | colWidth\"\n            [style.max-width]=\"col.defaultWidth | colWidth\"\n            scope=\"th\">\n            @if (col.filterable) {\n              <crd-table-filter-cell\n                [col]=\"col\"\n                [dt]=\"dataTable\"\n                [filterLevel]=\"filterLevel()\"\n              />\n            }\n          </th>\n        }\n        @if (!clickableRows() || customActionsTemplate()) {\n          <th scope=\"col\" class=\"actions-column\"></th>\n        }\n      </tr>\n    }\n  </ng-template>\n\n  <ng-template pTemplate=\"body\" let-rowData let-rowIndex=\"rowIndex\" let-columns=\"columns\">\n    <tr [ngStyle]=\"resolvedRowStyles(rowData)\" [pContextMenuRow]=\"rowData\">\n      @if (selectable()) {\n        <td class=\"checkbox-column\">\n          <p-tableCheckbox [value]=\"rowData\" />\n        </td>\n      }\n      @for (col of columns; track trackCol(col)) {\n        @let value = rowData[col.key];\n        <td\n          [pTooltip]=\"tooltip\"\n          [tooltipDisabled]=\"value === null || value === undefined || value === ''\"\n          [class.clickable]=\"clickableRows()\"\n          [style.width]=\"col.defaultWidth | colWidth\"\n          [style.max-width]=\"col.defaultWidth | colWidth\"\n          (click)=\"onCellClick(rowData, col)\">\n          <tbl-table-cell [cellValue]=\"value\" [options]=\"col\" />\n        </td>\n        <ng-template #tooltip>\n          <tbl-table-cell-tooltip [cellValue]=\"value\" [options]=\"col\" />\n        </ng-template>\n      }\n      @if (!clickableRows() || customActionsTemplate()) {\n        <td class=\"actions-column\">\n          @let customTemplate = customActionsTemplate();\n          @if (customTemplate) {\n            <ng-container [ngTemplateOutlet]=\"customTemplate\"\n              [ngTemplateOutletContext]=\"{ $implicit: rowData }\">\n            </ng-container>\n          } @else {\n            <tbl-table-actions-cell\n              [features]=\"features()\"\n              (viewClicked)=\"onActionClick(rowData, 'read')\"\n              (editClicked)=\"onActionClick(rowData, 'write')\"\n              (deleteClicked)=\"archived.emit(rowData.id)\"\n            />\n          }\n        </td>\n      }\n    </tr>\n  </ng-template>\n</p-table>\n", dependencies: [{ kind: "ngmodule", type: TableModule }, { kind: "component", type: i1$b.Table, selector: "p-table", inputs: ["frozenColumns", "frozenValue", "styleClass", "tableStyle", "tableStyleClass", "paginator", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorStyleClass", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "selectionMode", "selectionPageOnly", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "rowSelectable", "rowTrackBy", "lazy", "lazyLoadOnInit", "compareSelectionBy", "csvSeparator", "exportFilename", "filters", "globalFilterFields", "filterDelay", "filterLocale", "expandedRowKeys", "editingRowKeys", "rowExpandMode", "scrollable", "rowGroupMode", "scrollHeight", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "virtualScrollDelay", "frozenWidth", "contextMenu", "resizableColumns", "columnResizeMode", "reorderableColumns", "loading", "loadingIcon", "showLoader", "rowHover", "customSort", "showInitialSortBadge", "exportFunction", "exportHeader", "stateKey", "stateStorage", "editMode", "groupRowsBy", "size", "showGridlines", "stripedRows", "groupRowsByOrder", "responsiveLayout", "breakpoint", "paginatorLocale", "value", "columns", "first", "rows", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection", "selectAll"], outputs: ["contextMenuSelectionChange", "selectAllChange", "selectionChange", "onRowSelect", "onRowUnselect", "onPage", "onSort", "onFilter", "onLazyLoad", "onRowExpand", "onRowCollapse", "onContextMenuSelect", "onColResize", "onColReorder", "onRowReorder", "onEditInit", "onEditComplete", "onEditCancel", "onHeaderCheckboxToggle", "sortFunction", "firstChange", "rowsChange", "onStateSave", "onStateRestore"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: i1$b.SortableColumn, selector: "[pSortableColumn]", inputs: ["pSortableColumn", "pSortableColumnDisabled"] }, { kind: "directive", type: i1$b.ContextMenuRow, selector: "[pContextMenuRow]", inputs: ["pContextMenuRow", "pContextMenuRowIndex", "pContextMenuRowDisabled"] }, { kind: "directive", type: i1$b.ResizableColumn, selector: "[pResizableColumn]", inputs: ["pResizableColumnDisabled"] }, { kind: "component", type: i1$b.SortIcon, selector: "p-sortIcon", inputs: ["field"] }, { kind: "component", type: i1$b.TableCheckbox, selector: "p-tableCheckbox", inputs: ["value", "disabled", "required", "index", "inputId", "name", "ariaLabel"] }, { kind: "component", type: i1$b.TableHeaderCheckbox, selector: "p-tableHeaderCheckbox", inputs: ["disabled", "inputId", "name", "ariaLabel"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: TableActionsCellComponent, selector: "tbl-table-actions-cell", inputs: ["features"], outputs: ["editClicked", "deleteClicked"] }, { kind: "component", type: TableFilterCellComponent, selector: "crd-table-filter-cell", inputs: ["col", "dt", "filterLevel"] }, { kind: "component", type: TableFilterCellPrimeComponent, selector: "crd-table-filter-cell-prime", inputs: ["col"] }, { kind: "ngmodule", type: ContextMenuModule }, { kind: "component", type: i3$3.ContextMenu, selector: "p-contextMenu, p-contextmenu, p-context-menu", inputs: ["model", "triggerEvent", "target", "global", "style", "styleClass", "autoZIndex", "baseZIndex", "id", "breakpoint", "ariaLabel", "ariaLabelledBy", "pressDelay", "appendTo", "motionOptions"], outputs: ["onShow", "onHide"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: TableCellComponent, selector: "tbl-table-cell", inputs: ["cellValue", "options"] }, { kind: "component", type: TableCellTooltipComponent, selector: "tbl-table-cell-tooltip", inputs: ["cellValue", "options"] }, { kind: "component", type: TableHeaderCellComponent, selector: "tbl-table-header-cell", inputs: ["col"] }, { kind: "directive", type: Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "pipe", type: FirstRowPipe, name: "firstRow" }, { kind: "pipe", type: LastRowPipe, name: "lastRow" }, { kind: "pipe", type: ColWidthPipe, name: "colWidth" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableRegularComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-table-regular", imports: [
                        TableModule,
                        FirstRowPipe,
                        LastRowPipe,
                        NgStyle,
                        TableActionsCellComponent,
                        TableFilterCellComponent,
                        TableFilterCellPrimeComponent,
                        ContextMenuModule,
                        ColWidthPipe,
                        NgTemplateOutlet,
                        TableCellComponent,
                        TableCellTooltipComponent,
                        TableHeaderCellComponent,
                        Tooltip,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<p-contextmenu #cm [model]=\"contextMenuItems()\" appendTo=\"body\" />\n<p-table #dataTable\n  class=\"table\"\n  [stripedRows]=\"stripedRows()\"\n  [scrollable]=\"true\"\n  [scrollHeight]=\"scrollHeight()\"\n  [columns]=\"visibleColumns()\"\n  [value]=\"data()\"\n  [totalRecords]=\"total()\"\n  [rowHover]=\"true\"\n  [rows]=\"rows()\"\n  [rowsPerPageOptions]=\"rowsPerPageOptions()\"\n  [paginator]=\"paginator()\"\n  [filters]=\"defaultFilters()\"\n  [showCurrentPageReport]=\"data().length > 0\"\n  i18n-currentPageReportTemplate=\"@@Table_CurrentPageReportTemplate\"\n  [currentPageReportTemplate]=\"labels.tableRegular.currentPageReport(\n    (dataTable | firstRow:lastUpdateTime()).toString(),\n    (dataTable | lastRow:totalCount():lastUpdateTime()).toString(),\n    totalCount().toString()\n  )\"\n  [lazy]=\"lazy()\"\n  [contextMenu]=\"isContextMenuEnabled() ? cm : null\"\n  [stateStorage]=\"stateStorage()\"\n  [stateKey]=\"persistState() ? entityId() + '-table-state' : undefined\"\n  [resizableColumns]=\"areColumnsResizable()\" \n  columnResizeMode=\"expand\"\n  [(selection)]=\"selectedEntries\"\n  [(contextMenuSelection)]=\"rightClickedEntry\"\n  (onLazyLoad)=\"onLazyLoad($event)\"\n  (selectionChange)=\"selectedEntriesChange.emit($event)\"\n  (onColResize)=\"onColumnResized($event)\">\n\n  <!-- No data panel -->\n  <ng-template pTemplate=\"emptymessage\">\n    <tr>\n      <td \n        [attr.colspan]=\"columns().length\" \n        class=\"no-data-row\">\n        {{ labels.tableControl.noData }}\n      </td>\n    </tr>\n  </ng-template>\n\n  <ng-template pTemplate=\"header\" let-columns>\n    <!-- Header labels row -->\n    <tr>\n      @if (selectable()) {\n        <th class=\"checkbox-column\" scope=\"col\">\n          <p-tableHeaderCheckbox />\n        </th>\n      }\n      @for (col of columns; track trackCol(col)) {\n        <th [pSortableColumnDisabled]=\"!sortable() || !col.sortable\"\n          [pSortableColumn]=\"col.key\"\n          pResizableColumn\n          [pTooltip]=\"col.headerTooltip ?? col.label\"\n          [tooltipDisabled]=\"!col.headerTooltip\"\n          [style.width]=\"col.defaultWidth | colWidth\"\n          [style.max-width]=\"col.defaultWidth | colWidth\"\n          scope=\"th\"\n          [attr.data-colkey]=\"col.key\">\n          <div class=\"header-container\">\n            <div class=\"sub-container\">\n              <tbl-table-header-cell [col]=\"col\" />\n              @if (col.sortable) {\n                <p-sortIcon [field]=\"col.key\" />\n              }\n              @if (col.filterable && filterLevel() === \"advanced\") {\n                <crd-table-filter-cell-prime\n                  [col]=\"col\"\n                />\n              }\n            </div>\n          </div>\n        </th>\n      }\n      @if (!clickableRows() || customActionsTemplate()) {\n        <th scope=\"th\" class=\"actions-column\">{{ labels.tableControl.actionsColumnHeader }}</th>\n      }\n    </tr>\n    <!-- Filter row -->\n    @if (filterable() && (filterLevel() === \"basic\" || filterLevel() === \"intermediate\")) {\n      <tr>\n        @if (selectable()) {\n          <th class=\"checkbox-column\" scope=\"col\"></th>\n        }\n        @for (col of columns; track trackCol(col)) {\n          <th\n            class=\"filter-row-th\"\n            [style.width]=\"col.defaultWidth | colWidth\"\n            [style.max-width]=\"col.defaultWidth | colWidth\"\n            scope=\"th\">\n            @if (col.filterable) {\n              <crd-table-filter-cell\n                [col]=\"col\"\n                [dt]=\"dataTable\"\n                [filterLevel]=\"filterLevel()\"\n              />\n            }\n          </th>\n        }\n        @if (!clickableRows() || customActionsTemplate()) {\n          <th scope=\"col\" class=\"actions-column\"></th>\n        }\n      </tr>\n    }\n  </ng-template>\n\n  <ng-template pTemplate=\"body\" let-rowData let-rowIndex=\"rowIndex\" let-columns=\"columns\">\n    <tr [ngStyle]=\"resolvedRowStyles(rowData)\" [pContextMenuRow]=\"rowData\">\n      @if (selectable()) {\n        <td class=\"checkbox-column\">\n          <p-tableCheckbox [value]=\"rowData\" />\n        </td>\n      }\n      @for (col of columns; track trackCol(col)) {\n        @let value = rowData[col.key];\n        <td\n          [pTooltip]=\"tooltip\"\n          [tooltipDisabled]=\"value === null || value === undefined || value === ''\"\n          [class.clickable]=\"clickableRows()\"\n          [style.width]=\"col.defaultWidth | colWidth\"\n          [style.max-width]=\"col.defaultWidth | colWidth\"\n          (click)=\"onCellClick(rowData, col)\">\n          <tbl-table-cell [cellValue]=\"value\" [options]=\"col\" />\n        </td>\n        <ng-template #tooltip>\n          <tbl-table-cell-tooltip [cellValue]=\"value\" [options]=\"col\" />\n        </ng-template>\n      }\n      @if (!clickableRows() || customActionsTemplate()) {\n        <td class=\"actions-column\">\n          @let customTemplate = customActionsTemplate();\n          @if (customTemplate) {\n            <ng-container [ngTemplateOutlet]=\"customTemplate\"\n              [ngTemplateOutletContext]=\"{ $implicit: rowData }\">\n            </ng-container>\n          } @else {\n            <tbl-table-actions-cell\n              [features]=\"features()\"\n              (viewClicked)=\"onActionClick(rowData, 'read')\"\n              (editClicked)=\"onActionClick(rowData, 'write')\"\n              (deleteClicked)=\"archived.emit(rowData.id)\"\n            />\n          }\n        </td>\n      }\n    </tr>\n  </ng-template>\n</p-table>\n" }]
        }], propDecorators: { dataTable: [{ type: i0.ViewChild, args: [i0.forwardRef(() => Table), { isSignal: true }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: true }] }], total: [{ type: i0.Input, args: [{ isSignal: true, alias: "total", required: true }] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: true }] }], clickableRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "clickableRows", required: true }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: true }] }], features: [{ type: i0.Input, args: [{ isSignal: true, alias: "features", required: true }] }], selectedEntries: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedEntries", required: true }] }, { type: i0.Output, args: ["selectedEntriesChange"] }], filterable: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterable", required: true }] }], defaultFilters: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultFilters", required: true }] }], sortable: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortable", required: true }] }], defaultSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultSort", required: true }] }], paginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginator", required: true }] }], filterLevel: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLevel", required: true }] }], customRowStyles: [{ type: i0.Input, args: [{ isSignal: true, alias: "customRowStyles", required: true }] }], customActionsTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "customActionsTemplate", required: true }] }], isContextMenuEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isContextMenuEnabled", required: true }] }], entityId: [{ type: i0.Input, args: [{ isSignal: true, alias: "entityId", required: true }] }], stateStorage: [{ type: i0.Input, args: [{ isSignal: true, alias: "stateStorage", required: true }] }], persistState: [{ type: i0.Input, args: [{ isSignal: true, alias: "persistState", required: true }] }], areColumnsResizable: [{ type: i0.Input, args: [{ isSignal: true, alias: "areColumnsResizable", required: true }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: true }] }], rowsPerPageOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowsPerPageOptions", required: true }] }], outsideTableHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "outsideTableHeight", required: true }] }], stripedRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "stripedRows", required: true }] }], additionalReadonlyProperties: [{ type: i0.Input, args: [{ isSignal: true, alias: "additionalReadonlyProperties", required: true }] }], selectedEntriesChange: [{ type: i0.Output, args: ["selectedEntriesChange"] }], lazyLoaded: [{ type: i0.Output, args: ["lazyLoaded"] }], archived: [{ type: i0.Output, args: ["archived"] }], cellClicked: [{ type: i0.Output, args: ["cellClicked"] }], columnResized: [{ type: i0.Output, args: ["columnResized"] }] } });

class ExportDialogComponent {
    loadingService = inject(TableLoadingService);
    labels = inject(CRUD_LABELS);
    visible = input.required(...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    cols = input.required(...(ngDevMode ? [{ debugName: "cols" }] : /* istanbul ignore next */ []));
    isExcelExportEnabled = input.required(...(ngDevMode ? [{ debugName: "isExcelExportEnabled" }] : /* istanbul ignore next */ []));
    isCsvExportEnabled = input.required(...(ngDevMode ? [{ debugName: "isCsvExportEnabled" }] : /* istanbul ignore next */ []));
    hide = output();
    export = output();
    formats = computed(() => [
        { label: "CSV", value: "csv", disabled: !this.isCsvExportEnabled() },
        { label: "Excel", value: "xls", disabled: !this.isExcelExportEnabled() },
    ], ...(ngDevMode ? [{ debugName: "formats" }] : /* istanbul ignore next */ []));
    selectionOptions = computed(() => [
        { label: this.labels.exportDialog.all, value: "all" },
        { label: this.labels.exportDialog.selection, value: "filtered" },
    ], ...(ngDevMode ? [{ debugName: "selectionOptions" }] : /* istanbul ignore next */ []));
    format = "csv";
    selection = "all";
    isLoading = this.loadingService.isLoading;
    onHide() {
        this.format = "csv";
        this.hide.emit();
    }
    onExport() {
        this.export.emit({ format: this.format, selection: this.selection });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ExportDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.7", type: ExportDialogComponent, isStandalone: true, selector: "tbl-export-dialog", inputs: { visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: true, transformFunction: null }, cols: { classPropertyName: "cols", publicName: "cols", isSignal: true, isRequired: true, transformFunction: null }, isExcelExportEnabled: { classPropertyName: "isExcelExportEnabled", publicName: "isExcelExportEnabled", isSignal: true, isRequired: true, transformFunction: null }, isCsvExportEnabled: { classPropertyName: "isCsvExportEnabled", publicName: "isCsvExportEnabled", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { hide: "hide", export: "export" }, ngImport: i0, template: "<p-dialog [visible]=\"visible()\"\n  [style]=\"{width: '450px'}\"\n  [header]=\"labels.exportDialog.header\"\n  [modal]=\"true\"\n  styleClass=\"p-fluid\"\n  (visibleChange)=\"$event ? false : onHide()\"\n  (onHide)=\"onHide()\">\n  <ng-template pTemplate=\"content\">\n    <div class=\"container\">\n      <span class=\"label\">{{ labels.exportDialog.chooseFormat }}</span>\n      <p-selectButton\n        [options]=\"formats()\"\n        [(ngModel)]=\"format\"\n        optionLabel=\"label\"\n        optionValue=\"value\"\n      />\n    </div>\n\n    <div class=\"container\">\n      <span class=\"label\">{{ labels.exportDialog.chooseData }}</span>\n      <p-selectButton\n        [options]=\"selectionOptions()\"\n        [(ngModel)]=\"selection\"\n        optionLabel=\"label\"\n        optionValue=\"value\"\n      />\n    </div>\n  </ng-template>\n\n  <ng-template pTemplate=\"footer\">\n    <button pButton\n      pRipple\n      [label]=\"labels.exportDialog.cancel\"\n      icon=\"pi pi-times\"\n      class=\"p-button-text\"\n      (click)=\"onHide()\">\n    </button>\n\n    <button pButton\n      pRipple\n      [label]=\"labels.exportDialog.export\"\n      icon=\"pi pi-check\"\n      class=\"p-button-success\"\n      [loading]=\"isLoading()\"      \n      (click)=\"onExport()\">\n    </button>\n  </ng-template>\n</p-dialog>\n", styles: [".container{display:flex;flex-direction:column;margin-bottom:1rem}.container .label{font-weight:700;margin-bottom:1rem}\n"], dependencies: [{ kind: "ngmodule", type: DialogModule }, { kind: "component", type: i1$e.Dialog, selector: "p-dialog", inputs: ["hostName", "header", "draggable", "resizable", "contentStyle", "contentStyleClass", "modal", "closeOnEscape", "dismissableMask", "rtl", "closable", "breakpoints", "styleClass", "maskStyleClass", "maskStyle", "showHeader", "blockScroll", "autoZIndex", "baseZIndex", "minX", "minY", "focusOnShow", "maximizable", "keepInViewport", "focusTrap", "transitionOptions", "maskMotionOptions", "motionOptions", "closeIcon", "closeAriaLabel", "closeTabindex", "minimizeIcon", "maximizeIcon", "closeButtonProps", "maximizeButtonProps", "visible", "style", "position", "role", "appendTo", "content", "contentTemplate", "footerTemplate", "closeIconTemplate", "maximizeIconTemplate", "minimizeIconTemplate", "headlessTemplate"], outputs: ["onShow", "onHide", "visibleChange", "onResizeInit", "onResizeEnd", "onDragEnd", "onMaximize"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: CardModule }, { kind: "ngmodule", type: SelectButtonModule }, { kind: "component", type: i1$9.SelectButton, selector: "p-selectButton, p-selectbutton, p-select-button", inputs: ["options", "optionLabel", "optionValue", "optionDisabled", "unselectable", "tabindex", "multiple", "allowEmpty", "styleClass", "ariaLabelledBy", "dataKey", "autofocus", "size", "fluid"], outputs: ["onOptionClick", "onChange"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ButtonModule }, { kind: "directive", type: i1.ButtonDirective, selector: "[pButton]", inputs: ["ptButtonDirective", "pButtonPT", "pButtonUnstyled", "hostName", "text", "plain", "raised", "size", "outlined", "rounded", "iconPos", "loadingIcon", "fluid", "label", "icon", "loading", "buttonProps", "severity"] }, { kind: "ngmodule", type: RippleModule }, { kind: "directive", type: i6.Ripple, selector: "[pRipple]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ExportDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-export-dialog", imports: [
                        DialogModule,
                        SharedModule,
                        CardModule,
                        SelectButtonModule,
                        FormsModule,
                        ButtonModule,
                        RippleModule,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<p-dialog [visible]=\"visible()\"\n  [style]=\"{width: '450px'}\"\n  [header]=\"labels.exportDialog.header\"\n  [modal]=\"true\"\n  styleClass=\"p-fluid\"\n  (visibleChange)=\"$event ? false : onHide()\"\n  (onHide)=\"onHide()\">\n  <ng-template pTemplate=\"content\">\n    <div class=\"container\">\n      <span class=\"label\">{{ labels.exportDialog.chooseFormat }}</span>\n      <p-selectButton\n        [options]=\"formats()\"\n        [(ngModel)]=\"format\"\n        optionLabel=\"label\"\n        optionValue=\"value\"\n      />\n    </div>\n\n    <div class=\"container\">\n      <span class=\"label\">{{ labels.exportDialog.chooseData }}</span>\n      <p-selectButton\n        [options]=\"selectionOptions()\"\n        [(ngModel)]=\"selection\"\n        optionLabel=\"label\"\n        optionValue=\"value\"\n      />\n    </div>\n  </ng-template>\n\n  <ng-template pTemplate=\"footer\">\n    <button pButton\n      pRipple\n      [label]=\"labels.exportDialog.cancel\"\n      icon=\"pi pi-times\"\n      class=\"p-button-text\"\n      (click)=\"onHide()\">\n    </button>\n\n    <button pButton\n      pRipple\n      [label]=\"labels.exportDialog.export\"\n      icon=\"pi pi-check\"\n      class=\"p-button-success\"\n      [loading]=\"isLoading()\"      \n      (click)=\"onExport()\">\n    </button>\n  </ng-template>\n</p-dialog>\n", styles: [".container{display:flex;flex-direction:column;margin-bottom:1rem}.container .label{font-weight:700;margin-bottom:1rem}\n"] }]
        }], propDecorators: { visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: true }] }], cols: [{ type: i0.Input, args: [{ isSignal: true, alias: "cols", required: true }] }], isExcelExportEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isExcelExportEnabled", required: true }] }], isCsvExportEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isCsvExportEnabled", required: true }] }], hide: [{ type: i0.Output, args: ["hide"] }], export: [{ type: i0.Output, args: ["export"] }] } });

class TableToolbarComponent {
    labels = inject(CRUD_LABELS);
    selectedEntries = input.required(...(ngDevMode ? [{ debugName: "selectedEntries" }] : /* istanbul ignore next */ []));
    features = input.required(...(ngDevMode ? [{ debugName: "features" }] : /* istanbul ignore next */ []));
    selectable = input.required(...(ngDevMode ? [{ debugName: "selectable" }] : /* istanbul ignore next */ []));
    areColumnsConfigurable = input.required(...(ngDevMode ? [{ debugName: "areColumnsConfigurable" }] : /* istanbul ignore next */ []));
    tableTitle = input.required(...(ngDevMode ? [{ debugName: "tableTitle" }] : /* istanbul ignore next */ []));
    cols = input.required(...(ngDevMode ? [{ debugName: "cols" }] : /* istanbul ignore next */ []));
    isExcelExportEnabled = input.required(...(ngDevMode ? [{ debugName: "isExcelExportEnabled" }] : /* istanbul ignore next */ []));
    isCsvExportEnabled = input.required(...(ngDevMode ? [{ debugName: "isCsvExportEnabled" }] : /* istanbul ignore next */ []));
    isExportDialogVisible = model.required(...(ngDevMode ? [{ debugName: "isExportDialogVisible" }] : /* istanbul ignore next */ []));
    isExportingData = input(false, ...(ngDevMode ? [{ debugName: "isExportingData" }] : /* istanbul ignore next */ []));
    archiveManyClicked = output();
    restoreMultipleClicked = output();
    manageColumnsClicked = output();
    newClicked = output();
    refreshDataClicked = output();
    exportClicked = output();
    isExportEnabled = computed(() => {
        return ((this.isExcelExportEnabled() || this.isCsvExportEnabled()) &&
            !this.isExportingData());
    }, ...(ngDevMode ? [{ debugName: "isExportEnabled" }] : /* istanbul ignore next */ []));
    isToolbarDisplayed = computed(() => {
        const { archive: deleteFeature, create, restore } = this.features();
        const canMultiDelete = deleteFeature && this.selectable();
        return this.areColumnsConfigurable() || canMultiDelete || create || restore;
    }, ...(ngDevMode ? [{ debugName: "isToolbarDisplayed" }] : /* istanbul ignore next */ []));
    onDeleteMultiple() {
        this.archiveManyClicked.emit();
    }
    onRestoreMultiple() {
        this.restoreMultipleClicked.emit();
    }
    manageColumns() {
        this.manageColumnsClicked.emit();
    }
    onNew() {
        this.newClicked.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableToolbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableToolbarComponent, isStandalone: true, selector: "tbl-table-toolbar", inputs: { selectedEntries: { classPropertyName: "selectedEntries", publicName: "selectedEntries", isSignal: true, isRequired: true, transformFunction: null }, features: { classPropertyName: "features", publicName: "features", isSignal: true, isRequired: true, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: true, transformFunction: null }, areColumnsConfigurable: { classPropertyName: "areColumnsConfigurable", publicName: "areColumnsConfigurable", isSignal: true, isRequired: true, transformFunction: null }, tableTitle: { classPropertyName: "tableTitle", publicName: "tableTitle", isSignal: true, isRequired: true, transformFunction: null }, cols: { classPropertyName: "cols", publicName: "cols", isSignal: true, isRequired: true, transformFunction: null }, isExcelExportEnabled: { classPropertyName: "isExcelExportEnabled", publicName: "isExcelExportEnabled", isSignal: true, isRequired: true, transformFunction: null }, isCsvExportEnabled: { classPropertyName: "isCsvExportEnabled", publicName: "isCsvExportEnabled", isSignal: true, isRequired: true, transformFunction: null }, isExportDialogVisible: { classPropertyName: "isExportDialogVisible", publicName: "isExportDialogVisible", isSignal: true, isRequired: true, transformFunction: null }, isExportingData: { classPropertyName: "isExportingData", publicName: "isExportingData", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { isExportDialogVisible: "isExportDialogVisibleChange", archiveManyClicked: "archiveManyClicked", restoreMultipleClicked: "restoreMultipleClicked", manageColumnsClicked: "manageColumnsClicked", newClicked: "newClicked", refreshDataClicked: "refreshDataClicked", exportClicked: "exportClicked" }, ngImport: i0, template: "<p-toolbar id=\"table-toolbar\">\n  <ng-template pTemplate=\"left\">\n    <span class=\"toolbar-title\"> {{ tableTitle() }} </span>\n  </ng-template>\n\n  <ng-template pTemplate=\"right\">\n    <p-buttonGroup class=\"button-group\">\n      @if (features().create) {\n        <button\n          pButton\n          pRipple\n          icon=\"pi pi-plus\"\n          (click)=\"onNew()\">\n        </button>\n      }\n      @if (isExportEnabled()) {\n        <button pButton pRipple\n          [title]=\"labels.toolbar.export\"\n          [icon]=\"isExportingData() ? 'pi pi-spinner pi-spin' :'pi pi-download'\"\n          (click)=\"isExportDialogVisible.set(true)\"\n          [disabled]=\"isExportingData()\">\n        </button>\n      }\n      @if (selectable() && features().archive) {\n        <button\n          pButton\n          pRipple\n          icon=\"pi pi-trash\"\n          (click)=\"onDeleteMultiple()\"\n          [disabled]=\"!selectedEntries() || !selectedEntries().length\">\n        </button>\n      }\n      @if (areColumnsConfigurable()) {\n        <button pButton pRipple\n          icon=\"pi pi-cog\"\n          (click)=\"manageColumns()\"\n          [title]=\"labels.toolbar.configureColumns\">\n        </button>\n      }\n\n      <button pButton pRipple\n        icon=\"pi pi-refresh\"\n        (click)=\"refreshDataClicked.emit()\"\n        [title]=\"labels.toolbar.refresh\">\n      </button>\n    </p-buttonGroup>\n  </ng-template>\n</p-toolbar>\n\n\n<tbl-export-dialog \n  [visible]=\"isExportDialogVisible()\"\n  [isExcelExportEnabled]=\"isExcelExportEnabled()\"\n  [isCsvExportEnabled]=\"isCsvExportEnabled()\"\n  [cols]=\"cols()\"\n  (hide)=\"isExportDialogVisible.set(false)\"\n  (export)=\"exportClicked.emit($event)\"\n/>", styles: ["p-toolbar{margin:0 .25rem;padding:2px 12px;border:0}\n"], dependencies: [{ kind: "ngmodule", type: ToolbarModule }, { kind: "component", type: i1$g.Toolbar, selector: "p-toolbar", inputs: ["styleClass", "ariaLabelledBy"] }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: ButtonModule }, { kind: "directive", type: i1.ButtonDirective, selector: "[pButton]", inputs: ["ptButtonDirective", "pButtonPT", "pButtonUnstyled", "hostName", "text", "plain", "raised", "size", "outlined", "rounded", "iconPos", "loadingIcon", "fluid", "label", "icon", "loading", "buttonProps", "severity"] }, { kind: "ngmodule", type: FileUploadModule }, { kind: "component", type: ExportDialogComponent, selector: "tbl-export-dialog", inputs: ["visible", "cols", "isExcelExportEnabled", "isCsvExportEnabled"], outputs: ["hide", "export"] }, { kind: "ngmodule", type: ButtonGroupModule }, { kind: "component", type: i4$1.ButtonGroup, selector: "p-buttonGroup, p-buttongroup, p-button-group" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-table-toolbar", imports: [
                        ToolbarModule,
                        SharedModule,
                        ButtonModule,
                        FileUploadModule,
                        ExportDialogComponent,
                        ButtonGroupModule,
                    ], template: "<p-toolbar id=\"table-toolbar\">\n  <ng-template pTemplate=\"left\">\n    <span class=\"toolbar-title\"> {{ tableTitle() }} </span>\n  </ng-template>\n\n  <ng-template pTemplate=\"right\">\n    <p-buttonGroup class=\"button-group\">\n      @if (features().create) {\n        <button\n          pButton\n          pRipple\n          icon=\"pi pi-plus\"\n          (click)=\"onNew()\">\n        </button>\n      }\n      @if (isExportEnabled()) {\n        <button pButton pRipple\n          [title]=\"labels.toolbar.export\"\n          [icon]=\"isExportingData() ? 'pi pi-spinner pi-spin' :'pi pi-download'\"\n          (click)=\"isExportDialogVisible.set(true)\"\n          [disabled]=\"isExportingData()\">\n        </button>\n      }\n      @if (selectable() && features().archive) {\n        <button\n          pButton\n          pRipple\n          icon=\"pi pi-trash\"\n          (click)=\"onDeleteMultiple()\"\n          [disabled]=\"!selectedEntries() || !selectedEntries().length\">\n        </button>\n      }\n      @if (areColumnsConfigurable()) {\n        <button pButton pRipple\n          icon=\"pi pi-cog\"\n          (click)=\"manageColumns()\"\n          [title]=\"labels.toolbar.configureColumns\">\n        </button>\n      }\n\n      <button pButton pRipple\n        icon=\"pi pi-refresh\"\n        (click)=\"refreshDataClicked.emit()\"\n        [title]=\"labels.toolbar.refresh\">\n      </button>\n    </p-buttonGroup>\n  </ng-template>\n</p-toolbar>\n\n\n<tbl-export-dialog \n  [visible]=\"isExportDialogVisible()\"\n  [isExcelExportEnabled]=\"isExcelExportEnabled()\"\n  [isCsvExportEnabled]=\"isCsvExportEnabled()\"\n  [cols]=\"cols()\"\n  (hide)=\"isExportDialogVisible.set(false)\"\n  (export)=\"exportClicked.emit($event)\"\n/>", styles: ["p-toolbar{margin:0 .25rem;padding:2px 12px;border:0}\n"] }]
        }], propDecorators: { selectedEntries: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedEntries", required: true }] }], features: [{ type: i0.Input, args: [{ isSignal: true, alias: "features", required: true }] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: true }] }], areColumnsConfigurable: [{ type: i0.Input, args: [{ isSignal: true, alias: "areColumnsConfigurable", required: true }] }], tableTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableTitle", required: true }] }], cols: [{ type: i0.Input, args: [{ isSignal: true, alias: "cols", required: true }] }], isExcelExportEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isExcelExportEnabled", required: true }] }], isCsvExportEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isCsvExportEnabled", required: true }] }], isExportDialogVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "isExportDialogVisible", required: true }] }, { type: i0.Output, args: ["isExportDialogVisibleChange"] }], isExportingData: [{ type: i0.Input, args: [{ isSignal: true, alias: "isExportingData", required: false }] }], archiveManyClicked: [{ type: i0.Output, args: ["archiveManyClicked"] }], restoreMultipleClicked: [{ type: i0.Output, args: ["restoreMultipleClicked"] }], manageColumnsClicked: [{ type: i0.Output, args: ["manageColumnsClicked"] }], newClicked: [{ type: i0.Output, args: ["newClicked"] }], refreshDataClicked: [{ type: i0.Output, args: ["refreshDataClicked"] }], exportClicked: [{ type: i0.Output, args: ["exportClicked"] }] } });

class ExcelService {
    labels = inject(CRUD_LABELS);
    generateExcel(data, excelParams) {
        const workbook = new ExcelJS.Workbook();
        const { fileName, sheetName, columns } = excelParams;
        const worksheet = workbook.addWorksheet(sheetName);
        // Add headers
        const headers = [];
        for (const col in columns) {
            headers.push(columns[col].label);
        }
        worksheet.addRow(headers);
        // Add data
        for (const item of data) {
            const row = [];
            for (const col in columns) {
                const cellValue = item[col];
                let renderedValue = new CellTextContent({
                    cellValue,
                    options: columns[col],
                    checkboxLabels: this.labels.checkbox,
                }).value;
                if (isValidDateString(cellValue)) {
                    renderedValue = formatDate(renderedValue);
                }
                row.push(renderedValue);
            }
            worksheet.addRow(row);
        }
        return from(workbook.xlsx.writeBuffer()).pipe(tap((buffer) => {
            const blob = new Blob([buffer], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            });
            saveAs$1(blob, `${fileName}.xlsx`);
        }), map(() => true), catchError(() => of(false)));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ExcelService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ExcelService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ExcelService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: "root",
                }]
        }] });

class LocalTableColumnsStorage {
    localStorageService = inject(LocalStorageService);
    tablesStorageKey = inject(APP_CONFIG).storageKeys.TABLE_CONFIG;
    _configs = {};
    get configs() {
        return this._configs ?? {};
    }
    constructor() {
        this.init();
    }
    set(tableKey, columns) {
        const tableConfig = columns
            .filter((col) => !col.isHardHidden)
            .map((col) => ({
            key: col.key,
            isVisible: col.isVisible,
        }));
        this._configs[tableKey] = tableConfig;
        this.localStorageService.setItem(this.tablesStorageKey, JSON.stringify(this._configs));
    }
    getColumns(tableKey, baseConfig) {
        return this.configs[tableKey] ?? baseConfig ?? [];
    }
    init() {
        const config = this.localStorageService.getItem(this.tablesStorageKey);
        if (config) {
            this._configs = JSON.parse(config);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocalTableColumnsStorage, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocalTableColumnsStorage, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: LocalTableColumnsStorage, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }], ctorParameters: () => [] });

class TableColumnsStorage {
    preferencesService = inject(TableConfigService);
    localTableColumnsStorage = inject(LocalTableColumnsStorage);
    labels = inject(CRUD_LABELS);
    /**
     * When the service is init, we need to get the views
     * Then we need to compute the full column config for each view
     * Finally we need to know which view is the active view
     * Now we can expose "columns" to the table
     */
    baseCrudItems = signal([], ...(ngDevMode ? [{ debugName: "baseCrudItems" }] : /* istanbul ignore next */ []));
    componentId = signal(null, ...(ngDevMode ? [{ debugName: "componentId" }] : /* istanbul ignore next */ []));
    isViewSystemEnabled = signal(true, ...(ngDevMode ? [{ debugName: "isViewSystemEnabled" }] : /* istanbul ignore next */ []));
    views$ = combineLatest([
        toObservable(this.componentId),
        toObservable(this.baseCrudItems),
    ]).pipe(map(([componentId]) => componentId), filter((componentId) => !!componentId), switchMap((componentId) => this.getMany(componentId)), takeUntilDestroyed());
    viewsWithColumns$ = this.views$.pipe(map((views) => this.getViewsWithColumns(views)), tap((viewsWithColumns) => {
        this.viewsWithColumns.set(viewsWithColumns);
        const activeView = viewsWithColumns.find((view) => view.isActive);
        this.activeColumns.set(activeView ? activeView.columns : []);
    }));
    /**
     * Exposed signals
     */
    viewsWithColumns = signal(null, ...(ngDevMode ? [{ debugName: "viewsWithColumns" }] : /* istanbul ignore next */ []));
    activeColumns = signal([], ...(ngDevMode ? [{ debugName: "activeColumns" }] : /* istanbul ignore next */ []));
    /**
     * Initialize the table views service
     * @param componentId {string} Component identifier to query and post stored configurations
     * @param baseCrudItems {CrudItemOptions[]} Base columns configuration from CRUD definition
     * @param isViewSystemEnabled {boolean} Whether the view system is enabled or not
     * This method must be called by the table component in order to initialize the columns
     */
    init(componentId, baseCrudItems, isViewSystemEnabled) {
        this.componentId.set(componentId);
        this.baseCrudItems.set(baseCrudItems);
        this.isViewSystemEnabled.set(isViewSystemEnabled);
        this.viewsWithColumns$.subscribe();
    }
    /*** Backend communication ***/
    updateMany(views) {
        const componentId = this.componentId();
        if (!componentId)
            return of([]);
        const defaultView = views[0];
        if (!this.isViewSystemEnabled() && defaultView) {
            this.localTableColumnsStorage.set(componentId, defaultView.columns);
            this.activeColumns.set(defaultView.columns);
            return of(views);
        }
        const cleanViews = views.map((view) => ({
            ...view,
            id: view.isCreation || view.id === null ? undefined : view.id,
            isCreation: undefined,
            columns: undefined,
        }));
        return this.preferencesService
            .updateMany(componentId, cleanViews)
            .pipe(switchMap(() => this.viewsWithColumns$));
    }
    /** Called when a single column is resized */
    updateOne(updatedColumn) {
        const componentViews = this.viewsWithColumns()?.map((view) => {
            if (view.isActive) {
                const updatedConf = view.conf.map((col) => col.key === updatedColumn.colKey
                    ? { ...col, defaultWidth: `${updatedColumn.newWidthPx}px` }
                    : col);
                return { ...view, conf: updatedConf };
            }
            return view;
        });
        if (!componentViews) {
            return of([]);
        }
        return this.updateMany(componentViews);
    }
    getMany(componentId) {
        if (!this.isViewSystemEnabled()) {
            return of([]);
        }
        return this.preferencesService.getViews(componentId);
    }
    /**
     * Full columns computation
     */
    getViewsWithColumns(views) {
        const baseCrudItems = this.baseCrudItems();
        if (!baseCrudItems) {
            return [];
        }
        const componentId = this.componentId();
        if (!componentId) {
            return [];
        }
        // Retrieve local storage config if view system is disabled
        const localConfig = this.localTableColumnsStorage.getColumns(componentId, baseCrudItems);
        const columns = this.getOrderedColumns(baseCrudItems, localConfig);
        this.activeColumns.set(columns);
        const defaultView = {
            ...new TableConfig(componentId, this.labels.table.defaultViewName),
            columns,
            isActive: true,
        };
        if (!this.isViewSystemEnabled()) {
            return [defaultView];
        }
        if (views.length === 0) {
            return [{ ...defaultView, locked: true }];
        }
        // Otherwise, the config will come from the view preferences
        const userViews = views
            .toSorted((a, b) => a.name.localeCompare(b.name))
            .map((view) => {
            const userConf = view.conf ?? [];
            const isObsoleteConf = userConf.length !== baseCrudItems.length;
            const columns = isObsoleteConf
                ? baseCrudItems.map((item) => crudItemToColumn(item, userConf))
                : this.getOrderedColumns(baseCrudItems, userConf);
            return {
                ...view,
                columns,
            };
        });
        return userViews;
    }
    getOrderedColumns(baseColumns, userConfig) {
        return userConfig
            .map((col) => {
            const fullColumn = baseColumns.find(
            // biome-ignore lint/suspicious/noDoubleEquals: key may be number or string
            (colConfig) => colConfig.key == col.key);
            if (!fullColumn) {
                return null;
            }
            return crudItemToColumn(fullColumn, userConfig);
        })
            .filter((col) => col !== null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableColumnsStorage, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableColumnsStorage });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableColumnsStorage, decorators: [{
            type: Injectable
        }] });

class ExportService {
    locationInterceptorService = inject(LocationInterceptorService);
    excelService = inject(ExcelService);
    state = inject(TableStateService);
    tableViewsService = inject(TableColumnsStorage);
    http = inject(HttpClient);
    labels = inject(CRUD_LABELS);
    isExportingData = signal(false, ...(ngDevMode ? [{ debugName: "isExportingData" }] : /* istanbul ignore next */ []));
    columns = this.tableViewsService.activeColumns;
    params = computed(() => this.state.state().currentParams, ...(ngDevMode ? [{ debugName: "params" }] : /* istanbul ignore next */ []));
    getCall = () => of(NO_ROWS_AND_COUNT);
    export(options, getCall) {
        this.state.setCurrentTime();
        this.getCall = getCall ?? (() => of(NO_ROWS_AND_COUNT));
        const { format, selection } = options;
        if (format === "csv") {
            return this.exportCsv(selection);
        }
        return this.exportToXls(selection);
    }
    exportToXls(selection) {
        this.isExportingData.set(true);
        const columns = this.columns()
            .filter((col) => this.shouldExportColumn(selection, col))
            .reduce((acc, curr) => {
            acc[curr.key] = curr;
            return acc;
        }, {});
        return this.exportXls(selection, {
            columns,
            fileName: this.state.state().fileName,
            sheetName: this.state.state().entityLabel,
        }, this.state.state().excelExportMode);
    }
    /**
     * Return true if a column should be exported.
     * In all mode, we export all columns that are not hard hidden.
     * In filtered mode, we export all visibles column.
     * A column will never be exported if ignoreOnExport is true
     * @param selection the export mode
     * @param col the column that we want to check
     * @returns true if the column should be exported
     */
    shouldExportColumn(selection, col) {
        return (!col.ignoreOnExport &&
            ((selection === "filtered" && col.isVisible) ||
                (selection === "all" && !col.isHardHidden)));
    }
    exportXls(selection, excelParams, exportMode) {
        const params = this.params();
        if (!params)
            return of(false);
        const payload = selection === "filtered"
            ? params
            : {
                ...params,
                rows: undefined,
                first: undefined,
                last: undefined,
                filters: {},
            };
        const serverCall$ = this.getCall({
            ...payload,
            excel: excelParams,
        }).pipe(map(() => this.locationInterceptorService.consumeLocation()), switchMap((location) => {
            if (!location)
                throw of(throwError(() => { }));
            return this.tryDownloadXls(location);
        }), tap(() => {
            this.isExportingData.set(false);
        }), map(() => true), catchError(() => of(false)));
        const localCall$ = (this.state.state().lazy
            ? this.getCall(payload)
            : of({ rows: this.state.state().data })).pipe(switchMap((res) => this.excelService.generateExcel(res.rows, excelParams)));
        if (exportMode === "local") {
            return localCall$;
        }
        this.locationInterceptorService.enableLocationHeaderWaiting();
        return serverCall$;
    }
    /**
     * Downloads an Excel file from the given location and saves it locally.
     * If the file is not found, it retries the download up to 5 times with a
     * 2 second delay between each try.
     *
     * @param location the URL of the Excel file to download
     * @returns an Observable that emits nothing
     * @throws an error if the file is not found after the maximum number of retries
     */
    tryDownloadXls(location) {
        const delayBetweenTries = 2000;
        const maxRetry = 5;
        return this.http.get(location, { responseType: "blob" }).pipe(delay(delayBetweenTries), tap((data) => {
            if (!data) {
                throw throwError(data);
            }
            const blob = new Blob([data], {
                type: data.type,
            });
            const fileName = location.split("/").pop();
            saveAs(blob, fileName);
        }), retry(maxRetry));
    }
    exportCsv(selection) {
        const { fileName } = this.state.state();
        const columns = this.columns();
        return this.getCall({
            rows: null,
            filters: selection === "filtered" ? this.params()?.filters : undefined,
        }).pipe(tap((data) => {
            if (!data)
                return;
            let customLabels = {};
            const visibleColumns = selection === "filtered"
                ? columns.filter((item) => item.isVisible)
                : columns;
            for (const param of visibleColumns) {
                customLabels = { ...customLabels, [param.key]: param.label };
            }
            const array = data.rows.map((item) => {
                const arrayItems = {};
                for (const key of Object.keys(item)) {
                    const control = visibleColumns.find((item) => item.key === key);
                    if (control) {
                        const stringItem = new CellTextContent({
                            cellValue: item[key],
                            options: control,
                            checkboxLabels: this.labels.checkbox,
                        }).value;
                        arrayItems[key] = stringItem ?? "";
                    }
                }
                return arrayItems;
            });
            Export.data(fileName, array, {
                separator: ";",
                customLabels,
            });
        }), map(() => true), catchError(() => of(false)));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ExportService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ExportService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: ExportService, decorators: [{
            type: Injectable
        }] });

function cleanFilters(params) {
    if (!params) {
        return;
    }
    const cleanParams = JSON.parse(JSON.stringify(params));
    if (!cleanParams.filters) {
        return;
    }
    for (const key of Object.keys(cleanParams.filters)) {
        const filter = cleanParams.filters[key];
        if (!filter) {
            continue;
        }
        if (isFilterNull(filter)) {
            delete cleanParams.filters[key];
        }
        if (!isValueArray(filter) && isDateRangeFilter(filter)) {
            filter.value = getDateRangeWithoutTime(filter.value);
        }
    }
    return cleanParams;
}
function isValueArray(filter) {
    return isArray(filter);
}
function isFilterNull(filter) {
    const isArrayFilter = isValueArray(filter);
    const isFilterNull = (isArrayFilter && filter[0].value === null) ||
        (!isArrayFilter && filter?.value === null);
    return isFilterNull;
}
function isDateRangeFilter(filter) {
    return filter.matchMode === "dateRange" && filter.value?.length;
}

/**
 * Function to return the default filter value if define in the conf
 * @returns An object containing the default filters for the table
 */
function getFilters(items, filterLevel) {
    return items.reduce((filters, item) => {
        if (item.columnOptions?.defaultFilter) {
            const filter = item.columnOptions.defaultFilter;
            return {
                // biome-ignore lint/performance/noAccumulatingSpread: this is the behavior we want
                ...filters,
                [item.key]: filterLevel === "advanced" && !isArray(filter) ? [filter] : filter,
            };
        }
        return filters;
    }, {});
}
function applyDefaultFilters(currentFilters, defaultFilters) {
    const newFilters = { ...currentFilters };
    for (const filter in defaultFilters) {
        const defaultFilterMeta = defaultFilters[filter];
        if (!defaultFilterMeta)
            continue;
        const eventFilterMeta = currentFilters?.[filter];
        const isArrayFilter = isArray(eventFilterMeta);
        // array filter (advanced filtering mode)
        if (isArrayFilter) {
            const hasValue = eventFilterMeta.some((v) => !isNil(v.value));
            if (hasValue)
                continue; // do nothing if any value is set
            newFilters[filter] = isArray(defaultFilterMeta)
                ? defaultFilterMeta
                : [defaultFilterMeta];
        }
        else {
            // simple object value (basic filtering mode)
            const hasValue = !isNil(eventFilterMeta?.value);
            if (hasValue)
                continue; // do nothing if value is set
            newFilters[filter] = defaultFilterMeta;
        }
    }
    return newFilters;
}

function getDefaultSort(items) {
    return items.reduce((acc, item) => {
        if (item.columnOptions?.defaultSortField) {
            acc.field = item.key;
            acc.order = item.columnOptions.defaultSortOrder ?? 1;
        }
        return acc;
    }, { field: "", order: 1 });
}
function applyDefaultSort(currentSort, defaultSort) {
    if ((!currentSort || !currentSort.field) &&
        defaultSort &&
        defaultSort.field) {
        return defaultSort;
    }
    return currentSort;
}

class TableComponent {
    // Injected services
    confirmationService = inject(ConfirmationService);
    exportService = inject(ExportService);
    loader = inject((CrudLoader));
    loadingService = inject(TableLoadingService);
    route = inject(ActivatedRoute);
    router = inject(Router);
    state = inject(TableStateService);
    columnsStorage = inject(TableColumnsStorage);
    messageService = inject(MessageService);
    labels = inject(CRUD_LABELS);
    // Inputs
    /**
     * Controls whether columns can be hidden/shown through the configuration dialog.
     * When enabled, shows a gear icon in the toolbar allowing users to manage column visibility.
     * Persists user preferences in localStorage based on entityId.
     */
    areColumnsConfigurable = input(true, ...(ngDevMode ? [{ debugName: "areColumnsConfigurable" }] : /* istanbul ignore next */ []));
    /** Determines whether table columns can be resized by the user */
    areColumnsResizable = input(true, ...(ngDevMode ? [{ debugName: "areColumnsResizable" }] : /* istanbul ignore next */ []));
    /**
     * Enables deep linking to specific items by adding their ID to the URL query parameters.
     * When enabled, editing an item will add ?id=123 to the URL, allowing direct access to the edition dialog.
     * Useful for bookmarking or sharing links to specific items.
     */
    canAccessItemFromUrl = input(false, ...(ngDevMode ? [{ debugName: "canAccessItemFromUrl" }] : /* istanbul ignore next */ []));
    /**
     * Determines user interaction mode with table rows.
     * When true, clicking anywhere on a row opens the edition dialog.
     * When false, only action buttons in the actions column trigger edition.
     * Affects user experience and accessibility.
     */
    clickableRows = input(true, ...(ngDevMode ? [{ debugName: "clickableRows" }] : /* istanbul ignore next */ []));
    /**
     * Defines the structure and behavior of table columns and form fields.
     * Each CrudItemOptions object represents a column/field with display rules, validation, and control type.
     * This is the core configuration that drives both table display and form generation.
     */
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /**
     * Custom template for actions in the table's action column.
     * Allows injection of custom buttons or controls
     * The template receives the current row data as context, enabling dynamic action visibility.
     * Actions are displayed in place of the standard CRUD actions (edit, delete) in the actions column.
     */
    customActionsTemplate = input(...(ngDevMode ? [undefined, { debugName: "customActionsTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Applies conditional CSS styles to table rows based on row data.
     * Function receives row data and returns CSS properties object.
     * Useful for highlighting specific rows, status indication, or visual categorization.
     */
    customRowStyles = input(...(ngDevMode ? [undefined, { debugName: "customRowStyles" }] : /* istanbul ignore next */ []));
    /**
     * Forces read-only mode on the edition dialog when a row matches one of the provided property/value pairs.
     * Each key-value entry is checked against the clicked row: if any matches, the dialog opens in read-only mode instead of edit mode.
     * Takes precedence over the normal edit/write mode resolution.
     * @example { active: false } — opens inactive users in read-only mode
     */
    additionalReadonlyProperties = input(...(ngDevMode ? [undefined, { debugName: "additionalReadonlyProperties" }] : /* istanbul ignore next */ []));
    /**
     * Factory function that creates new entity instances for the creation dialog.
     * Must return an object with default values matching your entity structure.
     * Called when user clicks "New" button to populate the form with initial values.
     */
    entityFactory = input.required(...(ngDevMode ? [{ debugName: "entityFactory" }] : /* istanbul ignore next */ []));
    /**
     * Unique identifier for the entity type, used for persisting column preferences.
     * Should be consistent across the application for the same entity type.
     * Used as localStorage key for saving column visibility and order preferences.
     */
    entityId = input.required(...(ngDevMode ? [{ debugName: "entityId" }] : /* istanbul ignore next */ []));
    /**
     * Human-readable label for a single entity instance.
     * Used in dialog titles, confirmation messages, and form labels.
     * Should be singular form (not plural) for grammatical correctness.
     */
    entityLabel = input("", ...(ngDevMode ? [{ debugName: "entityLabel" }] : /* istanbul ignore next */ []));
    /**
     * Custom title for the edition dialog, overriding the default generated title.
     * When not provided, title is auto-generated as "Creation - {entityLabel}" or "Edition - {entityLabel}".
     * Useful for specific workflows or when default title doesn't fit the context.
     */
    editionDialogTitle = input("", ...(ngDevMode ? [{ debugName: "editionDialogTitle" }] : /* istanbul ignore next */ []));
    /** Width of the edition dialog
     * Sets the width of the edition/creation dialog modal.
     * Accepts any valid CSS width value (px, %, vw, etc.).
     * Larger dialogs are better for complex forms with many fields.
     * @default undefined
     * @example "50vw"
     * Will override 'editionDialogSize' if specified */
    editionDialogWidth = input(...(ngDevMode ? [undefined, { debugName: "editionDialogWidth" }] : /* istanbul ignore next */ []));
    /**
     * Sets the size of the edition/creation dialog modal.
     * Accepts "xs" (1 col), "s" (2 cols), "m" (3 cols), or "l" (4 cols) for small, medium, or large predefined sizes.
     * @default "s"
     * */
    editionDialogSize = input("s", ...(ngDevMode ? [{ debugName: "editionDialogSize" }] : /* istanbul ignore next */ []));
    /** Height of the edition dialog - defaults to undefined */
    editionDialogHeight = input(...(ngDevMode ? [undefined, { debugName: "editionDialogHeight" }] : /* istanbul ignore next */ []));
    /**
     * Determines how Excel export is processed - locally in browser or on server.
     * Local export is faster but limited by browser memory and capabilities.
     * Server export handles large datasets and complex formatting but requires backend support.
     */
    excelExportMode = input("server", ...(ngDevMode ? [{ debugName: "excelExportMode" }] : /* istanbul ignore next */ []));
    /**
     * Enables/disables column filtering functionality in the table.
     * When enabled, shows filter inputs in column headers allowing users to search/filter data.
     * Filter behavior depends on filterLevel setting.
     */
    filterable = input(true, ...(ngDevMode ? [{ debugName: "filterable" }] : /* istanbul ignore next */ []));
    /**
     * Defines the complexity level of filtering interface.
     * Controls what type of filter controls are shown and how they behave.
     * Higher levels provide more sophisticated filtering options.
     */
    filterLevel = input("basic", ...(ngDevMode ? [{ debugName: "filterLevel" }] : /* istanbul ignore next */ []));
    /**
     * Trigger for forcing table data reload from parent component.
     * Increment this value to trigger a reload. The actual value doesn't matter, only changes.
     * Useful for refreshing data after external operations or on specific events.
     */
    forceReload = input(...(ngDevMode ? [undefined, { debugName: "forceReload" }] : /* istanbul ignore next */ []));
    /**
     * Custom validator function applied to the entire form group in edition dialog.
     * Receives the FormGroup and returns validation errors object or null.
     * Useful for cross-field validation, business rules, or complex validation logic.
     */
    groupValidator = input(...(ngDevMode ? [undefined, { debugName: "groupValidator" }] : /* istanbul ignore next */ []));
    /**
     * Configuration object containing all HTTP operations for CRUD functionality.
     * Defines how the table communicates with your backend API for data operations.
     * Each operation is optional - omit unsupported operations to hide related UI elements.
     */
    httpCalls = input.required(...(ngDevMode ? [{ debugName: "httpCalls" }] : /* istanbul ignore next */ []));
    /**
     * Enables the context menu on right-clicking table rows.
     * When enabled, right-clicking a row shows a context menu with actions like View and Edit.
     * Context menu actions emit the same events as clicking the row or action buttons.
     * Useful for providing quick access to common actions without cluttering the UI.
     * @default false
     */
    isContextMenuEnabled = input(false, ...(ngDevMode ? [{ debugName: "isContextMenuEnabled" }] : /* istanbul ignore next */ []));
    /**
     * Enables CSV export functionality in the table toolbar.
     * When enabled, shows a CSV export button allowing users to download table data as CSV file.
     * Export includes all visible columns with current filters and sorting applied.
     */
    isCsvExportEnabled = input(true, ...(ngDevMode ? [{ debugName: "isCsvExportEnabled" }] : /* istanbul ignore next */ []));
    /**
     * Disables the default edition modal dialog, allowing custom edition handling.
     * When disabled, clicking edit buttons or rows will only emit events without showing the dialog.
     * Use this when you need custom edit behavior or external editing components.
     */
    isDefaultEditionDisabled = input(false, ...(ngDevMode ? [{ debugName: "isDefaultEditionDisabled" }] : /* istanbul ignore next */ []));
    /**
     * Enables Excel export functionality in the table toolbar.
     * When enabled, shows an Excel export button for downloading data as .xlsx file.
     * Excel export supports better formatting and larger datasets than CSV.
     */
    isExcelExportEnabled = input(false, ...(ngDevMode ? [{ debugName: "isExcelExportEnabled" }] : /* istanbul ignore next */ []));
    /**
     * Enables preferences mode for the table.
     * When enabled, will query configured views from backend and allow user to switch and add new ones.
     * When disabled, only the default view is used without any view management options.
     */
    isPreferencesModeEnabled = input(false, ...(ngDevMode ? [{ debugName: "isPreferencesModeEnabled" }] : /* istanbul ignore next */ []));
    /** Strategy for generating labels for form controls */
    labelStrategy = input("ifta", ...(ngDevMode ? [{ debugName: "labelStrategy" }] : /* istanbul ignore next */ []));
    /** Variant for the label strategy. Will be applied for float labels */
    labelStrategyVariant = input("on", ...(ngDevMode ? [{ debugName: "labelStrategyVariant" }] : /* istanbul ignore next */ []));
    /**
     * Enables lazy loading mode for large datasets.
     * When true, data is loaded on-demand as user scrolls, sorts, or filters.
     * When false, all data is loaded at once (suitable for smaller datasets).
     * Improves performance for tables with thousands of rows.
     */
    lazy = input(true, ...(ngDevMode ? [{ debugName: "lazy" }] : /* istanbul ignore next */ []));
    /**
     * Sets the height of the area outside the table (e.g. toolbar, paginator) to allow proper calculation of scrollable area.
     * Accepts any valid CSS height value (px, %, vh, etc.).
     * When not set, defaults to 200px to fit most screens.
     * Adjust this value based on your layout and available screen space.
     * @default "200px"
     * @example "400px"
     * @example "50vh"
     */
    outsideTableHeight = input("200px", ...(ngDevMode ? [{ debugName: "outsideTableHeight" }] : /* istanbul ignore next */ []));
    /**
     * Enables pagination controls at the bottom of the table.
     * When enabled, shows page numbers, page size selector, and navigation controls.
     * Helps manage large datasets by splitting them into manageable pages.
     */
    paginator = input(true, ...(ngDevMode ? [{ debugName: "paginator" }] : /* istanbul ignore next */ []));
    /**
     * Number of rows to display per page when pagination is enabled.
     * Should be a positive integer. Common values are 10, 25, 50, etc.
     * Affects how many rows are shown at once and how pagination behaves.
     */
    rows = input(10, ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    /**
     * Options for page size selection in the pagination controls.
     * Should be an array of positive integers representing page size options.
     * The first value is usually the default page size.
     * Allows users to choose how many rows they want to see per page.
     */
    rowsPerPageOptions = input([10, 25, 50], ...(ngDevMode ? [{ debugName: "rowsPerPageOptions" }] : /* istanbul ignore next */ []));
    /**
     * Enables row selection with checkboxes for bulk operations.
     * When enabled, adds a checkbox column allowing users to select multiple rows.
     * Selected rows are available via selectedEntries property for bulk actions.
     */
    selectable = input(false, ...(ngDevMode ? [{ debugName: "selectable" }] : /* istanbul ignore next */ []));
    /**
     * Enables column sorting functionality in table headers.
     * When enabled, clicking column headers toggles sorting order (asc/desc/none).
     * Individual columns can override this setting via their sortable property.
     */
    sortable = input(true, ...(ngDevMode ? [{ debugName: "sortable" }] : /* istanbul ignore next */ []));
    /**
     * Enables persistence of table state (filters, sorting, pagination) across page reloads.
     * When enabled, state is stored using the storage type defined by `stateStorage`.
     * Disabled by default — set to `true` to opt in to state persistence.
     * @default false
     */
    persistState = input(false, ...(ngDevMode ? [{ debugName: "persistState" }] : /* istanbul ignore next */ []));
    /**
     * Specifies where to store table state (filters, sorting, pagination).
     * Can be "local" for localStorage or "session" for sessionStorage.
     * Persists user preferences across sessions or tabs based on selection.
     * Only applies when `persistState` is `true`.
     * @default "session"
     */
    stateStorage = input("session", ...(ngDevMode ? [{ debugName: "stateStorage" }] : /* istanbul ignore next */ []));
    /**
     * Enables alternating background colors on table rows (zebra striping).
     * When true, odd and even rows will have slightly different background colors,
     * making it easier to visually follow a row across wide tables.
     * When false, all rows share the same background color.
     * Passed down to the underlying TableRegularComponent and its p-table binding.
     * @default true
     */
    stripedRows = input(true, ...(ngDevMode ? [{ debugName: "stripedRows" }] : /* istanbul ignore next */ []));
    /**
     * Display title shown at the top of the table component.
     * Usually plural form of the entity name, appears in the table header/toolbar.
     * Helps users understand what data they're viewing and provides context.
     */
    tableTitle = input.required(...(ngDevMode ? [{ debugName: "tableTitle" }] : /* istanbul ignore next */ []));
    // Outputs
    editionDialogClosed = output();
    formChanged = output();
    newClicked = output();
    rowClicked = output();
    validityChanged = output();
    // template references
    tableRegular = viewChild("table", { ...(ngDevMode ? { debugName: "tableRegular" } : /* istanbul ignore next */ {}), read: TableRegularComponent });
    columns = this.columnsStorage.activeColumns;
    data = computed(() => this.state.state().data, ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    features = this.loader.features;
    isExportingData = this.exportService.isExportingData;
    isLoading = this.loadingService.isLoading;
    total = computed(() => this.state.state().total, ...(ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []));
    views = this.columnsStorage.viewsWithColumns;
    defaultFilters = computed(() => getFilters(this.config(), this.filterLevel()), ...(ngDevMode ? [{ debugName: "defaultFilters" }] : /* istanbul ignore next */ []));
    defaultSort = linkedSignal(() => getDefaultSort(this.config()), ...(ngDevMode ? [{ debugName: "defaultSort" }] : /* istanbul ignore next */ []));
    // effects
    forceCloseDialog = effect(() => {
        const _refresh = this.loader.forceCloseEdition();
        this.hideEditionDialog();
    }, ...(ngDevMode ? [{ debugName: "forceCloseDialog" }] : /* istanbul ignore next */ []));
    // Properties
    ControlType = CONTROL_TYPES;
    editedEntry = null;
    isColumnsConfigDialogDisplayed = signal(false, ...(ngDevMode ? [{ debugName: "isColumnsConfigDialogDisplayed" }] : /* istanbul ignore next */ []));
    isCreation = signal(false, ...(ngDevMode ? [{ debugName: "isCreation" }] : /* istanbul ignore next */ []));
    isEntryEditionDialogDisplayed = signal(false, ...(ngDevMode ? [{ debugName: "isEntryEditionDialogDisplayed" }] : /* istanbul ignore next */ []));
    isReadonly = signal(false, ...(ngDevMode ? [{ debugName: "isReadonly" }] : /* istanbul ignore next */ []));
    isExportDialogVisible = signal(false, ...(ngDevMode ? [{ debugName: "isExportDialogVisible" }] : /* istanbul ignore next */ []));
    lazyLoad$ = new Subject();
    selectedEntries = [];
    debouncedLoad$ = this.lazyLoad$.pipe(debounceTime(300), takeUntilDestroyed());
    ngOnInit() {
        this.loader.set(this.httpCalls());
        this.loader.storeConfig(this.config());
        this.loader.enableFeatures();
        this.state.setStaticInformation({
            lazy: this.lazy(),
            entityLabel: this.entityLabel(),
            excelExportMode: this.excelExportMode(),
        });
        if (this.lazy()) {
            this.debouncedLoad$.subscribe((event) => {
                const params = cleanFilters(event);
                this.loader.load({ params, partial: "false" });
            });
        }
        else {
            this.loader.load();
        }
        this.displayItemEditionModal();
    }
    ngOnChanges(changes) {
        // Force reload
        const { currentValue: reload, previousValue: prevReload, firstChange, } = changes.forceReload ?? {};
        if (firstChange === false && reload !== prevReload) {
            this.loader.load();
        }
        // Config changed
        const { currentValue: config, previousValue: prevConfig } = changes.config ?? {};
        if (!isEqual(config, prevConfig)) {
            const isViewSystemEnabled = this.isPreferencesModeEnabled() && this.areColumnsConfigurable();
            this.columnsStorage.init(this.entityId(), config, isViewSystemEnabled);
        }
    }
    // Public methods
    applyViews(newViews) {
        this.columnsStorage.updateMany(newViews).subscribe(() => {
            this.hideColumnsConfigDialog();
        });
    }
    hideColumnsConfigDialog() {
        this.isColumnsConfigDialogDisplayed.set(false);
    }
    hideEditionDialog() {
        this.editionDialogClosed.emit(this.editedEntry);
        this.isEntryEditionDialogDisplayed.set(false);
        this.isCreation.set(false);
        this.editedEntry = null;
        this.selectedEntries = [];
        this.appendIdToUrl(null);
    }
    onArchive(id) {
        this.handleArchive([id]);
    }
    onArchiveMany() {
        const ids = this.selectedEntries
            .map((entry) => entry.id)
            .filter((id) => !!id);
        this.handleArchive(ids);
    }
    onCellClick({ row, mode, }) {
        if (mode === "read") {
            this.onView(row);
        }
        else {
            this.onEdit(row);
        }
    }
    onEditedEntryArchive(editedEntry) {
        if (!editedEntry || !editedEntry?.id) {
            return;
        }
        this.handleArchive([editedEntry.id]);
    }
    onEditedEntryRestore(editedEntry) {
        if (!editedEntry || !editedEntry?.id) {
            return;
        }
        this.handleRestore([editedEntry.id]);
    }
    onEditedEntryEdit(entry) {
        if (!entry) {
            return;
        }
        this.loader.update(entry).subscribe(() => {
            this.hideEditionDialog();
        });
    }
    onEditedEntrySave(entry) {
        if (!entry) {
            return;
        }
        const action$ = entry.id
            ? this.loader.update(entry)
            : this.loader.create(entry);
        action$
            .pipe(
        // TODO: this might not be the only strategy to update files.
        switchMap((res) => {
            const files = this.getFiles(entry);
            const id = res?.rows[0]?.id || entry.id;
            return this.loader.updateFiles(files, id);
        }))
            .subscribe(() => {
            this.hideEditionDialog();
        });
    }
    onExport(event) {
        this.loadingService.start();
        this.exportService
            .export(event, this.loader.getCall)
            .subscribe((success) => {
            this.loadingService.stop();
            this.isExportDialogVisible.set(false);
            if (!success) {
                this.messageService.add({
                    severity: "error",
                    summary: this.labels.table.exportFailedTitle,
                    detail: this.labels.table.exportFailedDetail,
                });
            }
        });
    }
    onFormChanged(editedData) {
        this.formChanged.emit(editedData);
    }
    onLazyLoad(event) {
        // Apply default filters if they are not already set
        const defaultFilters = this.defaultFilters();
        event.filters = applyDefaultFilters(event.filters, defaultFilters);
        // Apply default sort if not set
        const defaultSort = this.defaultSort();
        const { field, order } = applyDefaultSort({ field: event.sortField, order: event.sortOrder }, defaultSort);
        event.sortField = field;
        event.sortOrder = order;
        this.defaultSort.set({ field, order });
        // Emit the event to trigger data loading
        this.lazyLoad$.next(event);
    }
    onColumnResized(event) {
        this.columnsStorage.updateOne(event).subscribe();
    }
    onNew() {
        this.newClicked.emit();
        if (this.isDefaultEditionDisabled()) {
            return;
        }
        const factory = this.entityFactory();
        if (!factory)
            return;
        this.editedEntry = factory();
        this.isCreation.set(true);
        this.isReadonly.set(false);
        this.isEntryEditionDialogDisplayed.set(true);
    }
    getHistoryForEntry() {
        if (!this.features().update)
            return undefined;
        const readonlyProperties = this.additionalReadonlyProperties();
        const entry = this.editedEntry;
        if (readonlyProperties && entry) {
            const matches = Object.entries(readonlyProperties).some(([key, value]) => entry[key] === value);
            if (matches)
                return undefined;
        }
        return this.httpCalls().getHistory;
    }
    onValidityChanged(validity) {
        this.validityChanged.emit(validity);
    }
    refreshData() {
        this.loader.load();
    }
    showColumnsManagement() {
        this.isColumnsConfigDialogDisplayed.set(true);
    }
    onEdit(rowData) {
        this.rowClicked.emit(rowData);
        if (this.isDefaultEditionDisabled()) {
            return;
        }
        this.editedEntry = { ...rowData };
        this.isReadonly.set(false);
        this.isEntryEditionDialogDisplayed.set(true);
        this.appendIdToUrl(rowData.id);
    }
    onView(rowData) {
        this.rowClicked.emit(rowData);
        if (this.isDefaultEditionDisabled()) {
            return;
        }
        this.editedEntry = { ...rowData };
        this.isReadonly.set(true);
        this.isEntryEditionDialogDisplayed.set(true);
        this.appendIdToUrl(rowData.id);
    }
    // Private methods
    appendIdToUrl(id) {
        if (!this.canAccessItemFromUrl()) {
            return;
        }
        this.router.navigate([], {
            queryParams: { id },
            replaceUrl: true,
        });
    }
    displayItemEditionModal() {
        const id = this.route.snapshot.queryParams.id;
        if (id && this.canAccessItemFromUrl()) {
            const searchParams = { filters: { id: { value: id } } };
            const getOne$ = this.loader
                .getCall(searchParams)
                .pipe(map((res) => res.rows[0]));
            getOne$.subscribe((item) => {
                if (!item) {
                    this.appendIdToUrl(null);
                    return;
                }
                this.onEdit(item);
            });
        }
    }
    getFiles(entry) {
        // TODO: test if multiple files controls. Tested only with one for now.
        const fileControls = this.config().filter((item) => item.controlType === CONTROL_TYPES.FILES);
        const files = fileControls.flatMap((control) => {
            const key = control.key;
            const value = entry[key];
            if (isArray(value)) {
                return value
                    .map((v) => v.file)
                    .filter((v) => v instanceof File);
            }
            return [];
        });
        return files;
    }
    handleArchive(ids) {
        const count = ids.length;
        const message = count === 1
            ? this.labels.table.deleteConfirmationSingle
            : this.labels.table.deleteConfirmationMultiple(count);
        const acceptFn = () => {
            this.loader.archive(ids).subscribe(() => {
                this.hideEditionDialog();
            });
        };
        this.confirm(message, acceptFn);
    }
    handleRestore(ids) {
        const count = ids.length;
        const message = count === 1
            ? this.labels.table.restoreConfirmationSingle
            : this.labels.table.restoreConfirmationMultiple(count);
        const acceptFn = () => {
            this.loader.restore(ids).subscribe(() => {
                this.hideEditionDialog();
            });
        };
        this.confirm(message, acceptFn);
    }
    confirm(message, acceptFn) {
        this.confirmationService.confirm({
            message,
            header: this.labels.table.confirmationHeader,
            icon: "pi pi-info-circle",
            rejectLabel: this.labels.table.confirmationCancel,
            acceptLabel: this.labels.table.confirmationConfirm,
            accept: acceptFn,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.7", type: TableComponent, isStandalone: true, selector: "tbl-table", inputs: { areColumnsConfigurable: { classPropertyName: "areColumnsConfigurable", publicName: "areColumnsConfigurable", isSignal: true, isRequired: false, transformFunction: null }, areColumnsResizable: { classPropertyName: "areColumnsResizable", publicName: "areColumnsResizable", isSignal: true, isRequired: false, transformFunction: null }, canAccessItemFromUrl: { classPropertyName: "canAccessItemFromUrl", publicName: "canAccessItemFromUrl", isSignal: true, isRequired: false, transformFunction: null }, clickableRows: { classPropertyName: "clickableRows", publicName: "clickableRows", isSignal: true, isRequired: false, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, customActionsTemplate: { classPropertyName: "customActionsTemplate", publicName: "customActionsTemplate", isSignal: true, isRequired: false, transformFunction: null }, customRowStyles: { classPropertyName: "customRowStyles", publicName: "customRowStyles", isSignal: true, isRequired: false, transformFunction: null }, additionalReadonlyProperties: { classPropertyName: "additionalReadonlyProperties", publicName: "additionalReadonlyProperties", isSignal: true, isRequired: false, transformFunction: null }, entityFactory: { classPropertyName: "entityFactory", publicName: "entityFactory", isSignal: true, isRequired: true, transformFunction: null }, entityId: { classPropertyName: "entityId", publicName: "entityId", isSignal: true, isRequired: true, transformFunction: null }, entityLabel: { classPropertyName: "entityLabel", publicName: "entityLabel", isSignal: true, isRequired: false, transformFunction: null }, editionDialogTitle: { classPropertyName: "editionDialogTitle", publicName: "editionDialogTitle", isSignal: true, isRequired: false, transformFunction: null }, editionDialogWidth: { classPropertyName: "editionDialogWidth", publicName: "editionDialogWidth", isSignal: true, isRequired: false, transformFunction: null }, editionDialogSize: { classPropertyName: "editionDialogSize", publicName: "editionDialogSize", isSignal: true, isRequired: false, transformFunction: null }, editionDialogHeight: { classPropertyName: "editionDialogHeight", publicName: "editionDialogHeight", isSignal: true, isRequired: false, transformFunction: null }, excelExportMode: { classPropertyName: "excelExportMode", publicName: "excelExportMode", isSignal: true, isRequired: false, transformFunction: null }, filterable: { classPropertyName: "filterable", publicName: "filterable", isSignal: true, isRequired: false, transformFunction: null }, filterLevel: { classPropertyName: "filterLevel", publicName: "filterLevel", isSignal: true, isRequired: false, transformFunction: null }, forceReload: { classPropertyName: "forceReload", publicName: "forceReload", isSignal: true, isRequired: false, transformFunction: null }, groupValidator: { classPropertyName: "groupValidator", publicName: "groupValidator", isSignal: true, isRequired: false, transformFunction: null }, httpCalls: { classPropertyName: "httpCalls", publicName: "httpCalls", isSignal: true, isRequired: true, transformFunction: null }, isContextMenuEnabled: { classPropertyName: "isContextMenuEnabled", publicName: "isContextMenuEnabled", isSignal: true, isRequired: false, transformFunction: null }, isCsvExportEnabled: { classPropertyName: "isCsvExportEnabled", publicName: "isCsvExportEnabled", isSignal: true, isRequired: false, transformFunction: null }, isDefaultEditionDisabled: { classPropertyName: "isDefaultEditionDisabled", publicName: "isDefaultEditionDisabled", isSignal: true, isRequired: false, transformFunction: null }, isExcelExportEnabled: { classPropertyName: "isExcelExportEnabled", publicName: "isExcelExportEnabled", isSignal: true, isRequired: false, transformFunction: null }, isPreferencesModeEnabled: { classPropertyName: "isPreferencesModeEnabled", publicName: "isPreferencesModeEnabled", isSignal: true, isRequired: false, transformFunction: null }, labelStrategy: { classPropertyName: "labelStrategy", publicName: "labelStrategy", isSignal: true, isRequired: false, transformFunction: null }, labelStrategyVariant: { classPropertyName: "labelStrategyVariant", publicName: "labelStrategyVariant", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, outsideTableHeight: { classPropertyName: "outsideTableHeight", publicName: "outsideTableHeight", isSignal: true, isRequired: false, transformFunction: null }, paginator: { classPropertyName: "paginator", publicName: "paginator", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, rowsPerPageOptions: { classPropertyName: "rowsPerPageOptions", publicName: "rowsPerPageOptions", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null }, sortable: { classPropertyName: "sortable", publicName: "sortable", isSignal: true, isRequired: false, transformFunction: null }, persistState: { classPropertyName: "persistState", publicName: "persistState", isSignal: true, isRequired: false, transformFunction: null }, stateStorage: { classPropertyName: "stateStorage", publicName: "stateStorage", isSignal: true, isRequired: false, transformFunction: null }, stripedRows: { classPropertyName: "stripedRows", publicName: "stripedRows", isSignal: true, isRequired: false, transformFunction: null }, tableTitle: { classPropertyName: "tableTitle", publicName: "tableTitle", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { editionDialogClosed: "editionDialogClosed", formChanged: "formChanged", newClicked: "newClicked", rowClicked: "rowClicked", validityChanged: "validityChanged" }, providers: [
            CrudLoader,
            TableColumnsStorage,
            TableStateService,
            ExportService,
            ConfirmationService,
        ], viewQueries: [{ propertyName: "tableRegular", first: true, predicate: ["table"], descendants: true, read: TableRegularComponent, isSignal: true }], usesOnChanges: true, ngImport: i0, template: "@if (isLoading()) {\n  <p-progressBar class=\"table-progress-bar\" mode=\"indeterminate\" />\n}\n\n<tbl-table-toolbar\n  [features]=\"features()\"\n  [tableTitle]=\"tableTitle()\"\n  [selectedEntries]=\"selectedEntries\"\n  [selectable]=\"selectable()\"\n  [areColumnsConfigurable]=\"areColumnsConfigurable()\"\n  [isExcelExportEnabled]=\"isExcelExportEnabled()\"\n  [isCsvExportEnabled]=\"isCsvExportEnabled()\"\n  [isExportingData]=\"isExportingData()\"\n  [cols]=\"columns()\"\n  [(isExportDialogVisible)]=\"isExportDialogVisible\"\n  (archiveManyClicked)=\"onArchiveMany()\"\n  (exportClicked)=\"onExport($event)\"\n  (newClicked)=\"onNew()\"\n  (manageColumnsClicked)=\"showColumnsManagement()\"\n  (refreshDataClicked)=\"refreshData()\"\n/>\n\n<tbl-table-regular\n  #table\n  [columns]=\"columns()\"\n  [class.p-table-no-paginator]=\"!paginator()\"\n  [data]=\"data()\"\n  [total]=\"total()\"\n  [selectable]=\"selectable()\"\n  [(selectedEntries)]=\"selectedEntries\"\n  [clickableRows]=\"clickableRows()\"\n  [lazy]=\"lazy()\"\n  [features]=\"features()\"\n  [filterable]=\"filterable()\"\n  [defaultFilters]=\"defaultFilters()\"\n  [sortable]=\"sortable()\"\n  [defaultSort]=\"defaultSort()\"\n  [paginator]=\"paginator()\"\n  [filterLevel]=\"filterLevel()\"\n  [customRowStyles]=\"customRowStyles()\"\n  [customActionsTemplate]=\"customActionsTemplate()\"\n  [isContextMenuEnabled]=\"isContextMenuEnabled()\"\n  [entityId]=\"entityId()\"\n  [stateStorage]=\"stateStorage()\"\n  [persistState]=\"persistState()\"\n  [areColumnsResizable]=\"areColumnsResizable()\"\n  [rows]=\"rows()\"\n  [rowsPerPageOptions]=\"rowsPerPageOptions()\"\n  [outsideTableHeight]=\"outsideTableHeight()\"\n  [stripedRows]=\"stripedRows()\"\n  [additionalReadonlyProperties]=\"additionalReadonlyProperties()\"\n  (lazyLoaded)=\"onLazyLoad($event)\"\n  (archived)=\"onArchive($event)\"\n  (cellClicked)=\"onCellClick($event)\"\n  (columnResized)=\"onColumnResized($event)\"\n/>\n\n@if (isColumnsConfigDialogDisplayed()) {\n  <tbl-columns-management-dialog\n    [visible]=\"isColumnsConfigDialogDisplayed()\"\n    [isPreferencesModeEnabled]=\"isPreferencesModeEnabled()\"\n    [views]=\"views()!\"\n    (closed)=\"hideColumnsConfigDialog()\"\n    (saved)=\"applyViews($event)\"\n  />\n}\n\n@if (isEntryEditionDialogDisplayed() && editedEntry) {\n  <crd-edition-dialog\n    [isVisible]=\"isEntryEditionDialogDisplayed()\"\n    [customHeader]=\"editionDialogTitle()\"\n    [entityLabel]=\"entityLabel()\"\n    [config]=\"config()\"\n    [editedEntry]=\"editedEntry\"\n    [isCreation]=\"isCreation()\"\n    [isReadonly]=\"isReadonly()\"\n    [groupValidator]=\"groupValidator()\"\n    [features]=\"features()\"\n    [getHistory]=\"getHistoryForEntry()\"\n    [isLoading]=\"isLoading()\"\n    [width]=\"editionDialogWidth()\"\n    [height]=\"editionDialogHeight()\"\n    [size]=\"editionDialogSize()\"\n    (hide)=\"hideEditionDialog()\"\n    (saved)=\"onEditedEntrySave($event)\"\n    (archived)=\"onEditedEntryArchive($event)\"\n    (restored)=\"onEditedEntryRestore($event)\"\n    (edited)=\"onEditedEntryEdit($event)\"\n    (formChanged)=\"onFormChanged($event)\"\n    (validityChanged)=\"onValidityChanged($event)\"\n  />\n}\n\n<p-confirmdialog />\n\n<p-toast />", styles: ["tbl-table{height:100%;display:block;position:relative;--p-datatable-body-cell-padding: .25rem;--p-datatable-header-cell-padding: .25rem}tbl-table .table-progress-bar{position:absolute;bottom:0;z-index:3;width:100%;height:4px}tbl-table .p-button-text,tbl-table .p-button-text:enabled:hover{color:var(--primary-font-color)}tbl-table .table{margin:0 5px;display:block}tbl-table .table .p-datatable-table{table-layout:fixed}tbl-table .table .p-datatable-table .p-datatable-thead tr th .header-container{display:flex;justify-content:space-between;align-items:center}tbl-table .table .p-datatable-table .p-datatable-thead tr th .header-container .sub-container{display:flex;align-items:center;width:100%}tbl-table .table .p-datatable-table .p-datatable-thead tr th .header-container .sub-container span{flex:1}tbl-table .table .p-datatable-table .p-datatable-thead tr th .header-container .sub-container p-sorticon{margin-left:10px}tbl-table .table .p-datatable-table .p-datatable-tbody tr th span{max-width:calc(100% - 60px)}tbl-table .table .p-datatable-table .p-datatable-tbody tr td span.centered{text-align:center}tbl-table .table .p-datatable-table .p-datatable-tbody tr td.no-data-row{border:0;padding:1rem;text-align:center}tbl-table .table .p-datatable-table tr,tbl-table .table .p-datatable-table th,tbl-table .table .p-datatable-table td{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}tbl-table .table .p-datatable-table tr.checkbox-column,tbl-table .table .p-datatable-table th.checkbox-column,tbl-table .table .p-datatable-table td.checkbox-column{max-width:3rem;min-width:3rem;width:3rem}tbl-table .table .p-datatable-table tr.actions-column,tbl-table .table .p-datatable-table th.actions-column,tbl-table .table .p-datatable-table td.actions-column{width:150px;min-width:150px;max-width:150px}tbl-table .table .p-datatable-table tr.actions-column .p-button-icon-only,tbl-table .table .p-datatable-table th.actions-column .p-button-icon-only,tbl-table .table .p-datatable-table td.actions-column .p-button-icon-only{padding:0}tbl-table .table .p-datatable-table tr.clickable,tbl-table .table .p-datatable-table th.clickable,tbl-table .table .p-datatable-table td.clickable{cursor:pointer}tbl-table .table .p-datatable-table tr.filter-row-th,tbl-table .table .p-datatable-table th.filter-row-th,tbl-table .table .p-datatable-table td.filter-row-th{overflow:unset}tbl-table .table .p-datatable-table tr span:not(:has(span)):not([role=combobox]),tbl-table .table .p-datatable-table th span:not(:has(span)):not([role=combobox]),tbl-table .table .p-datatable-table td span:not(:has(span)):not([role=combobox]){display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:2px}tbl-table .table .p-datatable-table tr .p-chip,tbl-table .table .p-datatable-table th .p-chip,tbl-table .table .p-datatable-table td .p-chip{width:max-content;display:inline-block!important;margin-right:5px}tbl-table .table .p-datatable-table tr .cell-image,tbl-table .table .p-datatable-table th .cell-image,tbl-table .table .p-datatable-table td .cell-image{margin:auto;display:block;border-radius:50%}tbl-table .table .p-datatable-table tr .red,tbl-table .table .p-datatable-table th .red,tbl-table .table .p-datatable-table td .red{color:var(--p-red-700)}tbl-table .table .p-datatable-table tr .green,tbl-table .table .p-datatable-table th .green,tbl-table .table .p-datatable-table td .green{color:var(--p-green-700)}tbl-table .table .p-column-filter-overlay button.p-inputnumber-button{width:max-content;height:max-content;padding:0 .5rem;border-radius:0}tbl-table .table .p-datatable.p-datatable-hoverable-rows .p-datatable-tbody>tr:not(.p-highlight):hover td.p-frozen-column{background:var(--primary-bg-color)}\n"], dependencies: [{ kind: "component", type: TableToolbarComponent, selector: "tbl-table-toolbar", inputs: ["selectedEntries", "features", "selectable", "areColumnsConfigurable", "tableTitle", "cols", "isExcelExportEnabled", "isCsvExportEnabled", "isExportDialogVisible", "isExportingData"], outputs: ["isExportDialogVisibleChange", "archiveManyClicked", "restoreMultipleClicked", "manageColumnsClicked", "newClicked", "refreshDataClicked", "exportClicked"] }, { kind: "ngmodule", type: TableModule }, { kind: "ngmodule", type: SharedModule }, { kind: "component", type: TableRegularComponent, selector: "tbl-table-regular", inputs: ["columns", "data", "total", "selectable", "clickableRows", "lazy", "features", "selectedEntries", "filterable", "defaultFilters", "sortable", "defaultSort", "paginator", "filterLevel", "customRowStyles", "customActionsTemplate", "isContextMenuEnabled", "entityId", "stateStorage", "persistState", "areColumnsResizable", "rows", "rowsPerPageOptions", "outsideTableHeight", "stripedRows", "additionalReadonlyProperties"], outputs: ["selectedEntriesChange", "lazyLoaded", "archived", "cellClicked", "columnResized"] }, { kind: "component", type: ColumnsManagementDialogComponent, selector: "tbl-columns-management-dialog", inputs: ["views", "isPreferencesModeEnabled", "visible"], outputs: ["visibleChange", "closed", "saved"] }, { kind: "component", type: EditionDialogComponent, selector: "crd-edition-dialog", inputs: ["config", "features", "getHistory", "historyMapper", "groupValidator", "customHeader", "entityLabel", "height", "isCreation", "isReadonly", "isVisible", "width", "size", "isLoading", "labelStrategy", "labelStrategyVariant", "editedEntry"], outputs: ["editedEntryChange", "archived", "restored", "edited", "formChanged", "hide", "saved", "validityChanged"] }, { kind: "ngmodule", type: ProgressBarModule }, { kind: "component", type: i1$h.ProgressBar, selector: "p-progressBar, p-progressbar, p-progress-bar", inputs: ["value", "showValue", "styleClass", "valueStyleClass", "unit", "mode", "color"] }, { kind: "ngmodule", type: ConfirmDialogModule }, { kind: "component", type: i2$6.ConfirmDialog, selector: "p-confirmDialog, p-confirmdialog, p-confirm-dialog", inputs: ["header", "icon", "message", "style", "styleClass", "maskStyleClass", "acceptIcon", "acceptLabel", "closeAriaLabel", "acceptAriaLabel", "acceptVisible", "rejectIcon", "rejectLabel", "rejectAriaLabel", "rejectVisible", "acceptButtonStyleClass", "rejectButtonStyleClass", "closeOnEscape", "dismissableMask", "blockScroll", "rtl", "closable", "appendTo", "key", "autoZIndex", "baseZIndex", "transitionOptions", "focusTrap", "defaultFocus", "breakpoints", "modal", "visible", "position", "draggable"], outputs: ["onHide"] }, { kind: "ngmodule", type: ToastModule }, { kind: "component", type: i3$4.Toast, selector: "p-toast", inputs: ["key", "autoZIndex", "baseZIndex", "life", "styleClass", "position", "preventOpenDuplicates", "preventDuplicates", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "motionOptions", "breakpoints"], outputs: ["onClose"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.7", ngImport: i0, type: TableComponent, decorators: [{
            type: Component,
            args: [{ selector: "tbl-table", providers: [
                        CrudLoader,
                        TableColumnsStorage,
                        TableStateService,
                        ExportService,
                        ConfirmationService,
                    ], imports: [
                        TableToolbarComponent,
                        TableModule,
                        SharedModule,
                        TableRegularComponent,
                        ColumnsManagementDialogComponent,
                        EditionDialogComponent,
                        ProgressBarModule,
                        ConfirmDialogModule,
                        ToastModule,
                    ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (isLoading()) {\n  <p-progressBar class=\"table-progress-bar\" mode=\"indeterminate\" />\n}\n\n<tbl-table-toolbar\n  [features]=\"features()\"\n  [tableTitle]=\"tableTitle()\"\n  [selectedEntries]=\"selectedEntries\"\n  [selectable]=\"selectable()\"\n  [areColumnsConfigurable]=\"areColumnsConfigurable()\"\n  [isExcelExportEnabled]=\"isExcelExportEnabled()\"\n  [isCsvExportEnabled]=\"isCsvExportEnabled()\"\n  [isExportingData]=\"isExportingData()\"\n  [cols]=\"columns()\"\n  [(isExportDialogVisible)]=\"isExportDialogVisible\"\n  (archiveManyClicked)=\"onArchiveMany()\"\n  (exportClicked)=\"onExport($event)\"\n  (newClicked)=\"onNew()\"\n  (manageColumnsClicked)=\"showColumnsManagement()\"\n  (refreshDataClicked)=\"refreshData()\"\n/>\n\n<tbl-table-regular\n  #table\n  [columns]=\"columns()\"\n  [class.p-table-no-paginator]=\"!paginator()\"\n  [data]=\"data()\"\n  [total]=\"total()\"\n  [selectable]=\"selectable()\"\n  [(selectedEntries)]=\"selectedEntries\"\n  [clickableRows]=\"clickableRows()\"\n  [lazy]=\"lazy()\"\n  [features]=\"features()\"\n  [filterable]=\"filterable()\"\n  [defaultFilters]=\"defaultFilters()\"\n  [sortable]=\"sortable()\"\n  [defaultSort]=\"defaultSort()\"\n  [paginator]=\"paginator()\"\n  [filterLevel]=\"filterLevel()\"\n  [customRowStyles]=\"customRowStyles()\"\n  [customActionsTemplate]=\"customActionsTemplate()\"\n  [isContextMenuEnabled]=\"isContextMenuEnabled()\"\n  [entityId]=\"entityId()\"\n  [stateStorage]=\"stateStorage()\"\n  [persistState]=\"persistState()\"\n  [areColumnsResizable]=\"areColumnsResizable()\"\n  [rows]=\"rows()\"\n  [rowsPerPageOptions]=\"rowsPerPageOptions()\"\n  [outsideTableHeight]=\"outsideTableHeight()\"\n  [stripedRows]=\"stripedRows()\"\n  [additionalReadonlyProperties]=\"additionalReadonlyProperties()\"\n  (lazyLoaded)=\"onLazyLoad($event)\"\n  (archived)=\"onArchive($event)\"\n  (cellClicked)=\"onCellClick($event)\"\n  (columnResized)=\"onColumnResized($event)\"\n/>\n\n@if (isColumnsConfigDialogDisplayed()) {\n  <tbl-columns-management-dialog\n    [visible]=\"isColumnsConfigDialogDisplayed()\"\n    [isPreferencesModeEnabled]=\"isPreferencesModeEnabled()\"\n    [views]=\"views()!\"\n    (closed)=\"hideColumnsConfigDialog()\"\n    (saved)=\"applyViews($event)\"\n  />\n}\n\n@if (isEntryEditionDialogDisplayed() && editedEntry) {\n  <crd-edition-dialog\n    [isVisible]=\"isEntryEditionDialogDisplayed()\"\n    [customHeader]=\"editionDialogTitle()\"\n    [entityLabel]=\"entityLabel()\"\n    [config]=\"config()\"\n    [editedEntry]=\"editedEntry\"\n    [isCreation]=\"isCreation()\"\n    [isReadonly]=\"isReadonly()\"\n    [groupValidator]=\"groupValidator()\"\n    [features]=\"features()\"\n    [getHistory]=\"getHistoryForEntry()\"\n    [isLoading]=\"isLoading()\"\n    [width]=\"editionDialogWidth()\"\n    [height]=\"editionDialogHeight()\"\n    [size]=\"editionDialogSize()\"\n    (hide)=\"hideEditionDialog()\"\n    (saved)=\"onEditedEntrySave($event)\"\n    (archived)=\"onEditedEntryArchive($event)\"\n    (restored)=\"onEditedEntryRestore($event)\"\n    (edited)=\"onEditedEntryEdit($event)\"\n    (formChanged)=\"onFormChanged($event)\"\n    (validityChanged)=\"onValidityChanged($event)\"\n  />\n}\n\n<p-confirmdialog />\n\n<p-toast />", styles: ["tbl-table{height:100%;display:block;position:relative;--p-datatable-body-cell-padding: .25rem;--p-datatable-header-cell-padding: .25rem}tbl-table .table-progress-bar{position:absolute;bottom:0;z-index:3;width:100%;height:4px}tbl-table .p-button-text,tbl-table .p-button-text:enabled:hover{color:var(--primary-font-color)}tbl-table .table{margin:0 5px;display:block}tbl-table .table .p-datatable-table{table-layout:fixed}tbl-table .table .p-datatable-table .p-datatable-thead tr th .header-container{display:flex;justify-content:space-between;align-items:center}tbl-table .table .p-datatable-table .p-datatable-thead tr th .header-container .sub-container{display:flex;align-items:center;width:100%}tbl-table .table .p-datatable-table .p-datatable-thead tr th .header-container .sub-container span{flex:1}tbl-table .table .p-datatable-table .p-datatable-thead tr th .header-container .sub-container p-sorticon{margin-left:10px}tbl-table .table .p-datatable-table .p-datatable-tbody tr th span{max-width:calc(100% - 60px)}tbl-table .table .p-datatable-table .p-datatable-tbody tr td span.centered{text-align:center}tbl-table .table .p-datatable-table .p-datatable-tbody tr td.no-data-row{border:0;padding:1rem;text-align:center}tbl-table .table .p-datatable-table tr,tbl-table .table .p-datatable-table th,tbl-table .table .p-datatable-table td{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}tbl-table .table .p-datatable-table tr.checkbox-column,tbl-table .table .p-datatable-table th.checkbox-column,tbl-table .table .p-datatable-table td.checkbox-column{max-width:3rem;min-width:3rem;width:3rem}tbl-table .table .p-datatable-table tr.actions-column,tbl-table .table .p-datatable-table th.actions-column,tbl-table .table .p-datatable-table td.actions-column{width:150px;min-width:150px;max-width:150px}tbl-table .table .p-datatable-table tr.actions-column .p-button-icon-only,tbl-table .table .p-datatable-table th.actions-column .p-button-icon-only,tbl-table .table .p-datatable-table td.actions-column .p-button-icon-only{padding:0}tbl-table .table .p-datatable-table tr.clickable,tbl-table .table .p-datatable-table th.clickable,tbl-table .table .p-datatable-table td.clickable{cursor:pointer}tbl-table .table .p-datatable-table tr.filter-row-th,tbl-table .table .p-datatable-table th.filter-row-th,tbl-table .table .p-datatable-table td.filter-row-th{overflow:unset}tbl-table .table .p-datatable-table tr span:not(:has(span)):not([role=combobox]),tbl-table .table .p-datatable-table th span:not(:has(span)):not([role=combobox]),tbl-table .table .p-datatable-table td span:not(:has(span)):not([role=combobox]){display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:2px}tbl-table .table .p-datatable-table tr .p-chip,tbl-table .table .p-datatable-table th .p-chip,tbl-table .table .p-datatable-table td .p-chip{width:max-content;display:inline-block!important;margin-right:5px}tbl-table .table .p-datatable-table tr .cell-image,tbl-table .table .p-datatable-table th .cell-image,tbl-table .table .p-datatable-table td .cell-image{margin:auto;display:block;border-radius:50%}tbl-table .table .p-datatable-table tr .red,tbl-table .table .p-datatable-table th .red,tbl-table .table .p-datatable-table td .red{color:var(--p-red-700)}tbl-table .table .p-datatable-table tr .green,tbl-table .table .p-datatable-table th .green,tbl-table .table .p-datatable-table td .green{color:var(--p-green-700)}tbl-table .table .p-column-filter-overlay button.p-inputnumber-button{width:max-content;height:max-content;padding:0 .5rem;border-radius:0}tbl-table .table .p-datatable.p-datatable-hoverable-rows .p-datatable-tbody>tr:not(.p-highlight):hover td.p-frozen-column{background:var(--primary-bg-color)}\n"] }]
        }], propDecorators: { areColumnsConfigurable: [{ type: i0.Input, args: [{ isSignal: true, alias: "areColumnsConfigurable", required: false }] }], areColumnsResizable: [{ type: i0.Input, args: [{ isSignal: true, alias: "areColumnsResizable", required: false }] }], canAccessItemFromUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "canAccessItemFromUrl", required: false }] }], clickableRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "clickableRows", required: false }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], customActionsTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "customActionsTemplate", required: false }] }], customRowStyles: [{ type: i0.Input, args: [{ isSignal: true, alias: "customRowStyles", required: false }] }], additionalReadonlyProperties: [{ type: i0.Input, args: [{ isSignal: true, alias: "additionalReadonlyProperties", required: false }] }], entityFactory: [{ type: i0.Input, args: [{ isSignal: true, alias: "entityFactory", required: true }] }], entityId: [{ type: i0.Input, args: [{ isSignal: true, alias: "entityId", required: true }] }], entityLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "entityLabel", required: false }] }], editionDialogTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "editionDialogTitle", required: false }] }], editionDialogWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "editionDialogWidth", required: false }] }], editionDialogSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "editionDialogSize", required: false }] }], editionDialogHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "editionDialogHeight", required: false }] }], excelExportMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "excelExportMode", required: false }] }], filterable: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterable", required: false }] }], filterLevel: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLevel", required: false }] }], forceReload: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceReload", required: false }] }], groupValidator: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupValidator", required: false }] }], httpCalls: [{ type: i0.Input, args: [{ isSignal: true, alias: "httpCalls", required: true }] }], isContextMenuEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isContextMenuEnabled", required: false }] }], isCsvExportEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isCsvExportEnabled", required: false }] }], isDefaultEditionDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isDefaultEditionDisabled", required: false }] }], isExcelExportEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isExcelExportEnabled", required: false }] }], isPreferencesModeEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "isPreferencesModeEnabled", required: false }] }], labelStrategy: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategy", required: false }] }], labelStrategyVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStrategyVariant", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], outsideTableHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "outsideTableHeight", required: false }] }], paginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginator", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], rowsPerPageOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowsPerPageOptions", required: false }] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: false }] }], sortable: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortable", required: false }] }], persistState: [{ type: i0.Input, args: [{ isSignal: true, alias: "persistState", required: false }] }], stateStorage: [{ type: i0.Input, args: [{ isSignal: true, alias: "stateStorage", required: false }] }], stripedRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "stripedRows", required: false }] }], tableTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableTitle", required: true }] }], editionDialogClosed: [{ type: i0.Output, args: ["editionDialogClosed"] }], formChanged: [{ type: i0.Output, args: ["formChanged"] }], newClicked: [{ type: i0.Output, args: ["newClicked"] }], rowClicked: [{ type: i0.Output, args: ["rowClicked"] }], validityChanged: [{ type: i0.Output, args: ["validityChanged"] }], tableRegular: [{ type: i0.ViewChild, args: ["table", { ...{
                            read: TableRegularComponent,
                        }, isSignal: true }] }] } });

// --- Core: app config token (required by host app) ---

/**
 * Generated bundle index. Do not edit.
 */

export { ACL_ADAPTER, APP_CONFIG, APP_FORM_CONFIG, ARCHIVED_CONFIG, ArchiveInfo, BASE_FORM_ERROR_MESSAGES, CONTROL_TYPES, CRUD_LABELS, ColumnOptions, ConfigHelper, ControlOptions, CrudButtonComponent, CrudItemBase, CrudRepository, DATE_FORMAT, DATE_FORMAT_CALENDAR, DATE_WITH_SECONDS_FORMAT, DATE_WITH_TIME_FORMAT, DEFAULT_CRUD_LABELS, DocumentFormDataMapper, DownloadService, EditionDialogComponent, EmailValidator, FILTER_LEVELS, FOUR_COLUMN_WIDTH, FileInfo, FormBuilderService, FormComponent, HISTORY_MAPPER, HistoryComponent, ID_CONFIG, INIT_COORDINATES, INIT_SOCIALS, INPUT_TYPES, IdInfo, LOCATION_CONFIG, LoadingService, LocalStorageService, LocationInterceptorService, NO_ROWS, NO_ROWS_AND_COUNT, ONE_COLUMN_WIDTH, OfflineService, PRIMENG_FR, SOCIALS_CONFIG, SnackbarService, THREE_COLUMN_WIDTH, TWO_COLUMN_WIDTH, TableComponent, TableConfig, TableConfigService, alphanumericalWithSpaces, alphanumericalWithoutSpaces, canBeDate, createArchivedConfig, createAuditConfig, filterCalls, formatDate, getDateRangeWithoutTime, getDifferenceInDays, getMidnightTimeStamp, integer, interpolate, isValidDateString, lettersWithSpaces, lettersWithoutSpaces, max, maxlength, min, minlength, nameWithDashes, onlyCaps, patternValidator, phoneNumber, provideCrudLabels, required, requiredTrue, toSelectItems, withExtension };
//# sourceMappingURL=dwtechs-crud-builder.mjs.map
