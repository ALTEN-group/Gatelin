import * as _angular_core from '@angular/core';
import { InjectionToken, Type, Provider, Signal, OnInit, TemplateRef, OnChanges, SimpleChanges } from '@angular/core';
import * as primeng_api from 'primeng/api';
import { SelectItem, MessageService, FilterMetadata } from 'primeng/api';
import { SafeHtml } from '@angular/platform-browser';
import * as _angular_forms from '@angular/forms';
import { ValidatorFn, AsyncValidatorFn, AbstractControl, FormGroupDirective, FormGroup, UntypedFormGroup, FormControl, Validators, ValidationErrors } from '@angular/forms';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { ButtonSeverity } from 'primeng/button';
import * as _dwtechs_crud_builder from '@dwtechs/crud-builder';
import { TableLazyLoadEvent, Table, TableColResizeEvent } from 'primeng/table';
import { ActivatedRouteSnapshot } from '@angular/router';
import { HttpResponse } from '@angular/common/http';

interface AppConfig {
    title: string;
    appKey: string;
    storageKeys: {
        [key: string]: string;
    };
    apiPrefix: string;
}
declare const APP_CONFIG: InjectionToken<AppConfig>;

type ProgressMode = "bar" | "spin";
declare class LoadingService {
    private readonly defaultMode;
    private readonly _isLoading;
    private readonly _mode;
    readonly isLoading: _angular_core.Signal<boolean>;
    readonly mode: _angular_core.Signal<ProgressMode>;
    start(mode?: ProgressMode): void;
    stop(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LoadingService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<LoadingService>;
}

declare class LocalStorageService {
    getItem(key: string): string | null;
    setItem(key: string, data: string): void;
    removeItem(key: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LocalStorageService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<LocalStorageService>;
}

/**
 * Get a list of SelectItems from a list of item
 * @param items list of item to map
 * @param keyoflabel key of the label property
 * @returns a list of select item
 */
declare function toSelectItems<T extends {
    id: number | null;
}>(items: T[], keyoflabel: keyof T, extraKeys?: (keyof T)[]): (SelectItem & {
    extraData?: Partial<T>;
})[];

declare class SnackbarService {
    private readonly messageService;
    constructor(messageService: MessageService);
    displayError(message?: string): void;
    displaySuccess(): void;
    displayInfo(message: string): void;
    private show;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SnackbarService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SnackbarService>;
}

declare function interpolate<T>(string: string, values: T): string;

declare const CONTROL_TYPES: {
    readonly AUTOCOMPLETE: "autocomplete";
    readonly CHECKBOX: "checkbox";
    readonly CUSTOM: "custom";
    readonly DATE: "date";
    readonly FILES: "files";
    readonly GROUP: "group";
    readonly INPUT: "input";
    readonly MULTISELECT: "multiselect";
    readonly PICKLIST: "picklist";
    readonly RADIO: "radio";
    readonly SELECT: "select";
    readonly SELECT_BUTTON: "select_button";
    readonly TABLE: "table";
    readonly TEXTAREA: "textarea";
    readonly WYSIWYG: "wysiwyg";
};
type ControlType = (typeof CONTROL_TYPES)[keyof typeof CONTROL_TYPES];

declare class ColumnOptions {
    /** Defines if the column is sortable or not */
    sortable?: boolean;
    /** Specifies a default value for the filter*/
    defaultFilter?: FilterMetadata | FilterMetadata[];
    /** Should the column be sorted by default when landing on the table */
    defaultSortField?: boolean;
    /** Should the column be sorted ascending (1) or descending (-1) */
    defaultSortOrder?: -1 | 1;
    /** Defines if the column is filterable or not */
    filterable?: boolean;
    /** Specifies a specific control type for the filter input */
    filterType?: ControlType;
    /** Custom tooltip renderer for the column cells */
    tooltip?: (cellValue: unknown) => SafeHtml;
    /** If set to true, the column will be hidden but can be unhidden in column management */
    isSoftHidden?: boolean;
    /** If set to true, the column will be hidden in the table and in the column management dialog */
    isHardHidden?: boolean;
    /** Specifies a custom renderer for datatable cells
     * TODO: allow to use a custom component as renderer
     * Warning: be careful when using this prop, as it can lead to performance issues
     * Along with xss security issues if the renderer returns unsafe HTML
     */
    customCellRenderer?: (cellValue: unknown) => string;
    /** Specifies a custom HTML renderer for the column header
     * Warning: be careful when using this prop as it can lead to XSS security issues
     * if the renderer returns unsafe HTML
     */
    customHeaderRenderer?: (label: string) => string;
    /** Specifies a custom component for datatable cells -- Works for CUSTOM controlType */
    customComponent?: Type<unknown>;
    /** If true and the value is an array, each item will be displayed as a chip. Default true */
    valueAsChip?: boolean;
    /** Cell will be centered */
    centered?: boolean;
    /** Maximal width of the column. If not defined, will default to 150px */
    defaultWidth?: string;
    isFrozen?: boolean;
    /** Specifies if the column should be ignore on export */
    ignoreOnExport?: boolean;
    /** If the column should have a different label that the main label defined in CrudItemOptions */
    label?: string;
    /** Custom tooltip for the column header. Falls back to the column label if not defined */
    headerTooltip?: string;
    /** If the edition of this cell should be disabled in inline-cell edition mode */
    isCellEditionDisabled?: boolean;
}

interface ControlArrayConfig {
    /** Label for the "Add" button */
    addButtonLabel?: string;
    /** Maximum number of items allowed */
    maxItems?: number;
    /** Minimum number of items required */
    minItems?: number;
}

declare const INPUT_TYPES: {
    readonly TEXT: "text";
    readonly NUMBER: "number";
};
type InputType = (typeof INPUT_TYPES)[keyof typeof INPUT_TYPES];

type FileInfoBuilder = {
    type: "local";
    file: File;
    src: string;
} | {
    type: "server";
    src: string;
};
declare class FileInfo {
    src: string;
    file?: File;
    constructor(fileInfoBuilder: FileInfoBuilder);
    get name(): string;
}

/**
 * Use StrictCrudItemOptions to enforce type checking in your crud options
 * For example if you have to display objects with properties { name, age },
 * you won't be able to declare a crud item with an other key than name or age;
 */
interface StrictCrudItemOptions<T> extends Omit<CrudItemOptions, "key" | "conditions"> {
    key: keyof T;
    conditions?: ItemCondition<T>;
}
interface CrudItemOptions {
    /** Unique identifier */
    key: string;
    /** Label of the form control and the datatable column */
    label: string;
    /** Represents the type of the form control: input, select, autocomplete... */
    controlType: ControlType;
    /**
     * Specifies the type of the form control when it's an 'input': text, number...
     * Specifies if the file is an image
     */
    type?: InputType;
    /** Contains the options of a 'select' or 'multiselect' form control */
    options?: SelectItem[];
    /** Sub-items for nested forms */
    children?: CrudItemOptions[] /**
     * Specifies the way to resolve path given information from the backend
     * Will be used to:
     * - display already uploaded files in the control
     * - set the download path when user clicks to download
     * @example `filesPathResolver: (model) => ({src:`${environment.apiGateway}/model.uuid`, name: model.name}) // Extracts file path from model object
     */;
    filesPathResolver?: (model: any) => FileInfo[];
    /** Defines the options specific to the datatable column */
    columnOptions?: ColumnOptions;
    /** Defines the options specific to the form control */
    controlOptions?: ControlOptions;
    /**
     * @new stores new way to handle forms
     * This is a map of conditions that will be evaluated
     * to determine the value of a property in the controlOptions.
     *
     * The function should return a value that will be assigned to the property.
     *
     * For example:
     *
     * ```typescript
     * conditions: {
     *   controlOptions: {
     *     disabled: ({item, model}) => model.age < 18,
     *   }
     * }
     * ```
     */
    conditions?: ItemCondition;
}
/**
 * This type is used to define the structure of the conditions
 * that can be used in the CrudItemOptions.
 */
type ItemCondition<T = any> = {
    [Prop in keyof CrudItemOptions]?: ConditionFn<T> | ControlOptionsCondition<T>;
};
type ControlOptionsCondition<T = any> = {
    [Prop in keyof ControlOptions]?: ConditionFn<T>;
};
type ConditionFn<T = any> = (conditionsArgs: {
    control: CrudItemOptions;
    model: T;
}) => unknown;

type FormFieldInteraction = "blur" | "cellClicked" | "cellEditComplete" | "cellEditInit" | "clear" | "click" | "focus" | "keyup" | "panelClose" | "panelOpen" | "rowsSelectionChange" | "rowEditInit" | "rowEditCancel" | "rowEditComplete" | "select" | "valueChange" | "uploadFile" | "clearFile" | "clearAllFiles";
/**
 * Event emitted when a form field control is interacted with
 */
interface FormFieldInteractionEvent {
    /** The key/name of the form field */
    key: string;
    /** The type of control (input, select, etc.) */
    controlType: string;
    /** The current value after interaction */
    value: any;
    /** The type of interaction that occurred */
    interactionType: FormFieldInteraction;
    /** Timestamp of the interaction */
    timestamp: Date;
    /** Can store any additional data related to the interaction */
    extraData?: any;
}

interface TableCtrlConfig {
    /**
     * Table row edition mode: row will enable dialog edition, cell will enable the inline-cell edition
     * In "cell" mode, users can edit individual cells directly within the table.
     * In "row" mode, users edit an entire row at once through a dialog interface.
     * /!\ Cell edition is only possible for INPUT, SELECT and MULTISELECT control types for now.
     * @default "cell"
     */
    editionMode: "row" | "cell";
    /** Enables filtering */
    filterable: boolean;
    /** Enables sorting */
    sortable: boolean;
    /** Enables selection */
    selectable: boolean;
    /** Callback to trigger when a cell is clicked */
    onCellClicked: (entry: {
        row: unknown;
        index: number;
        mode: "read" | "write";
    }) => unknown;
    /** Columns keys in sorted order */
    sortedColumnKeys: string[];
    /** Is header hidden */
    isHeaderHidden: boolean;
    /** Validator function for the whole form when editing in row mode */
    groupValidator: ValidatorFn;
    /** Indicates whether deletion of rows is enabled */
    isDeletionEnabled: boolean;
    /** Indicates whether creation of new rows is enabled */
    isCreationEnabled: boolean;
}

interface ExtendedSelectItem extends SelectItem {
    extraData: unknown;
}
type ControlOnSearchFn = (event: string) => Observable<ExtendedSelectItem[]>;
interface ControlActionResult {
    key: string;
    value: unknown;
    /**
     * When true, applies the action only if the target field is empty or has no value
     * @example `soft: true` // Only sets the value if the target field is currently empty
     */
    soft?: boolean;
    /**
     * Defines how the value should be applied to the target field
     * - 'set': Replaces the current value (default behavior)
     * - 'push': Adds the value to an array field
     * - 'remove': Removes the value from an array field
     * @example `mode: 'push'` // Adds the value to an existing array
     */
    mode?: "set" | "push" | "remove";
}
type ControlAction = (event: FormFieldInteractionEvent) => ControlActionResult[] | undefined;
declare class ControlOptions {
    /**
     * Defines the action to take when a form field interaction occurs -
     * allows setting values of other fields based on interactions
     */
    action?: ControlAction;
    /** Should the increment/decrement buttons be visible for number inputs
     * @default true
     * @example `areNumberInputButtonsVisible: false` // Hides the buttons
     */
    areNumberInputButtonsVisible?: boolean;
    /** Should the options in dropdowns and multiselects be filterable
     * @default true
     * @example `areOptionsFilterable: false` // Enables a search input to filter options
     */
    areOptionsFilterable?: boolean;
    /**
     * Specifies async validators for form control that perform asynchronous validation
     * @example `asyncValidators: [this.emailExistsValidator()]` // Custom async validator checking if email exists
     */
    asyncValidators?: AsyncValidatorFn[];
    /** Minimum number of characters required to trigger autocomplete suggestions
     * @example `autocompleteMinQueryLength: 3` // Suggestions appear after typing 3 characters
     */
    autocompleteMinQueryLength?: number;
    /** Delay in milliseconds before triggering autocomplete suggestions after user input
     * @example `autocompleteDelay: 300` // Waits 300ms after typing before fetching suggestions
     */
    autocompleteDelay?: number;
    /** Height of the autocomplete suggestions dropdown
     * @example `autocompleteScrollHeight: '200px'` // Sets the dropdown height to 200 pixels
     */
    autocompleteScrollHeight?: string;
    /** Should the autocomplete control allow selecting multiple values
     * @example `autocompleteMultiple: true` // Enables multi-select in autocomplete
     */
    autocompleteMultiple?: boolean;
    /** Should the autocomplete control show a dropdown button to display all options
     * @example `autocompleteDropdown: true` // Shows a dropdown button
     */
    autocompleteDropdown?: boolean;
    /**
     * Configuration for the FormArray control when isFormArray is true
     * @example `controlArrayConfig: { minItems: 1, maxItems: 5, addButtonLabel: 'Add Item' }`
     */
    controlArrayConfig?: ControlArrayConfig;
    /** Currency code for number inputs of type currency
     * @example `numberCurrency: 'USD'` // Displays values in US Dollars
     */
    numberCurrency?: string;
    /** Custom component to use as the form control instead of built-in types
     * @example `customComponent: MyCustomControlComponent` // Renders a custom Angular component as the form control
     **/
    customComponent?: Type<unknown>;
    /** Dates that should be disabled (not selectable) in the date picker
     * @example `dateDisabledDates: [new Date(2023, 0, 1), new Date(2023, 11, 25)]` // Disables January 1 and December 25, 2023
     */
    dateDisabledDates?: Date[];
    /** Days of the week that should be disabled in the date picker
     * 0 = Sunday, 1 = Monday, ..., 6 = Saturday
     * @example `dateDisabledDays: [0,6]` // Disables all Sundays and Saturdays
     */
    dateDisabledDays?: number[];
    /** Date format string for displaying dates in the control
     * @example `dateFormat: 'dd/mm/yy'` // Displays dates in day/month/year format
     * @default 'yy-mm-dd'
     */
    dateFormat?: string;
    /** Minimum selectable date in the date picker
     * @example `dateMin: new Date(2020, 0, 1)` // Users cannot select dates before January 1, 2020
     */
    dateMin?: Date;
    /** Maximum selectable date in the date picker
     * @example `dateMax: new Date(2025, 11, 31)` // Users cannot select dates after December 31, 2025
     */
    dateMax?: Date;
    /** Should the date picker overlay hide automatically upon selecting a date
     * @default false
     * @example `dateHideOverlayOnSelect: true` // Closes the overlay when a date is selected
     */
    dateHideOverlayOnSelect?: boolean;
    /** Maximum number of dates that can be selected in 'multiple' selection mode
     * @example `dateMaxCount: 3` // Limits selection to 3 dates when in multiple mode
     */
    dateMaxCount?: number;
    /** Number of months to display simultaneously in the date picker overlay
     * Consider adjusting dateOverlayWidth accordingly for better display
     * @example `dateNumberOfMonths: 2` // Shows two months side by side in the overlay
     * @default 1
     */
    dateNumberOfMonths?: number;
    /** Width of the date picker overlay panel
     * @example `dateOverlayWidth: '400px'` // Sets the overlay width to 400 pixels
     * @default '500px'
     */
    dateOverlayWidth?: string;
    /** Should the date input be read-only, preventing manual typing
     * @example `dateReadonlyInput: true` // Users can only select dates via the picker, not type them
     * @default false
     */
    dateReadonlyInput?: boolean;
    /**
     * PrimeNG calendar mode: 'single' for one date, 'multiple' for several dates, 'range' for date range
     * @default 'single'
     * @example `dateSelectionMode: 'range'` // Allows selecting a start and end date
     */
    dateSelectionMode?: "single" | "multiple" | "range";
    /** Should the date picker show seconds in addition to hours and minutes
     * @example `dateShowSeconds: true` // Displays seconds selector in time selection
     */
    dateShowSeconds?: boolean;
    /**
     * Should the date picker show time selection in addition to date
     * Applicable only when dateSelectionMode is not defined or 'single'
     * @example `dateShowTime: true` // Shows hour and minute selectors
     */
    dateShowTime?: boolean;
    /** If true, only time selection will be shown without date
     * @example `dateTimeOnly: true` // Displays only time picker
     */
    dateTimeOnly?: boolean;
    /** Step increment for hours in time selection
     * @example `dateStepHours: 2` // Hours will increment in steps of 2
     */
    dateStepHours?: number;
    /** Step increment for minutes in time selection
     * @example `dateStepMinutes: 15` // Minutes will increment in steps of 15
     */
    dateStepMinutes?: number;
    /** Initial view mode for the date picker: 'date', 'month', or 'year'
     * @default 'date'
     * @example `dateViewMode: 'year'` // Opens the calendar in year selection mode
     */
    dateViewMode?: "date" | "month" | "year";
    /**
     * Defines the default value for an input when the form is initialized
     * @example `defaultValue: 'admin@example.com'` // Pre-fills the input with this value
     */
    defaultValue?: unknown;
    /**
     * Should the control be disabled (visible but not editable)
     * @example `disabled: true` // Control is grayed out and cannot be modified
     */
    disabled?: boolean;
    /**
     * @deprecated
     * Non applicable property - this will have no effect
     * If set to true, will force the control to always reset to the default value
     * @example `forceDefaultValue: true` // Control value will be reset to defaultValue on form reset
     */
    forceDefaultValue?: boolean;
    /**
     * Help text to display under the field to provide additional guidance
     * @example `helpText: 'Password must contain at least 8 characters with one uppercase letter'`
     */
    helpText?: string;
    /**
     * Should the control be hidden from the form
     * @example `hidden: true` // Control won't be displayed but will still be part of the form
     */
    hidden?: boolean;
    /**
     * Displays an icon in the left side of the input using PrimeNG icon classes
     * @example `inputIcon: 'pi pi-user'` // Shows a user icon inside the input field
     */
    inputIcon?: string;
    /** If true, allows clearing the field. Applicable for: number inputs, radio buttons, dropdowns, and autocomplete
     * @example `isClearable: true` // Shows a clear icon
     * @default true
     */
    isClearable?: boolean;
    /** If true, will prevent the options panel to show on focus */
    isCompleteOnFocusDisabled?: boolean;
    /**
     * Should the control be a FormArray instance for handling multiple values
     * @example `isFormArray: true` // Creates a FormArray instead of a FormControl
     */
    isFormArray?: boolean;
    /** If true, allows toggling between rich text and HTML source view in rich text editors
     * @example `isHtmlToggleable: true` // Shows a button to switch to HTML view
     */
    isHtmlToggleable?: boolean;
    /**
     * When enabled, allows user to create and select a new option in autocomplete when no results match
     * @example `isOptionCreationEnabled: true` // User can type a new value and it will be added as an option
     */
    isOptionCreationEnabled?: boolean;
    /** Enables a "Select All" option in multi-select controls
     * @default true
     * @example `isSelectAllEnabled: true` // Adds a "Select All" checkbox to select/deselect all options
     */
    isSelectAllEnabled?: boolean;
    /**
     * If the control should have a different label than the main label defined in CrudItemOptions
     * @example `label: 'Custom Field Name'` // Overrides the default label from CrudItemOptions
     */
    label?: string;
    /**
     * Defines the max value for an input of type number - should be used with corresponding validator
     * @example `max: 100` // Input value cannot exceed 100, use with Validators.max(100)
     */
    max?: number;
    /** Maximum number of fraction digits to display for number inputs */
    maxFractionDigits?: number;
    /**
     * Defines the max length for an input - should be used with corresponding validator
     * @example `maxLength: 50` // Input limited to 50 characters, use with Validators.maxLength(50)
     */
    maxLength?: number;
    /**
     * Specifies the maximum number of selected labels in a multi-select control
     * @example `maxSelectedLabels: 5` // Multi-select will show up to 5 selected labels before collapsing
     * @default undefined
     */
    maxSelectedLabels?: number;
    /**
     * Specifies a maximum width for the control, defaults to 50%
     * @example `maxWidth: '80%'` // Control will not exceed 80% of container width
     */
    maxWidth?: string;
    /**
     * Defines the min value for an input of type number - should be used with corresponding validator
     * @example `min: 100` // Input value cannot be less than 100, use with Validators.min(100)
     */
    min?: number;
    /** Minimum number of fraction digits to display for number inputs */
    minFractionDigits?: number;
    /**
     * Defines the min length for an input - should be used with corresponding validator
     * @example `minLength: 3` // Input requires at least 3 characters, use with Validators.minLength(3)
     */
    minLength?: number;
    /**
     * Specifies a minimum width for the control, defaults to 50%
     * @example `minWidth: '300px'` // Control will be at least 300px wide
     */
    minWidth?: string;
    /**
     * Enables multiple selection for select button controls - allows selecting multiple options simultaneously
     * @example `multipleSelectButton: true` // User can select multiple button options at once
     */
    multipleSelectButton?: boolean;
    /**
     * Allows deselecting/toggling select button options - enables clicking to unselect a previously selected option
     * @example `isSelectButtonOptionToggleable: true` // User can click a selected button to deselect it
     */
    isSelectButtonOptionToggleable?: boolean;
    /**
     * Placeholder text to display when the control has no value
     * @example `placeholder: 'Select an option'`
     */
    placeholder?: string;
    /** Direction for radio button options layout - 'row' for horizontal, 'column' for vertical
     * @example `radioOptionsDirection: 'row'` // Displays radio buttons in a horizontal row
     */
    radioOptionsDirection?: "row" | "column";
    /**
     * Specifies if the FormControl should be non-nullable (cannot have null values)
     * @example `nonNullable: true` // FormControl will reject null values and use default value instead
     */
    nonNullable?: boolean;
    /**
     * Defines the method to trigger for autocomplete suggestions - returns observable of options
     * @example `searchOptionsFn: (term) => this.userService.searchUsers(term)`
     */
    searchOptionsFn?: ControlOnSearchFn;
    /** Step value for number inputs - defines the increment/decrement step */
    step?: number;
    /** CSS class to apply to the form field wrapper component for styling purposes */
    styleClass?: string;
    /**
     * Columns to display when using TABLE control type - defines the table structure
     * @example `tableCtrlColumns: [
     *   { key: 'name', label: 'Name', controlType: CONTROL_TYPES.INPUT, type: INPUT_TYPES.TEXT },
     *   { key: 'age', label: 'Age', controlType: CONTROL_TYPES.INPUT, type: INPUT_TYPES.NUMBER }
     * ]`
     * @note Validators only handle 'required' at the moment for table-control columns
     */
    tableCtrlColumns?: CrudItemOptions[];
    /**
     * Store advanced configuration for table controls such as pagination, sorting, etc.
     * @example `tableCtrlConfig: { paginator: true, rows: 10, sortable: true }`
     */
    tableCtrlConfig?: Partial<TableCtrlConfig>;
    /** Height of the rich text editor control
     * @example `richTextEditorHeight: '300px'` // Sets the editor height to 300 pixels
     */
    textEditorHeight?: string;
    /**
     * Optional tooltip label that appears when hovering over the control
     * @example `tooltipLabel: 'Enter your email address used for notifications'`
     */
    tooltipLabel?: string;
    /** Whether to use grouping separators (e.g., thousands separators) for number inputs
     * @default false
     * @example `useNumberGrouping: true` // Displays numbers with grouping separators
     */
    useNumberGrouping?: boolean;
    /**
     * Specifies validators for form control
     *
     * When enabled on a simple FormControl, the validator will be applied on the control
     *
     * When enabled on a array control, the validator will be applied on each child
     * @example `validators: [Validators.required]` // or use `required` shared validator.
     */
    validators?: ValidatorFn[];
    /**
     * Specifies a fixed width for the control, will set both minWidth and maxWidth
     * @example `width: '250px'` // Control will be exactly 250px wide
     */
    width?: string;
    /**
     * Specifies the media type for the control of type FILES
     * @example `mediaType: 'image'` // Control will accept image files
     */
    mediaType?: "image" | string;
    /**
     * Whether to enable preview for uploaded files
     * @example `isPreviewEnabled: true` // Enables preview for uploaded images
     */
    isPreviewEnabled?: boolean;
    /**
     * Can the file input control accept multiple files for upload
     * @example `multiple: true` // User can select and upload multiple files at once
     */
    multiple?: boolean;
    /**
     * Maximum file size allowed in bytes
     * Will produce a form error when exceeded
     * @example `maxFileSize: 8000000` // Limits file size to 8MB
     */
    maxFileSize?: number;
}

type DeepPartial<T> = {
    [P in keyof T]?: T[P] extends (...args: unknown[]) => unknown ? T[P] : T[P] extends object ? DeepPartial<T[P]> : T[P];
};
interface CrudLabels {
    toolbar: {
        export: string;
        configureColumns: string;
        refresh: string;
    };
    exportDialog: {
        header: string;
        chooseFormat: string;
        chooseData: string;
        all: string;
        selection: string;
        cancel: string;
        export: string;
    };
    columnsDialog: {
        header: string;
        cancel: string;
        save: string;
    };
    columnsViews: {
        title: string;
        add: string;
        delete: string;
        validate: string;
        cancel: string;
        deleteConfirmation: string;
    };
    tableActions: {
        edit: string;
        delete: string;
    };
    tableControl: {
        add: string;
        delete: string;
        noData: string;
        actionsColumnHeader: string;
        multiselectValidate: string;
        multiselectUnsavedChanges: string;
    };
    history: {
        restore: string;
        updatedAt: string;
        updatedBy: string;
        property: string;
        value: string;
        previousValue: string;
        showPreviousValue: string;
        noChanges: string;
    };
    editionDialog: {
        historyHeader: string;
        archive: string;
        validate: string;
        modeCreate: string;
        modeConsult: string;
        modeEdit: string;
        cancel: string;
        close: string;
    };
    form: {
        reset: string;
        submit: string;
        noFields: string;
    };
    arrayElement: {
        delete: string;
    };
    picklist: {
        sourceHeader: string;
        targetHeader: string;
    };
    dateControl: {
        close: string;
        clear: string;
        today: string;
        validate: string;
    };
    richTextEditor: {
        editHtml: string;
    };
    fileUpload: {
        chooseFile: string;
        dragDropLabel: string;
        uploadedFilesTitle: string;
        canAddMore: string;
        cannotAddMore: string;
        maxFileSizeExceeded: (fileName: string, maxFileSize: number) => string;
    };
    autocomplete: {
        newOption: string;
    };
    validators: {
        invalid: string;
        required: string;
        unknownValue: string;
        emailInvalid: string;
        minlength: string;
        maxlength: string;
        max: string;
        min: string;
        maxFileSize: string;
    };
    patterns: {
        nameWithDashes: string;
        lettersWithSpaces: string;
        lettersWithoutSpaces: string;
        alphanumericalWithSpaces: string;
        alphanumerical: string;
        onlyCaps: string;
        integer: string;
        phoneNumber: string;
        withExtension: string;
    };
    archivedConfig: {
        label: string;
        labelAt: string;
        archived: string;
        active: string;
    };
    tableRegular: {
        currentPageReport: (first: string, last: string, total: string) => string;
    };
    table: {
        exportFailedTitle: string;
        exportFailedDetail: string;
        deleteConfirmationSingle: string;
        deleteConfirmationMultiple: (count: number) => string;
        restoreConfirmationSingle: string;
        restoreConfirmationMultiple: (count: number) => string;
        confirmationHeader: string;
        confirmationCancel: string;
        confirmationConfirm: string;
        defaultViewName: string;
    };
    download: {
        noPdfPrintWarning: string;
    };
    checkbox: {
        yes: string;
        no: string;
    };
    auditConfig: {
        createdAt: string;
        createdBy: string;
        updatedAt: string;
        updatedBy: string;
    };
}
declare const DEFAULT_CRUD_LABELS: CrudLabels;
declare const CRUD_LABELS: InjectionToken<CrudLabels>;
/**
 * Provides a partial translation override merged with the French defaults.
 * Only supply the sections/keys you want to change.
 *
 * @example
 * providers: [
 *   provideCrudLabels({
 *     toolbar: { export: 'Export data', refresh: 'Refresh' },
 *     tableActions: { edit: 'Edit', delete: 'Delete' },
 *   })
 * ]
 */
declare function provideCrudLabels(labels: DeepPartial<CrudLabels>): Provider;

declare class ArchiveInfo {
    updatedAt: Date | null;
    updaterId: number | null;
    updaterName: string | null;
    createdAt: Date | null;
    creatorId: number | null;
    creatorName: string | null;
    archived: boolean;
    archivedAt: Date | null;
}
declare function createArchivedConfig(labels?: CrudLabels["archivedConfig"]): StrictCrudItemOptions<ArchiveInfo>[];
/** @deprecated Use createArchivedConfig() instead */
declare const ARCHIVED_CONFIG: StrictCrudItemOptions<ArchiveInfo>[];

declare class IdInfo {
    id: number | null;
}
declare const ID_CONFIG: StrictCrudItemOptions<IdInfo>;

declare class CrudItemBase implements IdInfo, ArchiveInfo {
    id: number | null;
    archived: boolean;
    archivedAt: Date | null;
    updatedAt: Date | null;
    updaterId: number | null;
    updaterName: string | null;
    createdAt: Date | null;
    creatorId: number | null;
    creatorName: string | null;
}

type CrudItemFactory<T> = () => T;

type TableColumnBase = CrudItemOptions & ColumnOptions;
interface TableColumn extends TableColumnBase {
    key: string;
    isVisible?: boolean;
    defaultWidth?: string;
}

interface ExcelParams {
    columns: Record<string, TableColumn>;
    fileName: string;
    sheetName: string;
}

type ButtonType = "validate" | "cancel" | "delete" | "restore" | "edit" | "simple-icon";
declare class CrudButtonComponent {
    /** Template type of the button */
    readonly type: _angular_core.InputSignal<ButtonType>;
    /** Is the button disabled */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Is the button loading */
    readonly loading: _angular_core.InputSignal<boolean>;
    /** Label of the button, if not provide, the default label will be used */
    readonly label: _angular_core.InputSignal<string>;
    /** Icons */
    readonly icon: _angular_core.InputSignal<string | undefined>;
    /** Optional color for the button */
    readonly severity: _angular_core.InputSignal<ButtonSeverity>;
    /** Event emitted each time the button is clicked */
    readonly clicked: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrudButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrudButtonComponent, "crd-crud-button", never, { "type": { "alias": "type"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, never, true, never>;
}

type LabelStrategy = "ifta" | "float" | "normal";

/**
 * Represents a collection of rows from a query
 */
interface Rows<T> {
    rows: T[];
    errorCode?: number;
}
/**
 * Represents a collection of rows with total count for pagination
 */
interface RowsAndCount<T> extends Rows<T> {
    total: number;
}

type CrudGetParams = TableLazyLoadEvent & {
    excel?: ExcelParams;
};
interface Repository<T> {
    get: (e: CrudGetParams) => Observable<RowsAndCount<T>>;
    getById: (id: number) => Observable<RowsAndCount<T>>;
    getAll: () => Observable<RowsAndCount<T>>;
    getAndCacheAll: () => Observable<T[]>;
    create: (args: T) => Observable<Rows<T>>;
    update: (args: T) => Observable<Rows<T>>;
    archive: (args: number[]) => Observable<null>;
    updateFiles: (files: File[], id: number) => Observable<Rows<T>>;
    restore: (args: number[]) => Observable<null>;
    getHistory: (id: number) => Observable<RowsAndCount<unknown>>;
}
type Calls<T> = Partial<Repository<T>>;
/**
 * Permissions object to restrict which write operations are available.
 * Read operations (get, getById, getAll, getHistory...) are always preserved.
 * Set a permission to `false` to remove the corresponding call.
 */
interface CallsPermissions {
    canCreate?: boolean;
    canUpdate?: boolean;
    canArchive?: boolean;
    canRestore?: boolean;
}
interface FileOperationConfig<T> {
    filePropertyKey?: string;
    apiSuffix?: string;
    serializer?: (item: T) => FormData;
}
interface CrudRepositoryConfig<T = any> {
    endpoint: string;
    fileOperationsConfig?: FileOperationConfig<T>;
}

type LocalUpdatePayload = {
    value: CrudItemBase;
    feature: "update";
} | {
    value: CrudItemBase;
    feature: "create";
} | {
    value: number[];
    feature: "archive";
} | {
    value: number[];
    feature: "restore";
};
declare class CrudFeatures {
    create: boolean;
    update: boolean;
    archive: boolean;
    getHistory: boolean;
    updateFiles: boolean;
    restore: boolean;
}
declare class CrudLoader<TData extends CrudItemBase> {
    private readonly loadingService;
    private readonly state;
    private readonly _features;
    readonly features: _angular_core.Signal<CrudFeatures>;
    private readonly params;
    private httpCalls;
    private readonly _forceCloseEdition;
    readonly forceCloseEdition: _angular_core.Signal<number | null>;
    private readonly _config;
    get getCall(): ((e: TableLazyLoadEvent & {
        excel?: _dwtechs_crud_builder.ExcelParams;
    }) => Observable<RowsAndCount<TData>>) | (() => Observable<RowsAndCount<any>>);
    set(httpCalls: Calls<TData>): void;
    storeConfig(config: CrudItemOptions[]): void;
    enableFeatures(): void;
    load(event?: {
        params?: TableLazyLoadEvent;
        partial: "false";
    } | {
        partial: "true";
        params: Partial<TableLazyLoadEvent>;
    }): void;
    create(args: TData): Observable<Rows<TData> | null>;
    update(args: TData): Observable<Rows<TData> | null>;
    archive(args: number[]): Observable<null>;
    restore(args: number[]): Observable<null>;
    get(): Observable<RowsAndCount<TData>>;
    private assignFilePaths;
    updateFiles(files: File[], id: number | null): Observable<boolean> | Observable<Rows<TData>>;
    updateLocalRows(payload: LocalUpdatePayload): void;
    private handleLocalData;
}

type HistorizedData<T> = {
    id: number;
    tstamp: string;
    operation: string;
    updaterId: number;
    updaterName: string;
    record: T;
};
interface FullHistoryRow<T> extends HistorizedData<T> {
    id: number;
    changes: {
        oldValue: unknown;
        newValue: unknown;
        propKey: keyof T;
        label: string;
        hasChanged: boolean;
    }[];
}

declare class EditionDialogComponent<TData extends CrudItemBase> {
    protected readonly labels: _dwtechs_crud_builder.CrudLabels;
    private readonly globalHistoryMapper;
    /** Configuration array that defines the structure and behavior of form fields */
    readonly config: _angular_core.InputSignal<CrudItemOptions[]>;
    /** CRUD features configuration that defines available operations */
    readonly features: _angular_core.InputSignal<CrudFeatures>;
    /** Function to retrieve history data for an entry by ID */
    readonly getHistory: _angular_core.InputSignal<((id: number) => Observable<{
        rows: unknown[];
        total: number | undefined;
    }>) | undefined>;
    /**
     * Optional mapper to transform raw history rows from the API into `HistorizedData<TData>`.
     * Use this when the API response shape differs from the expected `HistorizedData` contract.
     */
    readonly historyMapper: _angular_core.InputSignal<((raw: unknown) => HistorizedData<TData>) | undefined>;
    /** Custom validator applied to the entire form group */
    readonly groupValidator: _angular_core.InputSignal<ValidatorFn | undefined>;
    /** Dialog header title text */
    readonly customHeader: _angular_core.InputSignal<string>;
    /** Displayed entity label */
    readonly entityLabel: _angular_core.InputSignal<string>;
    /** Dialog height (CSS value) */
    readonly height: _angular_core.InputSignal<string | undefined>;
    /** Whether the dialog is in creation mode (vs edit mode) */
    readonly isCreation: _angular_core.InputSignal<boolean>;
    /** Whether the dialog is in readonly mode */
    readonly isReadonly: _angular_core.InputSignal<boolean>;
    /** Controls dialog visibility state */
    readonly isVisible: _angular_core.InputSignal<boolean>;
    /** Dialog width (CSS value) */
    readonly width: _angular_core.InputSignal<string | undefined>;
    /**
     * Optional option to configure the default size of the dialog
     * @param "xs" | "s" | "m" | "l"
     * @default "s"
     * */
    readonly size: _angular_core.InputSignal<"xs" | "s" | "m" | "l">;
    /** Is something loading */
    readonly isLoading: _angular_core.InputSignal<boolean>;
    /** Strategy for generating labels for form controls */
    readonly labelStrategy: _angular_core.InputSignal<LabelStrategy>;
    /** Variant for the label strategy. Will be applied for float labels */
    readonly labelStrategyVariant: _angular_core.InputSignal<"on" | "in" | "over" | undefined>;
    /** The data object being edited (two-way binding) */
    readonly editedEntry: _angular_core.ModelSignal<TData>;
    /** Emitted when entry is archived/deleted */
    readonly archived: _angular_core.OutputEmitterRef<TData | null>;
    /** Emitted when entry is restored */
    readonly restored: _angular_core.OutputEmitterRef<TData | null>;
    /** Emitted when entry is edited (value changes) */
    readonly edited: _angular_core.OutputEmitterRef<TData | null>;
    /** Emitted when form values change */
    readonly formChanged: _angular_core.OutputEmitterRef<TData>;
    /** Emitted when dialog should be hidden */
    readonly hide: _angular_core.OutputEmitterRef<void>;
    /** Emitted when entry is saved */
    readonly saved: _angular_core.OutputEmitterRef<TData | null>;
    /** Emitted when form validation state changes */
    readonly validityChanged: _angular_core.OutputEmitterRef<boolean>;
    /** Whether the form is currently invalid */
    invalidForm: boolean;
    /** Timestamp to force form reload */
    forceReloadTime: _angular_core.WritableSignal<number>;
    /** Whether to show the previous value column in history */
    readonly showOldValue: _angular_core.WritableSignal<boolean>;
    /** ID of the currently edited entry */
    private readonly editedEntryId;
    /** Calculated width of the dialog based on size or fixed width */
    readonly calculatedWidth: _angular_core.Signal<string>;
    readonly formColumnsCount: _angular_core.Signal<1 | 2 | 3 | 4>;
    /** Dialog header label */
    readonly dialogTitle: _angular_core.Signal<string>;
    private readonly canArchiveRestore;
    readonly isArchiveBtnDisplayed: _angular_core.Signal<boolean>;
    readonly isRestoreBtnDisplayed: _angular_core.Signal<boolean>;
    /** Observable stream of history data for the current entry */
    readonly history$: Observable<_dwtechs_crud_builder.RowsAndCount<any> | {
        rows: HistorizedData<TData>[];
        total: number | undefined;
    }>;
    /** Whether the save button should be displayed based on form state and permissions */
    readonly canInteract: _angular_core.Signal<boolean>;
    readonly closeButtonLabel: _angular_core.Signal<string>;
    /**
     * Handles form value changes and updates the edited entry
     * @param value - The new form values
     */
    onFormChanged(value: TData): void;
    /**
     * Handles form validation state changes
     * @param valid - Whether the form is currently valid
     */
    onValidityChange(valid: boolean): void;
    /**
     * Handles selection of a history entry to restore
     * @param entry - The history entry to restore
     */
    onHistorySelect(entry: HistorizedData<TData>): void;
    /**
     * Handles save action and emits the current entry
     */
    onSave(): void;
    /**
     * Handles dialog hide action
     */
    onHide(): void;
    /**
     * Handles delete/archive action and emits the current entry
     */
    onArchive(): void;
    onRestore(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EditionDialogComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EditionDialogComponent<any>, "crd-edition-dialog", never, { "config": { "alias": "config"; "required": false; "isSignal": true; }; "features": { "alias": "features"; "required": false; "isSignal": true; }; "getHistory": { "alias": "getHistory"; "required": false; "isSignal": true; }; "historyMapper": { "alias": "historyMapper"; "required": false; "isSignal": true; }; "groupValidator": { "alias": "groupValidator"; "required": false; "isSignal": true; }; "customHeader": { "alias": "customHeader"; "required": false; "isSignal": true; }; "entityLabel": { "alias": "entityLabel"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "isCreation": { "alias": "isCreation"; "required": false; "isSignal": true; }; "isReadonly": { "alias": "isReadonly"; "required": false; "isSignal": true; }; "isVisible": { "alias": "isVisible"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "isLoading": { "alias": "isLoading"; "required": false; "isSignal": true; }; "labelStrategy": { "alias": "labelStrategy"; "required": false; "isSignal": true; }; "labelStrategyVariant": { "alias": "labelStrategyVariant"; "required": false; "isSignal": true; }; "editedEntry": { "alias": "editedEntry"; "required": true; "isSignal": true; }; }, { "editedEntry": "editedEntryChange"; "archived": "archived"; "restored": "restored"; "edited": "edited"; "formChanged": "formChanged"; "hide": "hide"; "saved": "saved"; "validityChanged": "validityChanged"; }, never, never, true, never>;
}

/**
 * Optional injection token to provide a global mapper that transforms raw API history rows
 * into the `HistorizedData` shape expected by the history component.
 *
 * Provide this token in your `app.config.ts` when your API response shape differs
 * from the `HistorizedData` contract (e.g. different field names).
 *
 * The `historyMapper` input on `EditionDialogComponent` takes precedence over this token
 * when both are defined.
 *
 * @example
 * // app.config.ts
 * {
 *   provide: HISTORY_MAPPER,
 *   useValue: (raw: unknown): HistorizedData<unknown> => {
 *     const r = raw as { timestamp: string; action: string; consumerId: number; consumerName: string; data: unknown };
 *     return {
 *       tstamp: r.timestamp,
 *       operation: r.action,
 *       updaterId: r.consumerId,
 *       updaterName: r.consumerName,
 *       val: r.data,
 *       table_name: 'unknown',
 *     };
 *   }
 * }
 */
declare const HISTORY_MAPPER: InjectionToken<(raw: unknown) => HistorizedData<unknown>>;

declare class HistoryComponent<TData> {
    protected readonly labels: _dwtechs_crud_builder.CrudLabels;
    readonly data: _angular_core.InputSignal<{
        rows: HistorizedData<TData>[];
        total: number | undefined;
    } | null>;
    readonly config: _angular_core.InputSignal<CrudItemOptions[]>;
    readonly rows: _angular_core.Signal<FullHistoryRow<TData>[]>;
    readonly selected: _angular_core.OutputEmitterRef<HistorizedData<TData>>;
    readonly showOldValue: _angular_core.InputSignal<boolean>;
    readonly dateFormat = "yyyy-MM-dd HH:mm:ss";
    selectedDate: string | null;
    expandedRows: Record<string, boolean>;
    showVersion(entry: HistorizedData<TData>): void;
    private buildHistoryTable;
    private buildChangesTable;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HistoryComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HistoryComponent<any>, "crd-history", never, { "data": { "alias": "data"; "required": true; "isSignal": true; }; "config": { "alias": "config"; "required": true; "isSignal": true; }; "showOldValue": { "alias": "showOldValue"; "required": false; "isSignal": true; }; }, { "selected": "selected"; }, never, never, true, never>;
}

interface Adapter<T> {
    adapt(item: any): T;
    adaptMany(items: any[]): T[];
    convert(item: T): any;
    convertMany(items: T[]): any[];
}

declare function createAuditConfig(labels?: CrudLabels["auditConfig"]): StrictCrudItemOptions<ArchiveInfo>[];

/**
 * Contract that any ACL adapter must fulfill to integrate with `filterCalls`.
 * The implementation can be backed by any access-control system
 * (role-based, scope-based, feature flags, etc.).
 */
interface AclAdapter {
    permissionsFor(functionality: string | undefined): CallsPermissions;
}
/**
 * Injection token for the ACL adapter.
 * The default implementation grants all permissions (open access).
 *
 * @example — provide your own implementation in app.config.ts:
 * providers: [
 *   { provide: ACL_ADAPTER, useExisting: AclService }
 * ]
 */
declare const ACL_ADAPTER: InjectionToken<AclAdapter>;

/**
 * Generic helper class to build entity configuration with resolved route data
 */
declare class ConfigHelper<TService extends {
    config: (payload: ActivatedRouteSnapshot) => CrudItemOptions[];
}> {
    private readonly route;
    /**
     * Get the entity configuration with resolved data from the activated route
     * @param service The service instance that provides the config method
     */
    getConfig(service: TService): CrudItemOptions[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfigHelper<any>, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ConfigHelper<any>>;
}

declare class CrudRepository<T> {
    private readonly http;
    private readonly apiPrefix;
    private apiUrl;
    private fileOperationsConfig;
    private _all$;
    /** Configure the repository with an endpoint and return CRUD operations */
    with(config: CrudRepositoryConfig): Repository<T>;
    private readonly operations;
    /**
     * Search for entities in the database, and return the result as an
     * observable of RowsAndCount.
     *
     * @param e The TableLazyLoadEvent to send to the server. If null, returns
     *          NO_ROWS_AND_COUNT.
     * @returns An observable of RowsAndCount<T>
     */
    private get;
    /**
     * Retrieve a single entity by its ID.
     *
     * @param itemId The ID of the item to retrieve.
     * @returns An observable of RowsAndCount<T>, containing a single item.
     */
    private getById;
    /**
     * Create a single entity in the database.
     *
     * @param item The entity to create.
     * @returns An observable of Rows<T>, containing a single item.
     */
    private create;
    /**
     * Update a single entity in the database.
     *
     * @param item The entity to update.
     * @returns An observable of Rows<T>, containing a single item.
     */
    private update;
    /**
     * Archive a list of items in the database.
     *
     * @param itemId The IDs of the items to archive.
     * @returns An observable of null.
     */
    private archive;
    private restore;
    private getAllAndCache;
    private invalidateCache;
    private getHistory;
    private updateFiles;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrudRepository<any>, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<CrudRepository<any>>;
}

/**
 * Filters a Calls object based on a permissions object.
 * Read operations (get, getById, getAll, getHistory...) are always preserved.
 * Designed to be used inside a `computed()` for signal-based reactivity.
 *
 * @example
 * public readonly httpCalls = computed(() =>
 *   filterCalls(this.service.httpCalls, {
 *     canCreate: this.acls.canWrite(),
 *     canUpdate: this.acls.canWrite(),
 *     canArchive: this.acls.canDelete(),
 *   })
 * );
 */
declare function filterCalls<T>(calls: Calls<T>, permissions: CallsPermissions): Calls<T>;

declare const NO_ROWS_AND_COUNT: RowsAndCount<any>;
declare const NO_ROWS: Rows<any>;

declare const DATE_FORMAT = "yyyy-MM-dd";
declare const DATE_WITH_TIME_FORMAT = "yyyy-MM-dd HH:mm";
declare const DATE_WITH_SECONDS_FORMAT = "yyyy-MM-dd HH:mm:ss";
declare const DATE_FORMAT_CALENDAR = "yy-mm-dd";
declare const getMidnightTimeStamp: (value: Date | string | null) => number | null;
declare const getDateRangeWithoutTime: (dateRange: [from: Date, to: Date]) => (Date | null)[];
declare const canBeDate: (d: unknown) => d is Date | number | string;
declare const isValidDateString: (value: unknown) => boolean;
declare const formatDate: (value: string | number | Date, withTime?: boolean) => string;
declare const getDifferenceInDays: (date1: Date, date2: Date) => number;

declare class DownloadService {
    private readonly http;
    private readonly snackbarService;
    private readonly labels;
    /**
     * Downloads a blob as a file or opens it in a print module for PDFs.
     *
     * @param data - The blob data to download. Throws an error if null.
     * @param fileName - The name to use for the downloaded file.
     * @param openPrintModule - If true, opens PDF files in print module instead of downloading.
     *                          Shows info message for non-PDF files. Defaults to false.
     *
     * @throws {Error} When data is null or undefined.
     */
    downloadBlob(data: Blob | null, fileName: string, openPrintModule?: boolean): void;
    /**
     * Downloads a file from the given location and saves it locally.
     * If the file is not found, it retries the download up to 5 times with a
     * 2 second delay between each try.
     *
     * @param location the URL of the file to download
     * @returns an Observable that emits nothing
     * @throws an error if the file is not found after the maximum number of retries
     */
    tryDownloadFile(location: string, filename?: string, openPrintModule?: boolean): rxjs.Observable<Blob>;
    private openPrintModule;
    /**
     * Extracts the file name from the content disposition header of the response.
     * @param response The HTTP response containing the blob.
     * @returns The extracted file name or "undefined" if not found.
     */
    extractFileInfo(response: HttpResponse<Blob>): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DownloadService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DownloadService>;
}

declare class DocumentFormDataMapper {
    toFormData<T>(formValues: CrudItemBase & T, fileProperties: (keyof (CrudItemBase & T))[]): FormData;
    private stringify;
}

declare class OfflineService {
    private readonly _isOnline;
    get isOnline(): Signal<boolean>;
    constructor();
    private updateOnlineStatus;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OfflineService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<OfflineService>;
}

type ExcelExportMode = "local" | "server";

declare const FILTER_LEVELS: {
    readonly BASIC: "basic";
    readonly INTERMEDIATE: "intermediate";
    readonly ADVANCED: "advanced";
};
type FilterLevel = (typeof FILTER_LEVELS)[keyof typeof FILTER_LEVELS];

/**
 * Extended validation errors interface that enforces a structure with a required message
 * and allows additional properties of unknown type
 */
interface TypedValidationErrors {
    [key: string]: {
        message: string;
        [key: string]: unknown;
    };
}
/**
 * Extended validator function type that returns strongly-typed validation errors
 */
type GroupValidatorFn = (control: AbstractControl) => TypedValidationErrors | null;

declare const FOUR_COLUMN_WIDTH = "25%";
declare const THREE_COLUMN_WIDTH = "33.333%";
declare const TWO_COLUMN_WIDTH = "50%";
declare const ONE_COLUMN_WIDTH = "100%";
declare class FormComponent<T extends {
    [key: string]: unknown;
} = {
    [key: string]: unknown;
}> implements OnInit {
    private readonly dynamicFormService;
    private readonly destroyRef;
    protected readonly labels: _dwtechs_crud_builder.CrudLabels;
    /** Defines the number of columns for form layout */
    readonly columnsCount: _angular_core.InputSignal<1 | 2 | 3 | 4>;
    /** Configuration array that defines the structure and behavior of form fields */
    readonly config: _angular_core.ModelSignal<CrudItemOptions[]>;
    /** Trigger to force form recreation */
    readonly forceReload: _angular_core.InputSignal<number>;
    /** Trigger to force form values reload without recreating the form */
    readonly forceReloadValues: _angular_core.InputSignal<number>;
    /** Custom validator applied to the entire form group */
    readonly groupValidator: _angular_core.InputSignal<GroupValidatorFn | undefined>;
    /** Makes the entire form read-only */
    readonly isReadonly: _angular_core.InputSignal<boolean | undefined>;
    /** Strategy for generating labels for form controls */
    readonly labelStrategy: _angular_core.InputSignal<LabelStrategy>;
    /** Variant for the label strategy. Will be applied for float labels */
    readonly labelStrategyVariant: _angular_core.InputSignal<"on" | "in" | "over" | undefined>;
    /** Two-way binding for form values */
    readonly model: _angular_core.ModelSignal<any>;
    /** Custom label for the reset button */
    readonly resetButtonLabel: _angular_core.InputSignal<string | undefined>;
    /** Shows debug information including form values and validation state */
    readonly showDebug: _angular_core.InputSignal<boolean | undefined>;
    /** Shows/hides the reset button */
    readonly showReset: _angular_core.InputSignal<boolean | undefined>;
    /** Shows/hides the submit button */
    readonly showSubmit: _angular_core.InputSignal<boolean | undefined>;
    /** Custom label for the submit button */
    readonly submitButtonLabel: _angular_core.InputSignal<string | undefined>;
    /** Emitted when user interacts with form fields */
    readonly fieldInteraction: _angular_core.OutputEmitterRef<FormFieldInteractionEvent>;
    /** Emitted when form values change (two-way binding) */
    readonly modelChange: _angular_core.OutputEmitterRef<any>;
    /** Emitted when form is reset (if showReset is true) */
    readonly reset: _angular_core.OutputEmitterRef<void>;
    /** Emitted when form is submitted (if showSubmit is true) */
    readonly submitted: _angular_core.OutputEmitterRef<any>;
    /** Emitted when form validation state changes */
    readonly validityChange: _angular_core.OutputEmitterRef<boolean>;
    /** Angular FormGroupDirective reference */
    readonly formDir: _angular_core.Signal<FormGroupDirective | undefined>;
    /** Default width for form controls based on column count */
    readonly defaultControlWidth: _angular_core.Signal<"25%" | "33.333%" | "50%" | "100%">;
    readonly syncValueInc: _angular_core.WritableSignal<number>;
    /** Angular FormGroup instance */
    readonly form: _angular_core.WritableSignal<FormGroup<any> | null>;
    /** Formatted error messages from form validation */
    get formErrors(): string;
    /** Effect to handle form reload when forceReload input changes */
    readonly forceReloadFormEffect: _angular_core.EffectRef;
    private initialValues;
    private prevReloadForm;
    private sub;
    private readonly pendingActions;
    /**
     * Angular OnInit lifecycle hook
     * Initializes form creation and change watching
     */
    ngOnInit(): void;
    /**
     * Resets form to initial values and emits reset event
     * resetForm() => clean values, validators, touched/dirty statuses...
     * resetForm(value) => set specific values but clean the rest
     */
    onReset(): void;
    /**
     * Handles form submission if valid
     */
    onSubmit(): void;
    /**
     * Track function for ngFor to optimize rendering
     */
    trackControl(index: number, item: CrudItemOptions): string;
    emitInteraction(event: FormFieldInteractionEvent): void;
    /**
     * Applies condition result to the actual form control
     */
    private applyCondition;
    /**
     * Creates form group and sets up value change watching
     */
    private createAndWatchForm;
    private evaluatePendingActions;
    private log;
    /**
     * Destroys current form and cleans up subscriptions
     */
    private destroyForm;
    /**
     * Gets a form control by key from parent form
     */
    private getControl;
    /**
     * Recursively evaluates and applies conditions to a control
     */
    private getUpdatedControl;
    /**
     * Sets async validators on a form control
     */
    private setAsyncValidators;
    /**
     * Enables or disables a form control
     */
    private setDisabled;
    /**
     * Shows or hides a form control and resets its value if hidden
     */
    private setHidden;
    /**
     * Sets validators on a form control
     */
    private setValidators;
    /**
     * Updates control configurations based on conditional logic
     */
    private updateControlsWithConditions;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormComponent<any>, "frm-form", never, { "columnsCount": { "alias": "columnsCount"; "required": false; "isSignal": true; }; "config": { "alias": "config"; "required": true; "isSignal": true; }; "forceReload": { "alias": "forceReload"; "required": false; "isSignal": true; }; "forceReloadValues": { "alias": "forceReloadValues"; "required": false; "isSignal": true; }; "groupValidator": { "alias": "groupValidator"; "required": false; "isSignal": true; }; "isReadonly": { "alias": "isReadonly"; "required": false; "isSignal": true; }; "labelStrategy": { "alias": "labelStrategy"; "required": false; "isSignal": true; }; "labelStrategyVariant": { "alias": "labelStrategyVariant"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": true; "isSignal": true; }; "resetButtonLabel": { "alias": "resetButtonLabel"; "required": false; "isSignal": true; }; "showDebug": { "alias": "showDebug"; "required": false; "isSignal": true; }; "showReset": { "alias": "showReset"; "required": false; "isSignal": true; }; "showSubmit": { "alias": "showSubmit"; "required": false; "isSignal": true; }; "submitButtonLabel": { "alias": "submitButtonLabel"; "required": false; "isSignal": true; }; }, { "config": "configChange"; "model": "modelChange"; "fieldInteraction": "fieldInteraction"; "modelChange": "modelChange"; "reset": "reset"; "submitted": "submitted"; "validityChange": "validityChange"; }, never, never, true, never>;
}

declare class FormBuilderService {
    toFormGroup(items: CrudItemOptions[], values: {
        [key: string]: unknown;
    }, groupValidator: GroupValidatorFn | undefined, isReadonlyMode: boolean): UntypedFormGroup;
    private toFormArray;
    toFormControl(item: CrudItemOptions, value: unknown, isReadonlyMode: boolean): FormControl;
    private getValue;
    /**
     * Generates form control options including validators, async validators, disabled state, and non-nullability
     * based on the provided `CrudItemOptions` and the current readonly mode.
     *
     * @param item - The CRUD item options containing control configuration.
     * @param isReadonlyMode - Indicates if the form is in readonly mode.
     * @returns An object containing:
     *   - `validators`: An array of synchronous validator functions.
     *   - `asyncValidators`: An array of asynchronous validator functions.
     *   - `disabled`: Whether the control should be disabled.
     *   - `nonNullable`: Whether the control value should be non-nullable.
     */
    private getFormControlOptions;
    private getDisableState;
    private getValidators;
    private getAsyncValidators;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormBuilderService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<FormBuilderService>;
}

/** Validator to check if the value is required */
declare const required: typeof Validators.required;
/** Validator to check if the value is true */
declare const requiredTrue: typeof Validators.requiredTrue;
/** Validator to check if the value is greater than x */
declare const min: (x: number) => _angular_forms.ValidatorFn;
/** Validator to check if the value is less than x */
declare const max: (x: number) => _angular_forms.ValidatorFn;
/** Validator to check if the value has a length greater than x */
declare const minlength: (x: number) => _angular_forms.ValidatorFn;
/** Validator to check if the value has a length less than x */
declare const maxlength: (x: number) => _angular_forms.ValidatorFn;

declare function EmailValidator(control: AbstractControl): ValidationErrors | null;

/**
 * Base error messages for form validation.
 * Strings are provided via the CRUD_LABELS injection token.
 * This object is kept for backwards compatibility with customErrorMessages override.
 */
declare const BASE_FORM_ERROR_MESSAGES: Record<string, string>;

interface FormTokenData {
    customErrorMessages?: {
        [key: string]: string;
    };
}
declare const APP_FORM_CONFIG: InjectionToken<FormTokenData>;

interface GeoCoordinates {
    location: [lng: number, lat: number];
    street: string;
    zipCode: string;
    city: string;
    label: string;
}
declare const INIT_COORDINATES: GeoCoordinates;
declare const LOCATION_CONFIG: StrictCrudItemOptions<GeoCoordinates>[];

declare function patternValidator(config: {
    pattern: RegExp | string;
    message: string;
}): ValidatorFn;

/** ALPHABETICAL */
declare const nameWithDashes: (message?: string) => {
    pattern: string;
    message: string;
};
declare const lettersWithSpaces: (message?: string) => {
    pattern: string;
    message: string;
};
declare const lettersWithoutSpaces: (message?: string) => {
    pattern: string;
    message: string;
};
/** ALPHANUMERICAL */
declare const alphanumericalWithSpaces: (message?: string) => {
    pattern: RegExp;
    message: string;
};
declare const alphanumericalWithoutSpaces: (message?: string) => {
    pattern: RegExp;
    message: string;
};
declare const onlyCaps: (message?: string) => {
    pattern: RegExp;
    message: string;
};
/** NUMERICAL */
declare const integer: (message?: string) => {
    pattern: RegExp;
    message: string;
};
/** OTHERS */
declare const phoneNumber: (message?: string) => {
    pattern: RegExp;
    message: string;
};
declare const withExtension: (message?: string) => {
    pattern: RegExp;
    message: string;
};

interface Socials {
    website: string;
    video: string;
    instagram: string;
    facebook: string;
    x: string;
    linkedin: string;
}
declare const INIT_SOCIALS: Socials;
declare const SOCIALS_CONFIG: StrictCrudItemOptions<Socials>[];

declare class TableConfig {
    id: number | null;
    name: string;
    component: string;
    conf: ColumnConfig[];
    isActive: boolean;
    locked: boolean;
    constructor(component: string, name?: string);
}
interface ExtendedTableConfig extends TableConfig {
    columns: TableColumn[];
}
type ColumnConfig = Pick<TableColumn, "key" | "isVisible" | "defaultWidth">;

declare class TableConfigService {
    private readonly api;
    private readonly http;
    getViews(componentId: string): Observable<TableConfig[]>;
    updateMany(componentId: string, views: TableConfig[]): Observable<Rows<TableConfig>>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableConfigService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TableConfigService>;
}

declare class LocationInterceptorService {
    private readonly _waitingForLocationHeader;
    private locationHeader?;
    readonly waitingForLocationHeader: _angular_core.Signal<boolean>;
    /**
     * Consume the location header stored in this service. This will clear the stored location.
     * It also clear the waiting flag
     * @returns The stored location header, or undefined if there is none.
     */
    consumeLocation(): string | undefined;
    /**
     * Indicates that the location interceptor should wait for a location header
     * to be received in the next response.
     */
    enableLocationHeaderWaiting(): void;
    /**
     * Store the location header intercepted by the location interceptor. This will clear
     * the waiting flag.
     * @param location The location header to store.
     */
    setLocation(location: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LocationInterceptorService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<LocationInterceptorService>;
}

interface ColumnResizeEvent {
    colKey: string;
    newWidthPx: number;
}

declare class TableRegularComponent<TData> {
    protected readonly labels: _dwtechs_crud_builder.CrudLabels;
    readonly dataTable: _angular_core.Signal<Table<any> | undefined>;
    readonly columns: _angular_core.InputSignal<TableColumn[]>;
    readonly data: _angular_core.InputSignal<TData[]>;
    readonly total: _angular_core.InputSignal<number>;
    readonly selectable: _angular_core.InputSignal<boolean>;
    readonly clickableRows: _angular_core.InputSignal<boolean>;
    readonly lazy: _angular_core.InputSignal<boolean>;
    readonly features: _angular_core.InputSignal<CrudFeatures>;
    readonly selectedEntries: _angular_core.ModelSignal<TData[]>;
    readonly filterable: _angular_core.InputSignal<boolean>;
    readonly defaultFilters: _angular_core.InputSignalWithTransform<{
        [key: string]: FilterMetadata | FilterMetadata[];
    }, unknown>;
    readonly sortable: _angular_core.InputSignal<boolean>;
    readonly defaultSort: _angular_core.InputSignal<{
        field: string;
        order: 1 | -1;
    }>;
    readonly paginator: _angular_core.InputSignal<boolean>;
    readonly filterLevel: _angular_core.InputSignal<FilterLevel>;
    readonly customRowStyles: _angular_core.InputSignal<((row: TData) => Record<string, string>) | undefined>;
    readonly customActionsTemplate: _angular_core.InputSignal<TemplateRef<unknown> | undefined>;
    readonly isContextMenuEnabled: _angular_core.InputSignal<boolean>;
    readonly entityId: _angular_core.InputSignal<string>;
    readonly stateStorage: _angular_core.InputSignal<"session" | "local">;
    readonly persistState: _angular_core.InputSignal<boolean>;
    readonly areColumnsResizable: _angular_core.InputSignal<boolean>;
    readonly rows: _angular_core.InputSignal<number>;
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[]>;
    readonly outsideTableHeight: _angular_core.InputSignal<string>;
    readonly stripedRows: _angular_core.InputSignal<boolean>;
    readonly additionalReadonlyProperties: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    readonly selectedEntriesChange: _angular_core.OutputEmitterRef<TData[]>;
    readonly lazyLoaded: _angular_core.OutputEmitterRef<TableLazyLoadEvent>;
    readonly archived: _angular_core.OutputEmitterRef<number>;
    readonly cellClicked: _angular_core.OutputEmitterRef<{
        row: TData;
        mode: "read" | "write";
    }>;
    readonly columnResized: _angular_core.OutputEmitterRef<ColumnResizeEvent>;
    readonly lastUpdateTime: _angular_core.WritableSignal<number>;
    readonly totalCount: _angular_core.Signal<number>;
    readonly visibleColumns: _angular_core.Signal<TableColumn[]>;
    readonly contextMenuItems: _angular_core.Signal<primeng_api.MenuItem[]>;
    rightClickedEntry: TData | null;
    readonly scrollHeight: _angular_core.Signal<string>;
    readonly sortEffect: _angular_core.EffectRef;
    trackCol(col: TableColumn): TableColumn;
    onLazyLoad(event: TableLazyLoadEvent): void;
    onCellClick(rowData: TData, col: TableColumn): void;
    onActionClick(rowData: TData, mode: "read" | "write"): void;
    resolvedRowStyles(rowData: TData): Record<string, string>;
    onColumnResized(event: TableColResizeEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableRegularComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableRegularComponent<any>, "tbl-table-regular", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "data": { "alias": "data"; "required": true; "isSignal": true; }; "total": { "alias": "total"; "required": true; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": true; "isSignal": true; }; "clickableRows": { "alias": "clickableRows"; "required": true; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": true; "isSignal": true; }; "features": { "alias": "features"; "required": true; "isSignal": true; }; "selectedEntries": { "alias": "selectedEntries"; "required": true; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": true; "isSignal": true; }; "defaultFilters": { "alias": "defaultFilters"; "required": true; "isSignal": true; }; "sortable": { "alias": "sortable"; "required": true; "isSignal": true; }; "defaultSort": { "alias": "defaultSort"; "required": true; "isSignal": true; }; "paginator": { "alias": "paginator"; "required": true; "isSignal": true; }; "filterLevel": { "alias": "filterLevel"; "required": true; "isSignal": true; }; "customRowStyles": { "alias": "customRowStyles"; "required": true; "isSignal": true; }; "customActionsTemplate": { "alias": "customActionsTemplate"; "required": true; "isSignal": true; }; "isContextMenuEnabled": { "alias": "isContextMenuEnabled"; "required": true; "isSignal": true; }; "entityId": { "alias": "entityId"; "required": true; "isSignal": true; }; "stateStorage": { "alias": "stateStorage"; "required": true; "isSignal": true; }; "persistState": { "alias": "persistState"; "required": true; "isSignal": true; }; "areColumnsResizable": { "alias": "areColumnsResizable"; "required": true; "isSignal": true; }; "rows": { "alias": "rows"; "required": true; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": true; "isSignal": true; }; "outsideTableHeight": { "alias": "outsideTableHeight"; "required": true; "isSignal": true; }; "stripedRows": { "alias": "stripedRows"; "required": true; "isSignal": true; }; "additionalReadonlyProperties": { "alias": "additionalReadonlyProperties"; "required": true; "isSignal": true; }; }, { "selectedEntries": "selectedEntriesChange"; "selectedEntriesChange": "selectedEntriesChange"; "lazyLoaded": "lazyLoaded"; "archived": "archived"; "cellClicked": "cellClicked"; "columnResized": "columnResized"; }, never, never, true, never>;
}

interface ExportOptions {
    format: "csv" | "xls";
    selection: "all" | "filtered";
}

declare class TableComponent<TData extends CrudItemBase> implements OnInit, OnChanges {
    private readonly confirmationService;
    private readonly exportService;
    readonly loader: CrudLoader<TData>;
    private readonly loadingService;
    private readonly route;
    private readonly router;
    private readonly state;
    private readonly columnsStorage;
    private readonly messageService;
    private readonly labels;
    /**
     * Controls whether columns can be hidden/shown through the configuration dialog.
     * When enabled, shows a gear icon in the toolbar allowing users to manage column visibility.
     * Persists user preferences in localStorage based on entityId.
     */
    readonly areColumnsConfigurable: _angular_core.InputSignal<boolean>;
    /** Determines whether table columns can be resized by the user */
    readonly areColumnsResizable: _angular_core.InputSignal<boolean>;
    /**
     * Enables deep linking to specific items by adding their ID to the URL query parameters.
     * When enabled, editing an item will add ?id=123 to the URL, allowing direct access to the edition dialog.
     * Useful for bookmarking or sharing links to specific items.
     */
    readonly canAccessItemFromUrl: _angular_core.InputSignal<boolean>;
    /**
     * Determines user interaction mode with table rows.
     * When true, clicking anywhere on a row opens the edition dialog.
     * When false, only action buttons in the actions column trigger edition.
     * Affects user experience and accessibility.
     */
    readonly clickableRows: _angular_core.InputSignal<boolean>;
    /**
     * Defines the structure and behavior of table columns and form fields.
     * Each CrudItemOptions object represents a column/field with display rules, validation, and control type.
     * This is the core configuration that drives both table display and form generation.
     */
    readonly config: _angular_core.InputSignal<CrudItemOptions[]>;
    /**
     * Custom template for actions in the table's action column.
     * Allows injection of custom buttons or controls
     * The template receives the current row data as context, enabling dynamic action visibility.
     * Actions are displayed in place of the standard CRUD actions (edit, delete) in the actions column.
     */
    readonly customActionsTemplate: _angular_core.InputSignal<TemplateRef<unknown> | undefined>;
    /**
     * Applies conditional CSS styles to table rows based on row data.
     * Function receives row data and returns CSS properties object.
     * Useful for highlighting specific rows, status indication, or visual categorization.
     */
    readonly customRowStyles: _angular_core.InputSignal<((row: TData) => Record<string, string>) | undefined>;
    /**
     * Forces read-only mode on the edition dialog when a row matches one of the provided property/value pairs.
     * Each key-value entry is checked against the clicked row: if any matches, the dialog opens in read-only mode instead of edit mode.
     * Takes precedence over the normal edit/write mode resolution.
     * @example { active: false } — opens inactive users in read-only mode
     */
    readonly additionalReadonlyProperties: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    /**
     * Factory function that creates new entity instances for the creation dialog.
     * Must return an object with default values matching your entity structure.
     * Called when user clicks "New" button to populate the form with initial values.
     */
    readonly entityFactory: _angular_core.InputSignal<CrudItemFactory<TData>>;
    /**
     * Unique identifier for the entity type, used for persisting column preferences.
     * Should be consistent across the application for the same entity type.
     * Used as localStorage key for saving column visibility and order preferences.
     */
    readonly entityId: _angular_core.InputSignal<string>;
    /**
     * Human-readable label for a single entity instance.
     * Used in dialog titles, confirmation messages, and form labels.
     * Should be singular form (not plural) for grammatical correctness.
     */
    readonly entityLabel: _angular_core.InputSignal<string>;
    /**
     * Custom title for the edition dialog, overriding the default generated title.
     * When not provided, title is auto-generated as "Creation - {entityLabel}" or "Edition - {entityLabel}".
     * Useful for specific workflows or when default title doesn't fit the context.
     */
    readonly editionDialogTitle: _angular_core.InputSignal<string>;
    /** Width of the edition dialog
     * Sets the width of the edition/creation dialog modal.
     * Accepts any valid CSS width value (px, %, vw, etc.).
     * Larger dialogs are better for complex forms with many fields.
     * @default undefined
     * @example "50vw"
     * Will override 'editionDialogSize' if specified */
    readonly editionDialogWidth: _angular_core.InputSignal<string | undefined>;
    /**
     * Sets the size of the edition/creation dialog modal.
     * Accepts "xs" (1 col), "s" (2 cols), "m" (3 cols), or "l" (4 cols) for small, medium, or large predefined sizes.
     * @default "s"
     * */
    readonly editionDialogSize: _angular_core.InputSignal<"xs" | "s" | "m" | "l">;
    /** Height of the edition dialog - defaults to undefined */
    readonly editionDialogHeight: _angular_core.InputSignal<string | undefined>;
    /**
     * Determines how Excel export is processed - locally in browser or on server.
     * Local export is faster but limited by browser memory and capabilities.
     * Server export handles large datasets and complex formatting but requires backend support.
     */
    readonly excelExportMode: _angular_core.InputSignal<ExcelExportMode>;
    /**
     * Enables/disables column filtering functionality in the table.
     * When enabled, shows filter inputs in column headers allowing users to search/filter data.
     * Filter behavior depends on filterLevel setting.
     */
    readonly filterable: _angular_core.InputSignal<boolean>;
    /**
     * Defines the complexity level of filtering interface.
     * Controls what type of filter controls are shown and how they behave.
     * Higher levels provide more sophisticated filtering options.
     */
    readonly filterLevel: _angular_core.InputSignal<FilterLevel>;
    /**
     * Trigger for forcing table data reload from parent component.
     * Increment this value to trigger a reload. The actual value doesn't matter, only changes.
     * Useful for refreshing data after external operations or on specific events.
     */
    readonly forceReload: _angular_core.InputSignal<number | undefined>;
    /**
     * Custom validator function applied to the entire form group in edition dialog.
     * Receives the FormGroup and returns validation errors object or null.
     * Useful for cross-field validation, business rules, or complex validation logic.
     */
    readonly groupValidator: _angular_core.InputSignal<ValidatorFn | undefined>;
    /**
     * Configuration object containing all HTTP operations for CRUD functionality.
     * Defines how the table communicates with your backend API for data operations.
     * Each operation is optional - omit unsupported operations to hide related UI elements.
     */
    readonly httpCalls: _angular_core.InputSignal<Partial<_dwtechs_crud_builder.Repository<TData>>>;
    /**
     * Enables the context menu on right-clicking table rows.
     * When enabled, right-clicking a row shows a context menu with actions like View and Edit.
     * Context menu actions emit the same events as clicking the row or action buttons.
     * Useful for providing quick access to common actions without cluttering the UI.
     * @default false
     */
    readonly isContextMenuEnabled: _angular_core.InputSignal<boolean>;
    /**
     * Enables CSV export functionality in the table toolbar.
     * When enabled, shows a CSV export button allowing users to download table data as CSV file.
     * Export includes all visible columns with current filters and sorting applied.
     */
    readonly isCsvExportEnabled: _angular_core.InputSignal<boolean>;
    /**
     * Disables the default edition modal dialog, allowing custom edition handling.
     * When disabled, clicking edit buttons or rows will only emit events without showing the dialog.
     * Use this when you need custom edit behavior or external editing components.
     */
    readonly isDefaultEditionDisabled: _angular_core.InputSignal<boolean>;
    /**
     * Enables Excel export functionality in the table toolbar.
     * When enabled, shows an Excel export button for downloading data as .xlsx file.
     * Excel export supports better formatting and larger datasets than CSV.
     */
    readonly isExcelExportEnabled: _angular_core.InputSignal<boolean>;
    /**
     * Enables preferences mode for the table.
     * When enabled, will query configured views from backend and allow user to switch and add new ones.
     * When disabled, only the default view is used without any view management options.
     */
    readonly isPreferencesModeEnabled: _angular_core.InputSignal<boolean>;
    /** Strategy for generating labels for form controls */
    readonly labelStrategy: _angular_core.InputSignal<LabelStrategy>;
    /** Variant for the label strategy. Will be applied for float labels */
    readonly labelStrategyVariant: _angular_core.InputSignal<"on" | "in" | "over" | undefined>;
    /**
     * Enables lazy loading mode for large datasets.
     * When true, data is loaded on-demand as user scrolls, sorts, or filters.
     * When false, all data is loaded at once (suitable for smaller datasets).
     * Improves performance for tables with thousands of rows.
     */
    readonly lazy: _angular_core.InputSignal<boolean>;
    /**
     * Sets the height of the area outside the table (e.g. toolbar, paginator) to allow proper calculation of scrollable area.
     * Accepts any valid CSS height value (px, %, vh, etc.).
     * When not set, defaults to 200px to fit most screens.
     * Adjust this value based on your layout and available screen space.
     * @default "200px"
     * @example "400px"
     * @example "50vh"
     */
    readonly outsideTableHeight: _angular_core.InputSignal<string>;
    /**
     * Enables pagination controls at the bottom of the table.
     * When enabled, shows page numbers, page size selector, and navigation controls.
     * Helps manage large datasets by splitting them into manageable pages.
     */
    readonly paginator: _angular_core.InputSignal<boolean>;
    /**
     * Number of rows to display per page when pagination is enabled.
     * Should be a positive integer. Common values are 10, 25, 50, etc.
     * Affects how many rows are shown at once and how pagination behaves.
     */
    readonly rows: _angular_core.InputSignal<number>;
    /**
     * Options for page size selection in the pagination controls.
     * Should be an array of positive integers representing page size options.
     * The first value is usually the default page size.
     * Allows users to choose how many rows they want to see per page.
     */
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[]>;
    /**
     * Enables row selection with checkboxes for bulk operations.
     * When enabled, adds a checkbox column allowing users to select multiple rows.
     * Selected rows are available via selectedEntries property for bulk actions.
     */
    readonly selectable: _angular_core.InputSignal<boolean>;
    /**
     * Enables column sorting functionality in table headers.
     * When enabled, clicking column headers toggles sorting order (asc/desc/none).
     * Individual columns can override this setting via their sortable property.
     */
    readonly sortable: _angular_core.InputSignal<boolean>;
    /**
     * Enables persistence of table state (filters, sorting, pagination) across page reloads.
     * When enabled, state is stored using the storage type defined by `stateStorage`.
     * Disabled by default — set to `true` to opt in to state persistence.
     * @default false
     */
    readonly persistState: _angular_core.InputSignal<boolean>;
    /**
     * Specifies where to store table state (filters, sorting, pagination).
     * Can be "local" for localStorage or "session" for sessionStorage.
     * Persists user preferences across sessions or tabs based on selection.
     * Only applies when `persistState` is `true`.
     * @default "session"
     */
    readonly stateStorage: _angular_core.InputSignal<"session" | "local">;
    /**
     * Enables alternating background colors on table rows (zebra striping).
     * When true, odd and even rows will have slightly different background colors,
     * making it easier to visually follow a row across wide tables.
     * When false, all rows share the same background color.
     * Passed down to the underlying TableRegularComponent and its p-table binding.
     * @default true
     */
    readonly stripedRows: _angular_core.InputSignal<boolean>;
    /**
     * Display title shown at the top of the table component.
     * Usually plural form of the entity name, appears in the table header/toolbar.
     * Helps users understand what data they're viewing and provides context.
     */
    readonly tableTitle: _angular_core.InputSignal<string>;
    readonly editionDialogClosed: _angular_core.OutputEmitterRef<TData | null>;
    readonly formChanged: _angular_core.OutputEmitterRef<TData>;
    readonly newClicked: _angular_core.OutputEmitterRef<void>;
    readonly rowClicked: _angular_core.OutputEmitterRef<TData>;
    readonly validityChanged: _angular_core.OutputEmitterRef<boolean>;
    readonly tableRegular: _angular_core.Signal<TableRegularComponent<any> | undefined>;
    readonly columns: _angular_core.WritableSignal<_dwtechs_crud_builder.TableColumn[]>;
    readonly data: _angular_core.Signal<any[]>;
    readonly features: _angular_core.Signal<CrudFeatures>;
    readonly isExportingData: _angular_core.WritableSignal<boolean>;
    readonly isLoading: _angular_core.Signal<boolean>;
    readonly total: _angular_core.Signal<number>;
    readonly views: _angular_core.WritableSignal<ExtendedTableConfig[] | null>;
    readonly defaultFilters: _angular_core.Signal<{
        [s: string]: primeng_api.FilterMetadata | primeng_api.FilterMetadata[] | undefined;
    } | undefined>;
    readonly defaultSort: _angular_core.WritableSignal<{
        field: string;
        order: 1 | -1;
    }>;
    readonly forceCloseDialog: _angular_core.EffectRef;
    ControlType: {
        readonly AUTOCOMPLETE: "autocomplete";
        readonly CHECKBOX: "checkbox";
        readonly CUSTOM: "custom";
        readonly DATE: "date";
        readonly FILES: "files";
        readonly GROUP: "group";
        readonly INPUT: "input";
        readonly MULTISELECT: "multiselect";
        readonly PICKLIST: "picklist";
        readonly RADIO: "radio";
        readonly SELECT: "select";
        readonly SELECT_BUTTON: "select_button";
        readonly TABLE: "table";
        readonly TEXTAREA: "textarea";
        readonly WYSIWYG: "wysiwyg";
    };
    editedEntry: TData | null;
    readonly isColumnsConfigDialogDisplayed: _angular_core.WritableSignal<boolean>;
    readonly isCreation: _angular_core.WritableSignal<boolean>;
    readonly isEntryEditionDialogDisplayed: _angular_core.WritableSignal<boolean>;
    readonly isReadonly: _angular_core.WritableSignal<boolean>;
    readonly isExportDialogVisible: _angular_core.WritableSignal<boolean>;
    private readonly lazyLoad$;
    selectedEntries: TData[];
    private readonly debouncedLoad$;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    applyViews(newViews: ExtendedTableConfig[]): void;
    hideColumnsConfigDialog(): void;
    hideEditionDialog(): void;
    onArchive(id: number): void;
    onArchiveMany(): void;
    onCellClick({ row, mode, }: {
        row: TData;
        mode: "read" | "write";
    }): void;
    onEditedEntryArchive(editedEntry: TData | null): void;
    onEditedEntryRestore(editedEntry: TData | null): void;
    onEditedEntryEdit(entry: TData | null): void;
    onEditedEntrySave(entry: TData | null): void;
    onExport(event: ExportOptions): void;
    onFormChanged(editedData: TData): void;
    onLazyLoad(event: TableLazyLoadEvent): void;
    onColumnResized(event: ColumnResizeEvent): void;
    onNew(): void;
    getHistoryForEntry(): Calls<TData>["getHistory"];
    onValidityChanged(validity: boolean): void;
    refreshData(): void;
    showColumnsManagement(): void;
    onEdit(rowData: TData): void;
    onView(rowData: TData): void;
    private appendIdToUrl;
    private displayItemEditionModal;
    private getFiles;
    private handleArchive;
    private handleRestore;
    private confirm;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableComponent<any>, "tbl-table", never, { "areColumnsConfigurable": { "alias": "areColumnsConfigurable"; "required": false; "isSignal": true; }; "areColumnsResizable": { "alias": "areColumnsResizable"; "required": false; "isSignal": true; }; "canAccessItemFromUrl": { "alias": "canAccessItemFromUrl"; "required": false; "isSignal": true; }; "clickableRows": { "alias": "clickableRows"; "required": false; "isSignal": true; }; "config": { "alias": "config"; "required": true; "isSignal": true; }; "customActionsTemplate": { "alias": "customActionsTemplate"; "required": false; "isSignal": true; }; "customRowStyles": { "alias": "customRowStyles"; "required": false; "isSignal": true; }; "additionalReadonlyProperties": { "alias": "additionalReadonlyProperties"; "required": false; "isSignal": true; }; "entityFactory": { "alias": "entityFactory"; "required": true; "isSignal": true; }; "entityId": { "alias": "entityId"; "required": true; "isSignal": true; }; "entityLabel": { "alias": "entityLabel"; "required": false; "isSignal": true; }; "editionDialogTitle": { "alias": "editionDialogTitle"; "required": false; "isSignal": true; }; "editionDialogWidth": { "alias": "editionDialogWidth"; "required": false; "isSignal": true; }; "editionDialogSize": { "alias": "editionDialogSize"; "required": false; "isSignal": true; }; "editionDialogHeight": { "alias": "editionDialogHeight"; "required": false; "isSignal": true; }; "excelExportMode": { "alias": "excelExportMode"; "required": false; "isSignal": true; }; "filterable": { "alias": "filterable"; "required": false; "isSignal": true; }; "filterLevel": { "alias": "filterLevel"; "required": false; "isSignal": true; }; "forceReload": { "alias": "forceReload"; "required": false; "isSignal": true; }; "groupValidator": { "alias": "groupValidator"; "required": false; "isSignal": true; }; "httpCalls": { "alias": "httpCalls"; "required": true; "isSignal": true; }; "isContextMenuEnabled": { "alias": "isContextMenuEnabled"; "required": false; "isSignal": true; }; "isCsvExportEnabled": { "alias": "isCsvExportEnabled"; "required": false; "isSignal": true; }; "isDefaultEditionDisabled": { "alias": "isDefaultEditionDisabled"; "required": false; "isSignal": true; }; "isExcelExportEnabled": { "alias": "isExcelExportEnabled"; "required": false; "isSignal": true; }; "isPreferencesModeEnabled": { "alias": "isPreferencesModeEnabled"; "required": false; "isSignal": true; }; "labelStrategy": { "alias": "labelStrategy"; "required": false; "isSignal": true; }; "labelStrategyVariant": { "alias": "labelStrategyVariant"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "outsideTableHeight": { "alias": "outsideTableHeight"; "required": false; "isSignal": true; }; "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "sortable": { "alias": "sortable"; "required": false; "isSignal": true; }; "persistState": { "alias": "persistState"; "required": false; "isSignal": true; }; "stateStorage": { "alias": "stateStorage"; "required": false; "isSignal": true; }; "stripedRows": { "alias": "stripedRows"; "required": false; "isSignal": true; }; "tableTitle": { "alias": "tableTitle"; "required": true; "isSignal": true; }; }, { "editionDialogClosed": "editionDialogClosed"; "formChanged": "formChanged"; "newClicked": "newClicked"; "rowClicked": "rowClicked"; "validityChanged": "validityChanged"; }, never, never, true, never>;
}

export { ACL_ADAPTER, APP_CONFIG, APP_FORM_CONFIG, ARCHIVED_CONFIG, ArchiveInfo, BASE_FORM_ERROR_MESSAGES, CONTROL_TYPES, CRUD_LABELS, ColumnOptions, ConfigHelper, ControlOptions, CrudButtonComponent, CrudItemBase, CrudRepository, DATE_FORMAT, DATE_FORMAT_CALENDAR, DATE_WITH_SECONDS_FORMAT, DATE_WITH_TIME_FORMAT, DEFAULT_CRUD_LABELS, DocumentFormDataMapper, DownloadService, EditionDialogComponent, EmailValidator, FILTER_LEVELS, FOUR_COLUMN_WIDTH, FileInfo, FormBuilderService, FormComponent, HISTORY_MAPPER, HistoryComponent, ID_CONFIG, INIT_COORDINATES, INIT_SOCIALS, INPUT_TYPES, IdInfo, LOCATION_CONFIG, LoadingService, LocalStorageService, LocationInterceptorService, NO_ROWS, NO_ROWS_AND_COUNT, ONE_COLUMN_WIDTH, OfflineService, SOCIALS_CONFIG, SnackbarService, THREE_COLUMN_WIDTH, TWO_COLUMN_WIDTH, TableComponent, TableConfig, TableConfigService, alphanumericalWithSpaces, alphanumericalWithoutSpaces, canBeDate, createArchivedConfig, createAuditConfig, filterCalls, formatDate, getDateRangeWithoutTime, getDifferenceInDays, getMidnightTimeStamp, integer, interpolate, isValidDateString, lettersWithSpaces, lettersWithoutSpaces, max, maxlength, min, minlength, nameWithDashes, onlyCaps, patternValidator, phoneNumber, provideCrudLabels, required, requiredTrue, toSelectItems, withExtension };
export type { AclAdapter, Adapter, AppConfig, ButtonType, Calls, CallsPermissions, ColumnConfig, ColumnResizeEvent, ConditionFn, ControlAction, ControlActionResult, ControlArrayConfig, ControlOptionsCondition, ControlType, CrudItemFactory, CrudItemOptions, CrudLabels, CrudRepositoryConfig, DeepPartial, ExcelExportMode, ExcelParams, ExtendedSelectItem, ExtendedTableConfig, FileOperationConfig, FilterLevel, FormFieldInteraction, FormFieldInteractionEvent, FormTokenData, FullHistoryRow, GeoCoordinates, GroupValidatorFn, HistorizedData, InputType, ItemCondition, LabelStrategy, ProgressMode, Repository, Rows, RowsAndCount, Socials, StrictCrudItemOptions, TableColumn, TypedValidationErrors };
